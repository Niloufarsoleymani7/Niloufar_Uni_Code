#ifndef FLIGHTBOOKING_H
#define FLIGHTBOOKING_H
#include "booking.h"

class FlightBooking : public Booking
{
public:

    FlightBooking(const std::string &fromDestination, const std::string &toDestination,
                  const std::string &airline, int id, const std::string &fromdate, const std::string &toDate, double price,int travelId);

    std::string showDetails()override;
    void replaceBooking(std::shared_ptr<FlightBooking> booking, std::string &fromDestination,  std::string &toDestination,
                         std::string &airline,std::string &fromdate,  std::string &toDate, double price);

    const std::string &getFromDestination() const;
    void setFromDestination(const std::string &newFromDestination);

    const std::string &getToDestination() const;
    void setToDestination(const std::string &newToDestination);

    const std::string &getAirline() const;
    void setAirline(const std::string &newAirline);

    ~FlightBooking();

private :

    std::string _fromDestination{};
    std::string _toDestination {};
    std::string _airline {};
};

#endif // FLIGHTBOOKING_H
