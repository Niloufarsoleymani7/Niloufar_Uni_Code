#ifndef RENTALCARRESERVATION_H
#define RENTALCARRESERVATION_H
#include "booking.h"

class RentalCarReservation : public Booking
{
public:
    RentalCarReservation(const std::string &pickupLocation, const std::string &returnLocation, const std::string &company, int id, const std::string &fromdate, const std::string &toDate, double price,int travelId);

    std::string showDetails() override;

    ~RentalCarReservation();

    const std::string &getPickupLocation() const;
    void setPickupLocation(const std::string &newPickupLocation);
    const std::string &getReturnLocation() const;
    void setReturnLocation(const std::string &newReturnLocation);
    const std::string &getCompany() const;
    void setCompany(const std::string &newCompany);

private:

    std::string _pickupLocation{};
    std::string _returnLocation {};
    std::string _company {};
};

#endif // RENTALCARRESERVATION_H
