#include "sortfunktor.h"

bool SortFunktor::operator()(std::shared_ptr<Booking> booking1, std::shared_ptr<Booking> booking2) const
{
    if (sortierParameter == PRICE)
        return booking1->getPrice() < booking2->getPrice();
    else if (sortierParameter == ID)
        return booking1->getId() < booking2->getId();
    else if (sortierParameter == FromDATE)
        return booking1->getFromdate() < booking2->getFromdate();
    else if (sortierParameter == ToDATE)
        return booking1->getToDate() < booking2->getToDate();
    else
        return false;
}
