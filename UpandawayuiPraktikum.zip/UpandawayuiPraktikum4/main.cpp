#include "mainwindow.h"
#include <QApplication>
#include <iostream>
#include <travelagency.h>
#include <execution>
#include <test.h>
using namespace std;

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

int main(int argc, char *argv[])
{
    // Zuerst muss in der UI-Datei der Text eingelesen werden. Dieser Text stammt aus der Datei "booking2" im Projektverzeichnis.
    // Anschließend können alle Buchungen angezeigt werden. Dabei gibt es die Möglichkeit, sowohl alle Buchungen im Allgemeinen anzuzeigen,
    // als auch speziell die Buchungen eines bestimmten Kunden. Diese Anwendung bezieht sich auf meine Praktikumsaufgaben an der Universität.
    // Sie demonstriert, wie ich programmieren und designen konnte. Falls Sie die Anwendung starten möchten, befolgen Sie bitte die oben genannten Schritte.

    QApplication a(argc, argv);
    shared_ptr<Travelagency> travelagency=std::make_shared<Travelagency>();
    MainWindow w(0,travelagency);
    w.show();

//    Test test(travelagency);
//    QTest::qExec(&test);

    return a.exec();
}
