#ifndef SORTFUNKTOR_H
#define SORTFUNKTOR_H
#include "booking.h"
#include <memory>

class SortFunktor
{
public:

    enum SortierParameter{ ID=0, PRICE=1, FromDATE=2, ToDATE=3 };

    SortFunktor(SortFunktor::SortierParameter parameter):sortierParameter(parameter){}
    bool operator()(std::shared_ptr<Booking> booking1, std::shared_ptr<Booking> booking2)const;

private:
   SortierParameter sortierParameter;
};

#endif // SORTFUNKTOR_H
