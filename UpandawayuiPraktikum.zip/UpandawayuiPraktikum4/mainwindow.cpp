#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QStringList>
#include <iostream>
#include <travelagency.h>
#include <QMessageBox>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QInputDialog>
#include <sortfunktor.h>


MainWindow::MainWindow(QWidget *parent,shared_ptr<Travelagency> travelagency)
    : QMainWindow(parent) , ui(new Ui::MainWindow),_travelagency(travelagency)
{
    ui->setupUi(this);
    ui->ausgabe_widget_list->hide();
    ui->travelId_tableWidget->hide();
    ui->kunde_tabele_widget->hide();
}

MainWindow::~MainWindow()
{ delete ui; }

void MainWindow::on_actionTextEinlesen_triggered()
{
    QString fileQstring= QFileDialog::getOpenFileName(this, "Select a file to open","C://Users//nilou//Documents//UpandawayuiPraktikum4");
    try
    {
        _travelagency->readtextfile1(fileQstring.toStdString());
        QMessageBox::StandardButtons reply= QMessageBox::question(this,"Datei erfolgreich eingelesen","dateiinfo anschauen?",QMessageBox::Yes | QMessageBox::No);
        if(reply==QMessageBox::Yes)
        {
            std::string fileInfoPopUp=_travelagency->gettextfileinfoForPg2();
            QMessageBox::information(this,"Dateiinfo",fileInfoPopUp.c_str());
        }
    }
    catch (std::runtime_error& msg)
    {
        QString msgfehler=QString::fromStdString(msg.what());
        //QMessageBox::warning(this,"Fehler beim Einlesen der Buchungen",msgfehler,QMessageBox::Reset | QMessageBox::Discard | QMessageBox::Cancel );

        QMessageBox msgBox;
        msgBox.setText(msgfehler);
        msgBox.setStandardButtons(QMessageBox::Retry | QMessageBox::Discard | QMessageBox::Cancel);
        msgBox.setDetailedText("Wenn Sie die Datei bereits korrigiert haben,"
                               " wählen Sie Wiederholen. Wahlen Sie Verwerfen', um alle Buchungen zu loschen "
                               "und 'Abbrechen', um die vorhandenen Buchungen stehenzulassen und diesen Dialog zu verlassen");
        int ret = msgBox.exec();
        switch (ret)
        { case QMessageBox::Retry:

            _travelagency->delteBooking();
            // travelagency->readfile1(fileQstring.toStdString());
            on_actionTextEinlesen_triggered();//behtare ke doobare seda bezanm ta hameye try catch ha bian
            break;
        case QMessageBox::Discard:
            _travelagency.reset();
            break;
        case QMessageBox::Cancel:
            break;
        }
    }
}

void MainWindow::on_actionAlle_anzeigen_triggered()
{
    ui->ausgabe_widget_list->clear();
    ui->ausgabe_widget_list->show();

    std::string allebuchungen=_travelagency->showbookings();
    if(allebuchungen.size()==0)
    {
        QMessageBox::warning(this,"Fehler bei der Einlesen!","Die gewuenschte Datei muss erst eingelesen werden!");
    }
    else
    {
        for(auto goInBookings:_travelagency->getBookings())
        {
            ui->ausgabe_widget_list->addItem(QString::fromStdString(goInBookings->showDetails()));
        }
    }
}

void MainWindow::on_actionJsonSpeichern_triggered()
{
    QMessageBox::warning(this,"Information","Bitte speichern  Sie Dateiname als dateiname.json");

    QString fileName = QFileDialog::getSaveFileName(this, tr("Save json", "C://Users//nilou//Documents")); //tr("Json Files (*.json)")

    QJsonDocument jsonDocument;
    QJsonArray jsonGesamteBuchungen;

    QJsonArray jsonFlugBuchungenArray;
    QJsonArray jsonHoteBuchungenArray;
    QJsonArray jsonRentalCarBuchungenArray;

    for(auto goInBookings:_travelagency->getBookings())
    {
        if(typeid(*goInBookings)==typeid(FlightBooking)) //muss immer * davor sein
        {
            QJsonObject jsonFlugObject;
            shared_ptr<FlightBooking> flighbuchungen=std::dynamic_pointer_cast<FlightBooking>(goInBookings);

            jsonFlugObject["Id"] = flighbuchungen->getId();
            jsonFlugObject["Ankunftdatum"] =QString::fromStdString(flighbuchungen->getFromdate());
            jsonFlugObject["Abreisedatum"] =QString::fromStdString(flighbuchungen->getFromdate());
            jsonFlugObject["StartFlughafen"] =QString::fromStdString(flighbuchungen->getFromDestination());
            jsonFlugObject["ZielFlughafen"] =QString::fromStdString(flighbuchungen->getToDestination());
            jsonFlugObject["Fluggeselschaft"] =QString::fromStdString(flighbuchungen->getAirline());
            jsonFlugObject["Price"] = flighbuchungen->getPrice();

            jsonFlugBuchungenArray.push_back(jsonFlugObject);
        }
        if (typeid(*goInBookings)==typeid(Hotelbooking))
        {
            QJsonObject jsonHotelObject;
            shared_ptr<Hotelbooking>hotelBuchungen=std::dynamic_pointer_cast<Hotelbooking>(goInBookings);

            jsonHotelObject["Id"] = hotelBuchungen->getId();
            jsonHotelObject["Ankunftdatum"] =QString::fromStdString(hotelBuchungen->getFromdate());
            jsonHotelObject["Abreisedatum"] =QString::fromStdString(hotelBuchungen->getFromdate());
            jsonHotelObject["Stadt"] =QString::fromStdString(hotelBuchungen->getTown());
            jsonHotelObject["Hotel"] =QString::fromStdString(hotelBuchungen->getHotel());
            jsonHotelObject["Price"] = hotelBuchungen->getPrice();

            jsonHoteBuchungenArray.push_back(jsonHotelObject);
        }
        if(typeid(*goInBookings)==typeid(RentalCarReservation))
        {
            QJsonObject jsonRentalCarObject;
            shared_ptr<RentalCarReservation>rentalcarbuchungen=std::dynamic_pointer_cast<RentalCarReservation>(goInBookings);

            jsonRentalCarObject["Id"] = rentalcarbuchungen->getId();
            jsonRentalCarObject["Ankunftdatum"] =QString::fromStdString(rentalcarbuchungen->getFromdate());
            jsonRentalCarObject["Abreisedatum"] =QString::fromStdString(rentalcarbuchungen->getToDate());
            jsonRentalCarObject["Pickuplocation"] =QString::fromStdString(rentalcarbuchungen->getPickupLocation());
            jsonRentalCarObject["returnLocATION"] =QString::fromStdString(rentalcarbuchungen->getReturnLocation());
            jsonRentalCarObject["cCompany"] =QString::fromStdString(rentalcarbuchungen->getCompany());
            jsonRentalCarObject["Price"] = rentalcarbuchungen->getPrice();

            jsonRentalCarBuchungenArray.push_back(jsonRentalCarObject);

        }
    }

    QJsonObject alleFlugObject;//hier kann auch array drin sein ich maa alle array in diesem obj rein
    alleFlugObject["Fligbuchungen"]=jsonFlugBuchungenArray;
    QJsonObject Object2;
    Object2["HotelBuchungen"]=jsonHoteBuchungenArray;
    QJsonObject Object3;
    Object3["Rentalcarrevervation"]=jsonRentalCarBuchungenArray;

    jsonGesamteBuchungen.push_back(alleFlugObject);//muss raus sein
    jsonGesamteBuchungen.push_back(Object2);
    jsonGesamteBuchungen.push_back(Object3);

    jsonDocument.setArray(jsonGesamteBuchungen);

    QFile datei (fileName);
    if (!datei.open(QIODevice::WriteOnly))
        std::cerr << "Datei konnte nicht geoeffnet werden";
    datei.write(jsonDocument.toJson());
    datei.close();
}

void MainWindow::on_ausgabe_widget_list_itemDoubleClicked(QListWidgetItem *item)
{
    ui->ausgabe_widget_list->show();
    shared_ptr<Booking>gesuchteBooking;
    std::string bookingInformation = item->text().toStdString();

    if(bookingInformation[0]=='F')
    {
        std::string id_s =bookingInformation.substr(12, 2);//az 12 2ta bede
        int id = stoi(id_s);
        gesuchteBooking=_travelagency->findBooking(id);
        flightBookingBoxInformationFuellen(gesuchteBooking);
    }

    if(bookingInformation[0]=='H')
    {
        std::string id_s =bookingInformation.substr(18, 2);
        int id = stoi(id_s);
        gesuchteBooking=_travelagency->findBooking(id);
        HotelBookingBoxInformationFuellen(gesuchteBooking);
    }

    if(bookingInformation[0]=='M')
    {
        std::string id_s =bookingInformation.substr(22, 2);
        int id = stoi(id_s);
        gesuchteBooking=_travelagency->findBooking(id);
        MietwagenBookingBoxInformationFuellen(gesuchteBooking);
    }
}

void MainWindow::on_actionAuswaehlen_triggered()
{
    int id = QInputDialog::getInt(this, "Buchung auswählen", "Buchung-ID");
    shared_ptr<Booking> gesuchteBooking=_travelagency->findBooking(id);

    //ui->ausgabe_widget_list->setCurrentItem();

    if(gesuchteBooking==nullptr)
    {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Fehler");
        msgBox.setText("ID kann nicht gefunden werden!");
        msgBox.exec();
    }
    else
    {
        ui->ausgabe_widget_list->clear();
        ui->ausgabe_widget_list->show();

        BookingTabwidgetNacBookingIdFuellen(id);
    }
}

void MainWindow::on_actionAlle_Anzeige_triggered()
{
    ui->ausgabe_widget_list->clear();
    ui->ausgabe_widget_list->show();

    for(size_t i=0;i<_travelagency->getCustomers().size();i++)
    {
        ui->ausgabe_widget_list->addItem(QString::fromStdString("\nKundenID : ")+QString::number(_travelagency->getCustomers().at(i)->getId()));
        ui->ausgabe_widget_list->addItem(QString::fromStdString("Name : ")+QString::fromStdString(_travelagency->getCustomers().at(i)->getName()));
        ui->ausgabe_widget_list->addItem(QString::fromStdString("Anzahl der Reisen : ")+QString::number(_travelagency->getCustomers().at(i)->getTravelList().size()));
    }
}

void MainWindow::on_actionAlle_Anzeigen_triggered()
{
    ui->ausgabe_widget_list->clear();
    ui->ausgabe_widget_list->show();

    for(size_t i=0;i<_travelagency->getTravels().size();i++)
    {
        ui->ausgabe_widget_list->addItem(QString::fromStdString("\nReiseID : ")+QString::number(_travelagency->getTravels().at(i)->getId()));
        ui->ausgabe_widget_list->addItem(QString::fromStdString("KundenID : ")+QString::number(_travelagency->getTravels().at(i)->getCustomerId()));
        ui->ausgabe_widget_list->addItem(QString::fromStdString("Anzahl der Buchungen : ")+QString::number(_travelagency->getTravels().at(i)->getTravelBookings().size()));
    }
}

void MainWindow::on_kunden_suchen_pushButton_clicked()
{
    ui->kunde_tabele_widget->show();
    ui->travelId_tableWidget->hide();

    int customerId=ui->Kunden_id_lineedit->text().toInt();

    shared_ptr<Customer> gefundeneCustomerInCustomers=_travelagency->findCustomer(customerId);
    if(gefundeneCustomerInCustomers==nullptr)
    {
        QMessageBox msgBox;//parent,titel,matn,standardbutton
        msgBox.warning(this,"Fehler","ID kann nicht gefunden werden!",QMessageBox::Ok);
    }
    else
    {
        QString name=QString::fromStdString(gefundeneCustomerInCustomers->getName());
        ui->kundenName_lineEdit->setText(name);
    }

    //colum spalte   row bereite
    int anzahlzeilen=gefundeneCustomerInCustomers->getTravelList().size();

    ui->kunde_tabele_widget->setRowCount(anzahlzeilen);

    for(int y=0;y<anzahlzeilen;y++)
    {

        QTableWidgetItem *id=new QTableWidgetItem(QString::number(gefundeneCustomerInCustomers->getTravelList().at(y)->getId()).arg(y));

        std::vector<shared_ptr<Booking>> bookingsVonCustomer=gefundeneCustomerInCustomers->getTravelList().at(y)->getTravelBookings();

        int minDate{},maxDate{};
        for(auto goInBooking:bookingsVonCustomer)
        {
            if(std::stoi(goInBooking->getToDate())>maxDate){
                maxDate=std::stoi(goInBooking->getToDate());
            }
            if(minDate==0)
            {
                minDate=std::stoi(goInBooking->getFromdate());
            }
            else
            {
                if((std::stoi(goInBooking->getFromdate())<minDate))
                    minDate=std::stoi(goInBooking->getFromdate());
            }
        }

        ui->kunde_tabele_widget->setItem(y,0,id);

        QTableWidgetItem *startdatum=new QTableWidgetItem(QString::number(minDate).arg(y));
        QTableWidgetItem *enddatum=new QTableWidgetItem(QString::number(maxDate).arg(y));

        ui->kunde_tabele_widget->setItem(y,1,startdatum);
        ui->kunde_tabele_widget->setItem(y,2,enddatum);
    }
}

void MainWindow::on_kunde_tabele_widget_cellDoubleClicked(int row)
{
    int travelId=ui->kunde_tabele_widget->item(row,0)->text().toInt();
    travelTabWidgetNachTravelIdFuellen(travelId);
}

void MainWindow::travelTabWidgetNachTravelIdFuellen(int travelId)
{
    ui->travelId_tableWidget->show();

    shared_ptr<Travel>gefundeneTravel=this->_travelagency->findTravel(travelId);
    unsigned long anzahlzeilen=gefundeneTravel->getTravelBookings().size();

    ui->travelId_tableWidget->setRowCount(anzahlzeilen);

    for(unsigned long long y=0;y<anzahlzeilen;y++)
    {
        QTableWidgetItem *id=new QTableWidgetItem(QString::number(gefundeneTravel->getTravelBookings().at(y)->getId()).arg(y));
        QTableWidgetItem *startdatum=new QTableWidgetItem(QString::fromStdString(gefundeneTravel->getTravelBookings().at(y)->getFromdate()).arg(y));
        QTableWidgetItem *enddatum=new QTableWidgetItem(QString::fromStdString(gefundeneTravel->getTravelBookings().at(y)->getToDate()).arg(y));
        QTableWidgetItem *preis=new QTableWidgetItem(QString::number(gefundeneTravel->getTravelBookings().at(y)->getPrice()).arg(y));
        ui->travelId_tableWidget->setItem(y,0,id);
        ui->travelId_tableWidget->setItem(y,1,startdatum);
        ui->travelId_tableWidget->setItem(y,2,enddatum);
        ui->travelId_tableWidget->setItem(y,3,preis);
    }
}

void MainWindow::on_travelId_tableWidget_cellDoubleClicked(int row)
{
    int booklId=ui->travelId_tableWidget->item(row,0)->text().toInt();
    BookingTabwidgetNacBookingIdFuellen(booklId);
}

void MainWindow::BookingTabwidgetNacBookingIdFuellen(int bookingId)
{
    shared_ptr<Booking>gesuchteBooking=this->_travelagency->findBooking(bookingId);

    if(typeid(*gesuchteBooking)==typeid(FlightBooking))
    {
        flightBookingBoxInformationFuellen(gesuchteBooking);
    }
    if(typeid(*gesuchteBooking)==typeid(Hotelbooking))
    {
        HotelBookingBoxInformationFuellen(gesuchteBooking);
    }
    if(typeid(*gesuchteBooking)==typeid(RentalCarReservation))
    {
        MietwagenBookingBoxInformationFuellen(gesuchteBooking);
    }

}

void MainWindow::flightBookingBoxInformationFuellen(shared_ptr<Booking> gesuchteBooking)
{
    QString dataVonBookingInString=QString::number(gesuchteBooking->getId());
    shared_ptr<FlightBooking> flighbuchungen=std::dynamic_pointer_cast<FlightBooking>(gesuchteBooking);

    ui->id_f_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(flighbuchungen->getFromdate());
    QDate Date = QDate::fromString(dataVonBookingInString,"yyyyMMdd");
    ui->startdatum_f_box->setDate(Date);

    dataVonBookingInString=QString::fromStdString(flighbuchungen->getToDate());
    Date = QDate::fromString(dataVonBookingInString,"yyyyMMdd");
    ui->Enddatum_f_box_2->setDate(Date);

    dataVonBookingInString=QString::fromStdString(flighbuchungen->getFromDestination());
    ui->startflughafen_f_box->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(flighbuchungen->getToDestination());
    ui->zielflughafen_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(flighbuchungen->getAirline());
    ui->fluggeselschaft_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(std::to_string(flighbuchungen->getPrice()));
    ui->price_f_box->setSpecialValueText(dataVonBookingInString);

    ui->tabwidget->setCurrentWidget(ui->FlightbuchungTab);
}

void MainWindow::HotelBookingBoxInformationFuellen(shared_ptr<Booking>gesuchteBooking)
{
    shared_ptr<Hotelbooking> hotelBuchungen=std::dynamic_pointer_cast<Hotelbooking>(gesuchteBooking);
    QString dataVonBookingInString=QString::number(gesuchteBooking->getId());

    ui->id_h_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(hotelBuchungen->getFromdate());
    QDate Date = QDate::fromString(dataVonBookingInString,"yyyyMMdd");
    ui->startdatum_h_box->setDate(Date);

    dataVonBookingInString=QString::fromStdString(hotelBuchungen->getToDate());
    Date = QDate::fromString(dataVonBookingInString,"yyyyMMdd");
    ui->enddatum_h_box->setDate(Date);

    dataVonBookingInString=QString::fromStdString(hotelBuchungen->getHotel());
    ui->hotel_h_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(hotelBuchungen->getTown());
    ui->stadt_h_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(std::to_string(hotelBuchungen->getPrice()));
    ui->preis_h_box->setSpecialValueText(dataVonBookingInString);

    ui->tabwidget->setCurrentWidget(ui->hotelTab);
}

void MainWindow::MietwagenBookingBoxInformationFuellen(shared_ptr<Booking>gesuchteBooking)
{
    shared_ptr<RentalCarReservation> rentalcarbuchungen=std::dynamic_pointer_cast<RentalCarReservation>(gesuchteBooking);
    QString dataVonBookingInString=QString::number(gesuchteBooking->getId());
    ui->id_m_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(rentalcarbuchungen->getFromdate());
    QDate Date = QDate::fromString(dataVonBookingInString,"yyyyMMdd");
    ui->Ankunft_m_lineedit->setDate(Date);

    dataVonBookingInString=QString::fromStdString(rentalcarbuchungen->getToDate());
    Date = QDate::fromString(dataVonBookingInString,"yyyyMMdd");
    ui->Abreise_m_lineedit->setDate(Date);


    dataVonBookingInString=QString::fromStdString(rentalcarbuchungen->getPickupLocation());
    ui->pickuplocation_m_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(rentalcarbuchungen->getReturnLocation());
    ui->returnlocation_m_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(rentalcarbuchungen->getCompany());
    ui->company_m_lineedit->setText(dataVonBookingInString);

    dataVonBookingInString=QString::fromStdString(std::to_string(rentalcarbuchungen->getPrice()));
    ui->preis_m_box->setSpecialValueText(dataVonBookingInString);

    ui->tabwidget->setCurrentWidget(ui->MietwagenTab);
}

void MainWindow::jsonSortiertspeichern()
{

    QMessageBox::warning(this,"Information","Bitte speichern  Sie Dateiname als dateiname.json");

    QString fileName = QFileDialog::getSaveFileName(this, tr("Save json", "C://Users//nilou//Documents")); //tr("Json Files (*.json)")

    QJsonDocument jsonDocument;
    QJsonArray jsonGesamteBuchungen;

    QJsonArray jsonFlugBuchungenArray;
    QJsonArray jsonHoteBuchungenArray;
    QJsonArray jsonRentalCarBuchungenArray;

    for(auto goInBookings:_travelagency->getBookings())
    {
        if(typeid(*goInBookings)==typeid(FlightBooking)) //muss immer * davor sein
        {
            QJsonObject jsonFlugObject;
            shared_ptr<FlightBooking> flighbuchungen=std::dynamic_pointer_cast<FlightBooking>(goInBookings);

            jsonFlugObject["Id"] = flighbuchungen->getId();
            jsonFlugObject["Ankunftdatum"] =QString::fromStdString(flighbuchungen->getFromdate());
            jsonFlugObject["Abreisedatum"] =QString::fromStdString(flighbuchungen->getFromdate());
            jsonFlugObject["StartFlughafen"] =QString::fromStdString(flighbuchungen->getFromDestination());
            jsonFlugObject["ZielFlughafen"] =QString::fromStdString(flighbuchungen->getToDestination());
            jsonFlugObject["Fluggeselschaft"] =QString::fromStdString(flighbuchungen->getAirline());
            jsonFlugObject["Price"] = flighbuchungen->getPrice();

            jsonFlugBuchungenArray.push_back(jsonFlugObject);
        }
        if (typeid(*goInBookings)==typeid(Hotelbooking))
        {
            QJsonObject jsonHotelObject;
            shared_ptr<Hotelbooking>hotelBuchungen=std::dynamic_pointer_cast<Hotelbooking>(goInBookings);

            jsonHotelObject["Id"] = hotelBuchungen->getId();
            jsonHotelObject["Ankunftdatum"] =QString::fromStdString(hotelBuchungen->getFromdate());
            jsonHotelObject["Abreisedatum"] =QString::fromStdString(hotelBuchungen->getFromdate());
            jsonHotelObject["Stadt"] =QString::fromStdString(hotelBuchungen->getTown());
            jsonHotelObject["Hotel"] =QString::fromStdString(hotelBuchungen->getHotel());
            jsonHotelObject["Price"] = hotelBuchungen->getPrice();

            jsonHoteBuchungenArray.push_back(jsonHotelObject);
        }
        if(typeid(*goInBookings)==typeid(RentalCarReservation))
        {
            QJsonObject jsonRentalCarObject;
            shared_ptr<RentalCarReservation>rentalcarbuchungen=std::dynamic_pointer_cast<RentalCarReservation>(goInBookings);

            jsonRentalCarObject["Id"] = rentalcarbuchungen->getId();
            jsonRentalCarObject["Ankunftdatum"] =QString::fromStdString(rentalcarbuchungen->getFromdate());
            jsonRentalCarObject["Abreisedatum"] =QString::fromStdString(rentalcarbuchungen->getToDate());
            jsonRentalCarObject["Pickuplocation"] =QString::fromStdString(rentalcarbuchungen->getPickupLocation());
            jsonRentalCarObject["returnLocATION"] =QString::fromStdString(rentalcarbuchungen->getReturnLocation());
            jsonRentalCarObject["cCompany"] =QString::fromStdString(rentalcarbuchungen->getCompany());
            jsonRentalCarObject["Price"] = rentalcarbuchungen->getPrice();

            jsonRentalCarBuchungenArray.push_back(jsonRentalCarObject);

        }
    }
    QJsonObject alleFlugObject;//hier kann auch array drin sein ich maa alle array in diesem obj rein
    alleFlugObject["Fligbuchungen"]=jsonFlugBuchungenArray;
    QJsonObject Object2;
    Object2["HotelBuchungen"]=jsonHoteBuchungenArray;
    QJsonObject Object3;
    Object3["Rentalcarrevervation"]=jsonRentalCarBuchungenArray;

    jsonGesamteBuchungen.push_back(alleFlugObject);//muss raus sein
    jsonGesamteBuchungen.push_back(Object2);
    jsonGesamteBuchungen.push_back(Object3);

    jsonDocument.setArray(jsonGesamteBuchungen);

    QFile datei (fileName);
    if (!datei.open(QIODevice::WriteOnly))
        std::cerr << "Datei konnte nicht geoeffnet werden";
    datei.write(jsonDocument.toJson());
    datei.close();

}

void MainWindow::alleBookingSortiertAlsJSon()
{
    QMessageBox::warning(this,"Information","Bitte speichern  Sie Dateiname als dateiname.json");

    QString fileName = QFileDialog::getSaveFileName(this, tr("Save json", "C://Users//nilou//Documents")); //tr("Json Files (*.json)")

    QJsonDocument jsonDocument;
    QJsonArray jsonGesamteBuchungen;

    QJsonArray jsonBuchungenArray;


    for(auto goInBookings:_travelagency->getBookings())
    {
        if(typeid(*goInBookings)==typeid(FlightBooking)) //muss immer * davor sein
        {
            QJsonObject jsonFlugObject;
            shared_ptr<FlightBooking> flighbuchungen=std::dynamic_pointer_cast<FlightBooking>(goInBookings);

            jsonFlugObject["Id"] = flighbuchungen->getId();
            jsonFlugObject["Ankunftdatum"] =QString::fromStdString(flighbuchungen->getFromdate());
            jsonFlugObject["Abreisedatum"] =QString::fromStdString(flighbuchungen->getFromdate());
            jsonFlugObject["StartFlughafen"] =QString::fromStdString(flighbuchungen->getFromDestination());
            jsonFlugObject["ZielFlughafen"] =QString::fromStdString(flighbuchungen->getToDestination());
            jsonFlugObject["Fluggeselschaft"] =QString::fromStdString(flighbuchungen->getAirline());
            jsonFlugObject["Price"] = flighbuchungen->getPrice();

            jsonBuchungenArray.push_back(jsonFlugObject);
        }
        if (typeid(*goInBookings)==typeid(Hotelbooking))
        {
            QJsonObject jsonHotelObject;
            shared_ptr<Hotelbooking>hotelBuchungen=std::dynamic_pointer_cast<Hotelbooking>(goInBookings);

            jsonHotelObject["Id"] = hotelBuchungen->getId();
            jsonHotelObject["Ankunftdatum"] =QString::fromStdString(hotelBuchungen->getFromdate());
            jsonHotelObject["Abreisedatum"] =QString::fromStdString(hotelBuchungen->getFromdate());
            jsonHotelObject["Stadt"] =QString::fromStdString(hotelBuchungen->getTown());
            jsonHotelObject["Hotel"] =QString::fromStdString(hotelBuchungen->getHotel());
            jsonHotelObject["Price"] = hotelBuchungen->getPrice();

            jsonBuchungenArray.push_back(jsonHotelObject);
        }
        if(typeid(*goInBookings)==typeid(RentalCarReservation))
        {
            QJsonObject jsonRentalCarObject;
            shared_ptr<RentalCarReservation>rentalcarbuchungen=std::dynamic_pointer_cast<RentalCarReservation>(goInBookings);

            jsonRentalCarObject["Id"] = rentalcarbuchungen->getId();
            jsonRentalCarObject["Ankunftdatum"] =QString::fromStdString(rentalcarbuchungen->getFromdate());
            jsonRentalCarObject["Abreisedatum"] =QString::fromStdString(rentalcarbuchungen->getToDate());
            jsonRentalCarObject["Pickuplocation"] =QString::fromStdString(rentalcarbuchungen->getPickupLocation());
            jsonRentalCarObject["returnLocATION"] =QString::fromStdString(rentalcarbuchungen->getReturnLocation());
            jsonRentalCarObject["cCompany"] =QString::fromStdString(rentalcarbuchungen->getCompany());
            jsonRentalCarObject["Price"] = rentalcarbuchungen->getPrice();

            jsonBuchungenArray.push_back(jsonRentalCarObject);

        }
    }
    QJsonObject alleBooking;//hier kann auch array drin sein ich maa alle array in diesem obj rein
    alleBooking["AlleBooking"]=jsonBuchungenArray;

    jsonGesamteBuchungen.push_back(alleBooking);//muss raus sein

    jsonDocument.setArray(jsonGesamteBuchungen);

    QFile datei (fileName);
    if (!datei.open(QIODevice::WriteOnly))
        std::cerr << "Datei konnte nicht geoeffnet werden";
    datei.write(jsonDocument.toJson());
    datei.close();

}
void MainWindow::on_actionJsonEinlesen_triggered()
{
    QString fileQstring= QFileDialog::getOpenFileName(this, "Select a file to open","C://Users//nilou//Documents//UpandawayuiPraktikum4");
    _travelagency->readjJsontfile(fileQstring);

}


void MainWindow::on_f_speichern_Button_clicked()
{
    //    void Hotelbooking::overWriteBooking(Booking *newBooking)
    //    {
    //        *this=*(static_cast<Hotelbooking*>(newBooking));
    //    }

    //    Booking* booking= new Flightbooking(id,price,travelId,fromDate,toDate,fromDestination,toDestination,airline);
    //    Booking* oldBooking=travelagency->findBooking(id);
    //    oldBooking->overWriteBooking(booking);

    long id= ui->id_f_lineedit->text().toLong();

    shared_ptr<Booking> oldBooking=_travelagency->findBooking(id);

    std::string fromDate= ui->startdatum_f_box->text().toStdString();
    std::string toDate= ui->Enddatum_f_box_2->text().toStdString();
    std::string fromDestination= ui->startflughafen_f_box->text().toStdString();
    std::string toDestination=ui->zielflughafen_lineedit->text().toStdString();
    std::string airline = ui->fluggeselschaft_lineedit->text().toStdString();
    double price = ui->price_f_box->text().toDouble();

    QPalette palette = ui->startflughafen_f_box->palette();
    ui->startflughafen_f_box->setPalette(palette);
    QString a=a.fromStdString(fromDestination);

    bool esgibt=_travelagency->findIata(a);

    if(!esgibt){
        ui->startflughafen_f_box->setText("Ungültiger Iata-Code!");
        palette.setColor(ui->startflughafen_f_box->foregroundRole(), Qt::red);
        ui->startflughafen_f_box->setPalette(palette);
        on_actionAlle_anzeigen_triggered();
    }else
    {
        palette.setColor(ui->startflughafen_f_box->foregroundRole(), Qt::black);
        ui->startflughafen_f_box->setPalette(palette);
        shared_ptr<FlightBooking>flightbooking=std::dynamic_pointer_cast<FlightBooking>(oldBooking);

        std::string from_airport=fromDestination;
        flightbooking->replaceBooking(flightbooking,fromDestination,toDestination,airline,fromDate,toDate,price);

        //flightbooking->setFromDestination(from_airport);//set neue wert

        QString fromDestination_name=_travelagency->airportMap.find(QString::fromStdString(fromDestination)).value()->getName();
        ui->startflughafen_f_box->setText(fromDestination_name);

       on_actionAlle_anzeigen_triggered();
    }

    QPalette palette1 = ui->zielflughafen_lineedit->palette();

    ui->zielflughafen_lineedit->setPalette(palette);
    if(!_travelagency->findIata(QString::fromStdString(toDestination))){
        ui->zielflughafen_lineedit->setText("Ungültiger Iata-Code!");
        palette.setColor(ui->zielflughafen_lineedit->foregroundRole(), Qt::red);
        ui->zielflughafen_lineedit->setPalette(palette);
    }else{
        palette.setColor(ui->zielflughafen_lineedit->foregroundRole(), Qt::black);
        ui->zielflughafen_lineedit->setPalette(palette);

        std::string to_airport=toDestination;
        shared_ptr<FlightBooking>flightbooking=std::dynamic_pointer_cast<FlightBooking>(oldBooking);

        flightbooking->setFromDestination(to_airport);

        QString toDestination_name=_travelagency->airportMap.find(QString::fromStdString(toDestination)).value()->getName();
        ui->zielflughafen_lineedit->setText(toDestination_name);

        on_actionAlle_anzeigen_triggered();
    }

}


void MainWindow::on_actionjsonSortierSpeichern_triggered()
{

    QMessageBox msgBox;
    msgBox.setWindowTitle("Sortierungsart");
    msgBox.setText("Waehlen Sie den Parameter, nach dem Ihre Buchung gespeichert werden sollen");
    msgBox.setInformativeText("Wie wollen Sie weiter vorgehen?");

    QPushButton* idSortButton = msgBox.addButton(tr("Id"),QMessageBox::ActionRole);
    QPushButton* priceSortButton = msgBox.addButton(tr("Price"),QMessageBox::ActionRole);
    QPushButton* fromDateSortButton = msgBox.addButton(tr("From Date"),QMessageBox::ActionRole);
    QPushButton* toDateSortButton = msgBox.addButton(tr("to Date"),QMessageBox::ActionRole);

    msgBox.exec();

    if(msgBox.clickedButton()==idSortButton)
    {
        _travelagency->sortBooking(SortFunktor::ID);
        jsonSortiertspeichern();
    }
    else if(msgBox.clickedButton()==priceSortButton)
    {
        _travelagency->sortBooking(SortFunktor::PRICE);
        jsonSortiertspeichern();
    }
    else if(msgBox.clickedButton()==fromDateSortButton){
        _travelagency->sortBooking(SortFunktor::FromDATE);
        jsonSortiertspeichern();
    }
    else if(msgBox.clickedButton()==toDateSortButton){
        _travelagency->sortBooking(SortFunktor::ToDATE);
        jsonSortiertspeichern();
    }
}


void MainWindow::on_actiontxtAlsJsonSpeichern_triggered()
{
    QString fileQstring= QFileDialog::getOpenFileName(this, "Select a file to open","C://Users//nilou//Documents//UpandawayuiPraktikum4");
   _travelagency->txtAlsJsonSpeichern(fileQstring.toStdString());

}


void MainWindow::on_actionalleBookingSortiertAlsJSon_triggered()
{

    QMessageBox msgBox;
    msgBox.setWindowTitle("Sortierungsart");
    msgBox.setText("Waehlen Sie den Parameter, nach dem Ihre Buchung gespeichert werden sollen");
    msgBox.setInformativeText("Wie wollen Sie weiter vorgehen?");

    QPushButton* idSortButton = msgBox.addButton(tr("Id"),QMessageBox::ActionRole);
    QPushButton* priceSortButton = msgBox.addButton(tr("Price"),QMessageBox::ActionRole);
    QPushButton* fromDateSortButton = msgBox.addButton(tr("From Date"),QMessageBox::ActionRole);
    QPushButton* toDateSortButton = msgBox.addButton(tr("to Date"),QMessageBox::ActionRole);

    msgBox.exec();

    if(msgBox.clickedButton()==idSortButton)
    {
        _travelagency->sortBooking(SortFunktor::ID);
        alleBookingSortiertAlsJSon();
    }
    else if(msgBox.clickedButton()==priceSortButton)
    {
        _travelagency->sortBooking(SortFunktor::PRICE);
        alleBookingSortiertAlsJSon();
    }
    else if(msgBox.clickedButton()==fromDateSortButton){
        _travelagency->sortBooking(SortFunktor::FromDATE);
        alleBookingSortiertAlsJSon();
    }
    else if(msgBox.clickedButton()==toDateSortButton){
        _travelagency->sortBooking(SortFunktor::ToDATE);
        alleBookingSortiertAlsJSon();
    }
}

