/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[40];
    char stringdata0[11];
    char stringdata1[32];
    char stringdata2[1];
    char stringdata3[33];
    char stringdata4[33];
    char stringdata5[41];
    char stringdata6[17];
    char stringdata7[5];
    char stringdata8[30];
    char stringdata9[32];
    char stringdata10[33];
    char stringdata11[36];
    char stringdata12[41];
    char stringdata13[4];
    char stringdata14[42];
    char stringdata15[30];
    char stringdata16[40];
    char stringdata17[32];
    char stringdata18[39];
    char stringdata19[46];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 31),  // "on_actionTextEinlesen_triggered"
        QT_MOC_LITERAL(43, 0),  // ""
        QT_MOC_LITERAL(44, 32),  // "on_actionAlle_anzeigen_triggered"
        QT_MOC_LITERAL(77, 32),  // "on_actionJsonSpeichern_triggered"
        QT_MOC_LITERAL(110, 40),  // "on_ausgabe_widget_list_itemDo..."
        QT_MOC_LITERAL(151, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(168, 4),  // "item"
        QT_MOC_LITERAL(173, 29),  // "on_actionAuswaehlen_triggered"
        QT_MOC_LITERAL(203, 31),  // "on_actionAlle_Anzeige_triggered"
        QT_MOC_LITERAL(235, 32),  // "on_actionAlle_Anzeigen_triggered"
        QT_MOC_LITERAL(268, 35),  // "on_kunden_suchen_pushButton_c..."
        QT_MOC_LITERAL(304, 40),  // "on_kunde_tabele_widget_cellDo..."
        QT_MOC_LITERAL(345, 3),  // "row"
        QT_MOC_LITERAL(349, 41),  // "on_travelId_tableWidget_cellD..."
        QT_MOC_LITERAL(391, 29),  // "on_f_speichern_Button_clicked"
        QT_MOC_LITERAL(421, 39),  // "on_actionjsonSortierSpeichern..."
        QT_MOC_LITERAL(461, 31),  // "on_actionJsonEinlesen_triggered"
        QT_MOC_LITERAL(493, 38),  // "on_actiontxtAlsJsonSpeichern_..."
        QT_MOC_LITERAL(532, 45)   // "on_actionalleBookingSortiertA..."
    },
    "MainWindow",
    "on_actionTextEinlesen_triggered",
    "",
    "on_actionAlle_anzeigen_triggered",
    "on_actionJsonSpeichern_triggered",
    "on_ausgabe_widget_list_itemDoubleClicked",
    "QListWidgetItem*",
    "item",
    "on_actionAuswaehlen_triggered",
    "on_actionAlle_Anzeige_triggered",
    "on_actionAlle_Anzeigen_triggered",
    "on_kunden_suchen_pushButton_clicked",
    "on_kunde_tabele_widget_cellDoubleClicked",
    "row",
    "on_travelId_tableWidget_cellDoubleClicked",
    "on_f_speichern_Button_clicked",
    "on_actionjsonSortierSpeichern_triggered",
    "on_actionJsonEinlesen_triggered",
    "on_actiontxtAlsJsonSpeichern_triggered",
    "on_actionalleBookingSortiertAlsJSon_triggered"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x08,    1 /* Private */,
       3,    0,  105,    2, 0x08,    2 /* Private */,
       4,    0,  106,    2, 0x08,    3 /* Private */,
       5,    1,  107,    2, 0x08,    4 /* Private */,
       8,    0,  110,    2, 0x08,    6 /* Private */,
       9,    0,  111,    2, 0x08,    7 /* Private */,
      10,    0,  112,    2, 0x08,    8 /* Private */,
      11,    0,  113,    2, 0x08,    9 /* Private */,
      12,    1,  114,    2, 0x08,   10 /* Private */,
      14,    1,  117,    2, 0x08,   12 /* Private */,
      15,    0,  120,    2, 0x08,   14 /* Private */,
      16,    0,  121,    2, 0x08,   15 /* Private */,
      17,    0,  122,    2, 0x08,   16 /* Private */,
      18,    0,  123,    2, 0x08,   17 /* Private */,
      19,    0,  124,    2, 0x08,   18 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_actionTextEinlesen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAlle_anzeigen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionJsonSpeichern_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ausgabe_widget_list_itemDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'on_actionAuswaehlen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAlle_Anzeige_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAlle_Anzeigen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_kunden_suchen_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_kunde_tabele_widget_cellDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_travelId_tableWidget_cellDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_f_speichern_Button_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionjsonSortierSpeichern_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionJsonEinlesen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actiontxtAlsJsonSpeichern_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionalleBookingSortiertAlsJSon_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_actionTextEinlesen_triggered(); break;
        case 1: _t->on_actionAlle_anzeigen_triggered(); break;
        case 2: _t->on_actionJsonSpeichern_triggered(); break;
        case 3: _t->on_ausgabe_widget_list_itemDoubleClicked((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 4: _t->on_actionAuswaehlen_triggered(); break;
        case 5: _t->on_actionAlle_Anzeige_triggered(); break;
        case 6: _t->on_actionAlle_Anzeigen_triggered(); break;
        case 7: _t->on_kunden_suchen_pushButton_clicked(); break;
        case 8: _t->on_kunde_tabele_widget_cellDoubleClicked((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->on_travelId_tableWidget_cellDoubleClicked((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 10: _t->on_f_speichern_Button_clicked(); break;
        case 11: _t->on_actionjsonSortierSpeichern_triggered(); break;
        case 12: _t->on_actionJsonEinlesen_triggered(); break;
        case 13: _t->on_actiontxtAlsJsonSpeichern_triggered(); break;
        case 14: _t->on_actionalleBookingSortiertAlsJSon_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
