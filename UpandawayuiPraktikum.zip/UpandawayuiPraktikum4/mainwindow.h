#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <travelagency.h>
#include <QListWidgetItem>
#include <QTableWidgetItem>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent,shared_ptr<Travelagency> travelagency);
    void travelTabWidgetNachTravelIdFuellen(int travelId);
    void BookingTabwidgetNacBookingIdFuellen(int bookinId);
    void flightBookingBoxInformationFuellen(shared_ptr<Booking> gesuchteBooking);
    void HotelBookingBoxInformationFuellen(shared_ptr<Booking> gesuchteBooking);
    void MietwagenBookingBoxInformationFuellen(shared_ptr<Booking> gesuchteBooking);

    void jsonSortiertspeichern();
    void alleBookingSortiertAlsJSon();

    ~MainWindow();

private slots:
    void on_actionTextEinlesen_triggered();
    void on_actionAlle_anzeigen_triggered();
    void on_actionJsonSpeichern_triggered();
    void on_ausgabe_widget_list_itemDoubleClicked(QListWidgetItem *item);
    void on_actionAuswaehlen_triggered();
    void on_actionAlle_Anzeige_triggered();
    void on_actionAlle_Anzeigen_triggered();
    void on_kunden_suchen_pushButton_clicked();
    void on_kunde_tabele_widget_cellDoubleClicked(int row);
    void on_travelId_tableWidget_cellDoubleClicked(int row);
    void on_f_speichern_Button_clicked();
    void on_actionjsonSortierSpeichern_triggered();
    void on_actionJsonEinlesen_triggered();
    void on_actiontxtAlsJsonSpeichern_triggered();

    void on_actionalleBookingSortiertAlsJSon_triggered();

private:
    Ui::MainWindow *ui;
    shared_ptr<Travelagency> _travelagency=shared_ptr<Travelagency>();
};
#endif // MAINWINDOW_H
