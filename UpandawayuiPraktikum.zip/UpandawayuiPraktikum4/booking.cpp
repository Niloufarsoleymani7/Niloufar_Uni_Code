#include "booking.h"
#include <iostream>
#include <bits/stdc++.h>
#include <sstream>
#include <time.h>

Booking::Booking(int id, const std::string &fromdate, const std::string &toDate, double price,int travelId) : _id(id),
    _travelId(travelId),
    _price(price),
    _fromdate(fromdate),
    _toDate(toDate){}

int Booking::getId() const
{
    return _id;
}

std::string Booking::getcreatedDate(std::string &todate)
{
    std::string jahr{},monat{},tag{};

    jahr=todate.substr(0,4);//von hier bis hier soviel will ich nehmen
    monat=todate.substr(4,2);
    tag=todate.substr(6,2);

    return tag+"."+monat+"."+jahr;
}

double Booking::getPrice() const
{
    return _price;
}

const std::string &Booking::getFromdate() const
{
    return _fromdate;
}

void Booking::setFromdate(const std::string &newFromdate)
{
    _fromdate = newFromdate;
}

const std::string &Booking::getToDate() const
{
    return _toDate;
}

void Booking::setToDate(const std::string &newToDate)
{
    _toDate = newToDate;
}

int Booking::getTravelId() const
{
    return _travelId;
}

Booking::~Booking()
{ }

void Booking::setPrice(double newPrice)
{
    _price = newPrice;
}

void Booking::setTravelId(int newTravelId)
{
    _travelId = newTravelId;
}
