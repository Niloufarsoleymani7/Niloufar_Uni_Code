#ifndef HOTELBOOKING_H
#define HOTELBOOKING_H
#include "booking.h"

class Hotelbooking :public Booking
{
public:
    Hotelbooking(const std::string &hotel, const std::string &town, int id, const std::string &fromdate, const std::string &toDate, double price,int travelId);

    std::string showDetails() override;


    ~Hotelbooking();

    const std::string &getHotel() const;
    void setHotel(const std::string &newHotel);
    const std::string &getTown() const;
    void setTown(const std::string &newTown);

private:

    std::string _hotel{};
    std::string _town {};

};

#endif // HOTELBOOKING_H
