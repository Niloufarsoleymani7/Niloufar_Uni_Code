#include "travelagency.h"
#include "qjsonarray.h"
#include "qjsondocument.h"
#include "qjsonobject.h"
#include "qjsonvalue.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <flightbooking.h>
#include <hotelbooking.h>
#include <rentalcarreservation.h>
#include <memory>
#include <QFile>

using std::cout;
using std::endl;
using std::make_shared;

Travelagency::Travelagency()
{}

void Travelagency::readtextfile1(std::string ausgewaehltedatei)
{
    std::fstream bookingFile;
    std::string leseAllZeilInFile;
    std::string dateiname{};

    bookingFile.open(ausgewaehltedatei, std::ios::in);
    if(!bookingFile)
    {
        throw std::invalid_argument("Datei kann nicht geoffnet wreden!");
    }

    while(std::getline(bookingFile,leseAllZeilInFile))
    {
        if(leseAllZeilInFile.empty())
        {
            break;
        }
        std::stringstream leseBuchstabenInZeil;

        leseBuchstabenInZeil << leseAllZeilInFile;//fagat mikhune jayi save nist
        int anzahlBuchstabenInZeil =0;

        //anzahl buchstaben in zeil
        for (unsigned int i=0;i<leseAllZeilInFile.size();i++)
        {
            if(leseAllZeilInFile[i]=='|')
                anzahlBuchstabenInZeil++;
        }

        std::string step1{},step2{},step3{},
        step4{},step5{},step6{},step7,step9{},step8{},step10{},step11{};

        std::getline(leseBuchstabenInZeil,step1,'|');//um den typ wegzulassen
        std::getline(leseBuchstabenInZeil,step2,'|');//1 id
        std::getline(leseBuchstabenInZeil,step3,'|');//2 price
        std::getline(leseBuchstabenInZeil,step4,'|');//3 fromdate
        std::getline(leseBuchstabenInZeil,step5,'|');//4 todate
        std::getline(leseBuchstabenInZeil,step6,'|');// booking travelid  travel id
        std::getline(leseBuchstabenInZeil,step7,'|');//customer id   travel customerid
        std::getline(leseBuchstabenInZeil,step8,'|');// customer name
        std::getline(leseBuchstabenInZeil,step9,'|');//5 fromFlug or hotel or pickuplocation
        std::getline(leseBuchstabenInZeil,step10,'|');//6 zielflug or townHotel or returnLocation
        std::getline(leseBuchstabenInZeil,step11,'|');//7 flugLinie or CompanyCar
        //f,r=10  h=9

        int bookingId=std::stoi(step2);
        int travelId=std::stoi(step6);
        int customerId =std::stoi(step7);
        double price {};

        //find costumer
        shared_ptr<Customer> customer;
        if(findCustomer(customerId)==nullptr)
        {
            customer = make_shared <Customer>(customerId,step8);
            _customers.push_back(customer);
        }
        else
        {
            customer=findCustomer(customerId);
        }


        if(!is_number(step3))
        {
            throw std::runtime_error("In der zeile "+std::to_string(_bookings.size()+1)+" ist der price  keine Zahl");
        }
        else
        {
            price=std::stof(step3);
        }

        if(step1=="F")
        {
            if(anzahlBuchstabenInZeil!=10)
            {
                throw std::runtime_error("In der zeile "+std::to_string(_bookings.size()+1)+" zu wenige oder zu viele Attribute");
            }
            if(step9.size() == 3 and step10.size() == 3)//start and ziel
            {
                if(findBooking(bookingId)==nullptr)
                {
                    shared_ptr<FlightBooking> flightBooking= make_shared<FlightBooking>(step9,step10,step11,bookingId,step4,step5,price,travelId);
                    _bookings.push_back(flightBooking);

                    if(findTravel(travelId)==nullptr)
                    {
                        shared_ptr<Travel>travel=make_shared<Travel>(travelId,customerId,customer);
                        _travels.push_back(travel);
                        setBookingForTravel(travelId,flightBooking);
                        settravelForCustomer(customerId,travel);
                    }
                    else
                    {
                        setBookingForTravel(travelId,flightBooking);
                    } } }
            else
            {
                throw std::runtime_error("Es gibt ein  falsches Flughafenkuerzel in der zeile "+std::to_string(_bookings.size()+1));
            }
        }


        else if(step1=="H")
        {
            if(anzahlBuchstabenInZeil!=9)
            {
                throw std::runtime_error("In der zeile "+std::to_string(_bookings.size()+1) +" zu wenige oder zu viele Attribute in der Textdatei (H Typ) ");
            }

            if(findBooking(bookingId)==nullptr)
            {
                shared_ptr<Hotelbooking> hotelBooking=make_shared<Hotelbooking>(step9,step10,bookingId,step4,step5,price,travelId);
                _bookings.push_back(hotelBooking);

                if(findTravel(travelId)==nullptr)
                {
                   shared_ptr<Travel> travel=make_shared<Travel>(travelId,customerId,customer);
                    _travels.push_back(travel);
                    setBookingForTravel(travelId,hotelBooking);
                    settravelForCustomer(customerId,travel);
                }
                else
                {
                    setBookingForTravel(travelId,hotelBooking);
                } } }


        else
        {
            if(anzahlBuchstabenInZeil!=10)
            {
                throw std::runtime_error("In der zeile "+std::to_string(_bookings.size()+1) +" zu wenige oder zu viele Attribute in der Textdatei (R Typ) ");
            }
            else
            {
                if(findBooking(bookingId)==nullptr)
                {
                    shared_ptr<RentalCarReservation>mietwagen=make_shared<RentalCarReservation>(step9,step10,step11,bookingId,step4,step5,price,travelId);
                    _bookings.push_back(mietwagen);

                    if(findTravel(travelId)==nullptr)
                    {
                        shared_ptr<Travel> travel=make_shared<Travel>(travelId,customerId,customer);
                        _travels.push_back(travel);
                        setBookingForTravel(travelId,mietwagen);
                        settravelForCustomer(customerId,travel);
                    }
                    else
                    {
                        setBookingForTravel(travelId,mietwagen);
                    } } } } }

    bookingFile.close();
}

void Travelagency::readjJsontfile(QString ausgewaehltedatei)
{
    QFile file(ausgewaehltedatei);
    file.open(QIODevice::ReadOnly);
    QString geleseneDaten=file.readAll();
    QJsonDocument document=QJsonDocument::fromJson(geleseneDaten.toUtf8());

    for(int i=0; i<document.array().size();i++)
    {
        //q_obj=q_doc.array()[i].toObject();
        QJsonObject object=document.array().at(i).toObject();

        QJsonValue value=object.value("name");
        QString name=value.toString();

        value=object.value("iso_country");
        QString country=value.toString();

        value=object.value("municipality");
        QString city=value.toString();

        //q_obj=q_doc.array()[i].toObject();
        value=object.value("iata_code");
        QString iata=value.toString();
        //ap->setIata(iata);

        //shared_ptr<Flughafen> ap = shared_ptr<Flughafen> (new Fluhafen(name, country, city, iata));

        shared_ptr<Flughafen> result = std::make_shared<Flughafen>(name, country, city, iata);
        airportMap[iata]=result;
        //airportMap.insert(iata, result);

        //QMap<key,value>;
        //map[key]=value;
    }

}

void Travelagency::txtAlsJsonSpeichern(std::string ausgewaehltedatei)
{
    std::string line;
    std::ifstream datei;
    datei.open(ausgewaehltedatei, std::ios::in);

    if (!datei) { // Fehlerabfrage
       cout<<"Datei kann nicht geoeffnet werden!";

    }

    std::stringstream lineStream;
    std::string stp1 , stp2 , stp3 , stp4 , stp5 , stp6 , stp7 , stp8;

    QJsonDocument jsonDocument;
    QJsonArray jsonArrayBuchungen;
    QJsonArray jsonArrayFlugBuchungen;
    QJsonArray jsonArrayHotelBuchungen;
    QJsonArray jsonArrayCarBuchungen;
    QJsonObject flugbuchungen_o;
    QJsonObject mietwagen_o;
    QJsonObject hotel_o;
    QJsonObject jsonArrayTitle;

    while (getline(datei, line)){
        if (line.empty()){ // si la ligne est vide (la fin du fichier)
            break;
        }
        lineStream.clear();
        lineStream<<line;
        getline(lineStream , stp1 , '|'); // type R , F, H
        getline(lineStream , stp2 , '|'); // ID
        getline(lineStream , stp3 , '|'); // price
        getline(lineStream , stp4 , '|'); //fromDate
        getline(lineStream , stp5 , '|'); //toDate
        getline(lineStream , stp6 , '|'); //fromFlug or hotel or pickuplocation
        getline(lineStream , stp7 , '|'); //zielflug or townHotel or returnLocation
        getline(lineStream , stp8 , '|'); //flugLinie or CompanyCar

        int id = stoi(stp2); //convertir de string  vers int
        double preis = stof(stp3); //convetir de string vers double


        if(stp1 == "F"){

            QJsonObject jsonObjektFlugBuchung;

            jsonObjektFlugBuchung ["airline"]= QString::fromStdString(stp8);
            jsonObjektFlugBuchung ["fromDate"]= QString::fromStdString(stp4);
            jsonObjektFlugBuchung ["fromDest"]= QString::fromStdString(stp6);
            jsonObjektFlugBuchung ["id"]= id;
            jsonObjektFlugBuchung ["price"]= preis;
            jsonObjektFlugBuchung ["toDate"]= QString::fromStdString(stp5);
            jsonObjektFlugBuchung ["toDest"]= QString::fromStdString(stp7);

            jsonArrayFlugBuchungen.push_back(jsonObjektFlugBuchung);

        }

        else if(stp1 == "H")
        {

            QJsonObject jsonObjektHotelBuchung;

            jsonObjektHotelBuchung ["fromDate"]= QString::fromStdString(stp4);
            jsonObjektHotelBuchung ["hotel"]= QString::fromStdString(stp6);
            jsonObjektHotelBuchung ["id"]= id;
            jsonObjektHotelBuchung ["price"]= preis;
            jsonObjektHotelBuchung ["toDate"]= QString::fromStdString(stp5);
            jsonObjektHotelBuchung ["town"]= QString::fromStdString(stp7);


            jsonArrayHotelBuchungen.push_back(jsonObjektHotelBuchung);
        }

        else if(stp1 == "R")
        {

            QJsonObject jsonObjektCarBuchung;

            jsonObjektCarBuchung ["company"]= QString::fromStdString(stp8);
            jsonObjektCarBuchung ["fromDate"]= QString::fromStdString(stp4);
            jsonObjektCarBuchung ["id"]= id;
            jsonObjektCarBuchung ["pickupLocation"]= QString::fromStdString(stp6);
            jsonObjektCarBuchung ["price"]= preis;
            jsonObjektCarBuchung ["returnLocation"]= QString::fromStdString(stp7);
            jsonObjektCarBuchung ["toDate"]= QString::fromStdString(stp5);



            jsonArrayCarBuchungen.push_back(jsonObjektCarBuchung);
        }

    }

    flugbuchungen_o["FlugBuchung"]=jsonArrayFlugBuchungen;
    hotel_o["HotelBuchung"]=jsonArrayHotelBuchungen;
    mietwagen_o["CarReserviereungen"]=jsonArrayCarBuchungen;


    jsonArrayBuchungen.push_back(flugbuchungen_o);
    jsonArrayBuchungen.push_back(hotel_o);
    jsonArrayBuchungen.push_back(mietwagen_o);

    jsonDocument.setArray(jsonArrayBuchungen);

    QString dateiNm="buchungen2.json";
    QFile jsondatei(dateiNm);//dateiname
    if(!jsondatei.open(QIODevice::WriteOnly))
        cout<<"json Datei konnte nicht geoeffnetwerden";
    jsondatei.write(jsonDocument.toJson());
    datei.close();


}


std::string Travelagency::gettextfileinfoForPg2()
{
    int anzahlFluege{},anzahlHotels{},anzahlMietwagen{};

    for(auto go:_bookings)
    {
        if(typeid(*go)==typeid(FlightBooking))
        {
            gesamtFlugBetrag=gesamtHotelBetrag+go->getPrice();
            anzahlFluege++;
        }
        if (typeid(*go)==typeid(Hotelbooking))
        {
            gesamtHotelBetrag=gesamtHotelBetrag+go->getPrice();
            anzahlHotels++;
        }
        if(typeid(*go)==typeid(RentalCarReservation))
        {
            gesamtMietwagenBetrag=gesamtMietwagenBetrag+go->getPrice();
            anzahlMietwagen++;}
    }

    double gesamtumsatz=gesamtMietwagenBetrag+gesamtFlugBetrag+gesamtHotelBetrag;
    int reisenAnzahl{},buchungenAnzahl{};

    for(size_t i=0;i<_customers.size();i++)
    {
        if(_customers.at(i)->getId()==1)
        {
            reisenAnzahl=_customers.at(i)->getTravelList().size();
        }

    }
    for (size_t var = 0; var < _travels.size(); var++)
    {
        if(_travels.at(var)->getId()==17)
        {
            buchungenAnzahl=_travels.at(var)->getTravelBookings().size();
        }
    }
    return "Es wurden insgesamt "+std::to_string(_bookings.size())+" Buchungen eingelesen, Davon:\n"
            +std::to_string(anzahlFluege)+" Flugbuchungen\n"+std::to_string(anzahlHotels)+" Hotelbuchungen\n"+std::to_string(anzahlMietwagen)+" Autobuchungen\nGesamtwert: "
            +std::to_string(gesamtumsatz)+" Euro\nEs wurden "+std::to_string(_travels.size())+" Reisen und "
            +std::to_string(_customers.size())+" Kunden angelegt.\nDer Kunde mit der ID 1 hat "+std::to_string(reisenAnzahl)+
            " Reisen gebucht.\nZur Reise mit der ID 17 gehören "+ std::to_string(buchungenAnzahl)+" Buchungen.";

}

shared_ptr<Booking> Travelagency::findBooking(int id)
{
    for(auto goInBooking:_bookings)
    {
        if(goInBooking->getId()==id)
        {
            return goInBooking;
        }
    }
    return nullptr;
}

shared_ptr<Travel> Travelagency::findTravel(int id)
{
    for(auto goInTravels:_travels)
    {
        if(goInTravels->getId()==id)
        {
            return goInTravels;
        }
    }
    return nullptr;

}

shared_ptr<Customer>Travelagency::findCustomer(int id)
{
    for(auto goInCustomers:_customers)
    {
        if(goInCustomers->getId()==id)
        {
            return goInCustomers;
        }
    }
    return nullptr;
}

void Travelagency::delteBooking()
{
//    for(auto goInBooking:_bookings)
//    {
//        delete goInBooking;
//    }

    _bookings.clear();//nanivisam pak nemishe va doppelt booking daram

}


double Travelagency::getGesamtFlugBetrag()
{
    return gesamtFlugBetrag;
}

double Travelagency::getGesamtHotelBetrag()
{
    return gesamtHotelBetrag;
}

double Travelagency::getGesamtMietwagenBetrag()
{
    return gesamtMietwagenBetrag;
}

std::string Travelagency::showbookings()
{
    std::string allebuchungen{};
    for(auto goInBookings:_bookings)
    {
        allebuchungen=allebuchungen+goInBookings->showDetails();
    }
    return allebuchungen;
}

bool Travelagency::is_number(const std::string &s)
{
    long double ld;

    return (std::istringstream(s) >> ld >> std::ws).eof();
}

const std::vector<shared_ptr<Booking>> &Travelagency::getBookings() const
{
    return _bookings;
}

Travelagency::~Travelagency()
{/*
    for(auto goInBooking:_bookings)
    {
        delete goInBooking;
    }*/
}

const std::vector<shared_ptr<Customer>> &Travelagency::getCustomers() const
{
    return _customers;
}

const std::vector<shared_ptr<Travel>> &Travelagency::getTravels() const
{
    return _travels;
}

void Travelagency::setBookingForTravel(int id, shared_ptr<Booking>booking)
{
    for(auto goIntravels:_travels){
        if(goIntravels->getId()==id)
        {
            goIntravels->addBooking(booking);
        }
    }
}

void Travelagency::settravelForCustomer(int id,shared_ptr<Travel> travel)
{
    for(auto goInCustomers:_customers)
    {
        if(goInCustomers->getId()==id)
        {
            goInCustomers->addTravel(travel);
        }
    }
}

bool Travelagency::findIata(QString iataName)
{
    //kolle hameye keyha tu ye list
    QList<QString> iataListen=airportMap.keys();//weil es qstring ist musss man in einem container speichern
    for(auto& goInIataListen:iataListen)
    {
        if(goInIataListen==iataName)
        {
            return true;
        }
    }
    //airportMap.contains("FRA"); aya hast ya nist

    return false;

}

void Travelagency::sortBooking(SortFunktor::SortierParameter mode)
{
     std::sort(_bookings.begin(),_bookings.end(),SortFunktor(mode));//sortfunktor vergleichobject
}


















