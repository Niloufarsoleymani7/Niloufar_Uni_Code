#include "test.h"

Test::Test(shared_ptr<Travelagency> travelagency,QObject *parent)
    : QObject{parent},_travelagency(travelagency)
{
    _travelagency->readtextfile1(datei);
    testmietwagen();
    testFlugbuchung();
    testbuchungwert();
}

void Test::testmietwagen()
{
    int ergebnis{};
    for(auto goInbooking:_travelagency->getBookings()){
        if(typeid(*goInbooking)==typeid(RentalCarReservation))
        {
            shared_ptr<RentalCarReservation>rentalcarbuchungen=std::dynamic_pointer_cast<RentalCarReservation>(goInbooking);
            if(rentalcarbuchungen->getCompany()=="Avis")
                 {ergebnis++;}
        }
    }
    QCOMPARE(ergebnis,5);
}

void Test::testFlugbuchung()
{
    int ergebnis{};
    for(auto goInbooking:_travelagency->getBookings()){
        if(typeid(*goInbooking)==typeid(FlightBooking))
        {
            shared_ptr<FlightBooking>rentalcarbuchungen=std::dynamic_pointer_cast<FlightBooking>(goInbooking);
            if(rentalcarbuchungen->getAirline()=="United Airlines")
                 {ergebnis++;}
        }
    }
    QCOMPARE(ergebnis,3);
}

void Test::testbuchungwert()
{
    int ergebnis{};
    for(auto goInbooking:_travelagency->getBookings()){
            if(goInbooking->getPrice()>=1000)
                 {ergebnis++;}
    }
    QCOMPARE(ergebnis,31);
}
