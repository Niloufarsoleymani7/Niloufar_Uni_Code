#include "flightbooking.h"
#include "travel.h"

FlightBooking::FlightBooking(const std::string &fromDestination, const std::string &toDestination, const std::string &airline, int id,
                             const std::string &fromdate, const std::string &toDate, double price,int travelId) :
    Booking(id, fromdate, toDate, price,travelId),
    _fromDestination(fromDestination),
    _toDestination(toDestination),
    _airline(airline)
{}

std::string FlightBooking::showDetails()
{
    using std::to_string;
        std::string bookinginfo = "Flugbuchung "+ to_string(getId())+" von "+ getFromDestination()+ " nach "+ getToDestination()+
                " mit "+ getAirline()+ " am "+ getcreatedDate(_fromdate)+ " Preis: " +to_string(getPrice())+ " Euro.";
        return bookinginfo+"\n";
}

void FlightBooking::replaceBooking(std::shared_ptr<FlightBooking> flighbuchung, std::string &fromDestination,
                                   std::string &toDestination, std::string &airline, std::string &fromdate,
                                   std::string &toDate, double price)
{
    std::string jahr{},monat{},tag{};
    //04/01/2015
    tag=fromdate.substr(0,2);//von hier bis hier soviel will ich nehmen
    monat=fromdate.substr(3,2);
    jahr=fromdate.substr(6,4);
    //eyne gabli bashe
    fromdate= jahr+monat+tag;

    flighbuchung->setFromDestination(fromDestination);
    flighbuchung->setToDestination(toDestination);
    flighbuchung->setAirline(airline);
    flighbuchung->setFromdate(fromdate);
    flighbuchung->setToDate(toDate);
    flighbuchung->setPrice(price);

}


const std::string &FlightBooking::getFromDestination() const
{
    return _fromDestination;
}

void FlightBooking::setFromDestination(const std::string &newFromDestination)
{
    _fromDestination = newFromDestination;
}

const std::string &FlightBooking::getToDestination() const
{
    return _toDestination;
}

void FlightBooking::setToDestination(const std::string &newToDestination)
{
    _toDestination = newToDestination;
}

const std::string &FlightBooking::getAirline() const
{
    return _airline;
}

void FlightBooking::setAirline(const std::string &newAirline)
{
    _airline = newAirline;
}

FlightBooking::~FlightBooking()
{  }
