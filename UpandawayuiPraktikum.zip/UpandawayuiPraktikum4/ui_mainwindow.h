/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionTextEinlesen;
    QAction *actionAuswaehlen;
    QAction *actionAlle_anzeigen;
    QAction *actionJsonSpeichern;
    QAction *actionAlle_Anzeige;
    QAction *actionAlle_Anzeigen;
    QAction *actionJsonEinlesen;
    QAction *actionjsonSortierSpeichern;
    QAction *actiontxtAlsJsonSpeichern;
    QAction *actionalleBookingSortiertAlsJSon;
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_7;
    QTabWidget *tabwidget;
    QWidget *FlightbuchungTab;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_9;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *id_f_label;
    QLabel *Startdatum_f_label;
    QLabel *Enddatum_f_label;
    QLabel *NameVonFlugHafen_startflughafen_label;
    QLabel *startflughafen_label;
    QLabel *NameVonFlugHafen_endflughafen_label;
    QLabel *Zielflughafen_label;
    QLabel *Flugesekschaft_label;
    QLabel *Preis_f_label;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *id_f_lineedit;
    QDateEdit *startdatum_f_box;
    QDateEdit *Enddatum_f_box_2;
    QLineEdit *namevonflughafen_startflughafen_f_box;
    QLineEdit *startflughafen_f_box;
    QLineEdit *namevonflughafen_endflughafen_f_box;
    QLineEdit *zielflughafen_lineedit;
    QLineEdit *fluggeselschaft_lineedit;
    QSpinBox *price_f_box;
    QPushButton *f_speichern_Button;
    QWidget *hotelTab;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *Id_h_label;
    QLabel *Startdatum_h_label;
    QLabel *Enddatum_h_label;
    QLabel *Hotel_h_label;
    QLabel *Stadt_h_label;
    QLabel *price_h_box;
    QVBoxLayout *verticalLayout_6;
    QLineEdit *id_h_lineedit;
    QDateEdit *startdatum_h_box;
    QDateEdit *enddatum_h_box;
    QLineEdit *hotel_h_lineedit;
    QLineEdit *stadt_h_lineedit;
    QSpinBox *preis_h_box;
    QWidget *MietwagenTab;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *Id_m_label;
    QLabel *Pickuplocation_m_label;
    QLabel *returnlocation_m_label;
    QLabel *Ankunftdatum_m_label;
    QLabel *AbreiseDatum_m_label;
    QLabel *Compan_m_label;
    QLabel *Id_m_label_6;
    QVBoxLayout *verticalLayout_5;
    QLineEdit *id_m_lineedit;
    QLineEdit *pickuplocation_m_lineedit;
    QLineEdit *returnlocation_m_lineedit;
    QDateEdit *Ankunft_m_lineedit;
    QDateEdit *Abreise_m_lineedit;
    QLineEdit *company_m_lineedit;
    QSpinBox *preis_m_box;
    QWidget *tab_3;
    QLineEdit *kundenName_lineEdit;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_5;
    QHBoxLayout *horizontalLayout_4;
    QLabel *Kunden_id_label;
    QLineEdit *Kunden_id_lineedit;
    QPushButton *kunden_suchen_pushButton;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_6;
    QTableWidget *travelId_tableWidget;
    QTableWidget *kunde_tabele_widget;
    QListWidget *ausgabe_widget_list;
    QStatusBar *statusbar;
    QMenuBar *menubar;
    QMenu *menuDatei;
    QMenu *menuBuchungen;
    QMenu *menuReise;
    QMenu *menuKunde;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1569, 891);
        actionTextEinlesen = new QAction(MainWindow);
        actionTextEinlesen->setObjectName("actionTextEinlesen");
        actionAuswaehlen = new QAction(MainWindow);
        actionAuswaehlen->setObjectName("actionAuswaehlen");
        actionAlle_anzeigen = new QAction(MainWindow);
        actionAlle_anzeigen->setObjectName("actionAlle_anzeigen");
        actionJsonSpeichern = new QAction(MainWindow);
        actionJsonSpeichern->setObjectName("actionJsonSpeichern");
        actionAlle_Anzeige = new QAction(MainWindow);
        actionAlle_Anzeige->setObjectName("actionAlle_Anzeige");
        actionAlle_Anzeigen = new QAction(MainWindow);
        actionAlle_Anzeigen->setObjectName("actionAlle_Anzeigen");
        actionJsonEinlesen = new QAction(MainWindow);
        actionJsonEinlesen->setObjectName("actionJsonEinlesen");
        actionjsonSortierSpeichern = new QAction(MainWindow);
        actionjsonSortierSpeichern->setObjectName("actionjsonSortierSpeichern");
        actiontxtAlsJsonSpeichern = new QAction(MainWindow);
        actiontxtAlsJsonSpeichern->setObjectName("actiontxtAlsJsonSpeichern");
        actionalleBookingSortiertAlsJSon = new QAction(MainWindow);
        actionalleBookingSortiertAlsJSon->setObjectName("actionalleBookingSortiertAlsJSon");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(20, 0, 611, 499));
        verticalLayout_7 = new QVBoxLayout(layoutWidget);
        verticalLayout_7->setObjectName("verticalLayout_7");
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        tabwidget = new QTabWidget(layoutWidget);
        tabwidget->setObjectName("tabwidget");
        FlightbuchungTab = new QWidget();
        FlightbuchungTab->setObjectName("FlightbuchungTab");
        layoutWidget1 = new QWidget(FlightbuchungTab);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(10, 10, 581, 431));
        verticalLayout_9 = new QVBoxLayout(layoutWidget1);
        verticalLayout_9->setObjectName("verticalLayout_9");
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName("verticalLayout_3");
        id_f_label = new QLabel(layoutWidget1);
        id_f_label->setObjectName("id_f_label");

        verticalLayout_3->addWidget(id_f_label);

        Startdatum_f_label = new QLabel(layoutWidget1);
        Startdatum_f_label->setObjectName("Startdatum_f_label");

        verticalLayout_3->addWidget(Startdatum_f_label);

        Enddatum_f_label = new QLabel(layoutWidget1);
        Enddatum_f_label->setObjectName("Enddatum_f_label");

        verticalLayout_3->addWidget(Enddatum_f_label);

        NameVonFlugHafen_startflughafen_label = new QLabel(layoutWidget1);
        NameVonFlugHafen_startflughafen_label->setObjectName("NameVonFlugHafen_startflughafen_label");

        verticalLayout_3->addWidget(NameVonFlugHafen_startflughafen_label);

        startflughafen_label = new QLabel(layoutWidget1);
        startflughafen_label->setObjectName("startflughafen_label");

        verticalLayout_3->addWidget(startflughafen_label);

        NameVonFlugHafen_endflughafen_label = new QLabel(layoutWidget1);
        NameVonFlugHafen_endflughafen_label->setObjectName("NameVonFlugHafen_endflughafen_label");

        verticalLayout_3->addWidget(NameVonFlugHafen_endflughafen_label);

        Zielflughafen_label = new QLabel(layoutWidget1);
        Zielflughafen_label->setObjectName("Zielflughafen_label");

        verticalLayout_3->addWidget(Zielflughafen_label);

        Flugesekschaft_label = new QLabel(layoutWidget1);
        Flugesekschaft_label->setObjectName("Flugesekschaft_label");

        verticalLayout_3->addWidget(Flugesekschaft_label);

        Preis_f_label = new QLabel(layoutWidget1);
        Preis_f_label->setObjectName("Preis_f_label");

        verticalLayout_3->addWidget(Preis_f_label);


        horizontalLayout_3->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName("verticalLayout_4");
        id_f_lineedit = new QLineEdit(layoutWidget1);
        id_f_lineedit->setObjectName("id_f_lineedit");
        id_f_lineedit->setEnabled(false);

        verticalLayout_4->addWidget(id_f_lineedit);

        startdatum_f_box = new QDateEdit(layoutWidget1);
        startdatum_f_box->setObjectName("startdatum_f_box");
        startdatum_f_box->setEnabled(true);
        startdatum_f_box->setDate(QDate(1999, 1, 1));

        verticalLayout_4->addWidget(startdatum_f_box);

        Enddatum_f_box_2 = new QDateEdit(layoutWidget1);
        Enddatum_f_box_2->setObjectName("Enddatum_f_box_2");
        Enddatum_f_box_2->setEnabled(true);
        Enddatum_f_box_2->setDate(QDate(1999, 1, 1));

        verticalLayout_4->addWidget(Enddatum_f_box_2);

        namevonflughafen_startflughafen_f_box = new QLineEdit(layoutWidget1);
        namevonflughafen_startflughafen_f_box->setObjectName("namevonflughafen_startflughafen_f_box");
        namevonflughafen_startflughafen_f_box->setEnabled(false);

        verticalLayout_4->addWidget(namevonflughafen_startflughafen_f_box);

        startflughafen_f_box = new QLineEdit(layoutWidget1);
        startflughafen_f_box->setObjectName("startflughafen_f_box");
        startflughafen_f_box->setEnabled(true);

        verticalLayout_4->addWidget(startflughafen_f_box);

        namevonflughafen_endflughafen_f_box = new QLineEdit(layoutWidget1);
        namevonflughafen_endflughafen_f_box->setObjectName("namevonflughafen_endflughafen_f_box");
        namevonflughafen_endflughafen_f_box->setEnabled(false);

        verticalLayout_4->addWidget(namevonflughafen_endflughafen_f_box);

        zielflughafen_lineedit = new QLineEdit(layoutWidget1);
        zielflughafen_lineedit->setObjectName("zielflughafen_lineedit");
        zielflughafen_lineedit->setEnabled(true);

        verticalLayout_4->addWidget(zielflughafen_lineedit);

        fluggeselschaft_lineedit = new QLineEdit(layoutWidget1);
        fluggeselschaft_lineedit->setObjectName("fluggeselschaft_lineedit");
        fluggeselschaft_lineedit->setEnabled(true);

        verticalLayout_4->addWidget(fluggeselschaft_lineedit);

        price_f_box = new QSpinBox(layoutWidget1);
        price_f_box->setObjectName("price_f_box");
        price_f_box->setEnabled(true);
        price_f_box->setMaximum(1000000);
        price_f_box->setStepType(QAbstractSpinBox::DefaultStepType);

        verticalLayout_4->addWidget(price_f_box);


        horizontalLayout_3->addLayout(verticalLayout_4);


        verticalLayout_9->addLayout(horizontalLayout_3);

        f_speichern_Button = new QPushButton(layoutWidget1);
        f_speichern_Button->setObjectName("f_speichern_Button");

        verticalLayout_9->addWidget(f_speichern_Button);

        tabwidget->addTab(FlightbuchungTab, QString());
        hotelTab = new QWidget();
        hotelTab->setObjectName("hotelTab");
        layoutWidget2 = new QWidget(hotelTab);
        layoutWidget2->setObjectName("layoutWidget2");
        layoutWidget2->setGeometry(QRect(10, 10, 551, 441));
        verticalLayout_10 = new QVBoxLayout(layoutWidget2);
        verticalLayout_10->setObjectName("verticalLayout_10");
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        Id_h_label = new QLabel(layoutWidget2);
        Id_h_label->setObjectName("Id_h_label");

        verticalLayout->addWidget(Id_h_label);

        Startdatum_h_label = new QLabel(layoutWidget2);
        Startdatum_h_label->setObjectName("Startdatum_h_label");

        verticalLayout->addWidget(Startdatum_h_label);

        Enddatum_h_label = new QLabel(layoutWidget2);
        Enddatum_h_label->setObjectName("Enddatum_h_label");

        verticalLayout->addWidget(Enddatum_h_label);

        Hotel_h_label = new QLabel(layoutWidget2);
        Hotel_h_label->setObjectName("Hotel_h_label");

        verticalLayout->addWidget(Hotel_h_label);

        Stadt_h_label = new QLabel(layoutWidget2);
        Stadt_h_label->setObjectName("Stadt_h_label");

        verticalLayout->addWidget(Stadt_h_label);

        price_h_box = new QLabel(layoutWidget2);
        price_h_box->setObjectName("price_h_box");

        verticalLayout->addWidget(price_h_box);


        horizontalLayout_2->addLayout(verticalLayout);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName("verticalLayout_6");
        id_h_lineedit = new QLineEdit(layoutWidget2);
        id_h_lineedit->setObjectName("id_h_lineedit");
        id_h_lineedit->setEnabled(false);

        verticalLayout_6->addWidget(id_h_lineedit);

        startdatum_h_box = new QDateEdit(layoutWidget2);
        startdatum_h_box->setObjectName("startdatum_h_box");
        startdatum_h_box->setEnabled(true);
        startdatum_h_box->setDate(QDate(1999, 1, 1));

        verticalLayout_6->addWidget(startdatum_h_box);

        enddatum_h_box = new QDateEdit(layoutWidget2);
        enddatum_h_box->setObjectName("enddatum_h_box");
        enddatum_h_box->setEnabled(true);
        enddatum_h_box->setDate(QDate(1999, 1, 1));

        verticalLayout_6->addWidget(enddatum_h_box);

        hotel_h_lineedit = new QLineEdit(layoutWidget2);
        hotel_h_lineedit->setObjectName("hotel_h_lineedit");
        hotel_h_lineedit->setEnabled(true);

        verticalLayout_6->addWidget(hotel_h_lineedit);

        stadt_h_lineedit = new QLineEdit(layoutWidget2);
        stadt_h_lineedit->setObjectName("stadt_h_lineedit");
        stadt_h_lineedit->setEnabled(true);

        verticalLayout_6->addWidget(stadt_h_lineedit);

        preis_h_box = new QSpinBox(layoutWidget2);
        preis_h_box->setObjectName("preis_h_box");
        preis_h_box->setEnabled(true);

        verticalLayout_6->addWidget(preis_h_box);


        horizontalLayout_2->addLayout(verticalLayout_6);


        verticalLayout_10->addLayout(horizontalLayout_2);

        tabwidget->addTab(hotelTab, QString());
        MietwagenTab = new QWidget();
        MietwagenTab->setObjectName("MietwagenTab");
        verticalLayout_8 = new QVBoxLayout(MietwagenTab);
        verticalLayout_8->setObjectName("verticalLayout_8");
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        Id_m_label = new QLabel(MietwagenTab);
        Id_m_label->setObjectName("Id_m_label");

        verticalLayout_2->addWidget(Id_m_label);

        Pickuplocation_m_label = new QLabel(MietwagenTab);
        Pickuplocation_m_label->setObjectName("Pickuplocation_m_label");

        verticalLayout_2->addWidget(Pickuplocation_m_label);

        returnlocation_m_label = new QLabel(MietwagenTab);
        returnlocation_m_label->setObjectName("returnlocation_m_label");

        verticalLayout_2->addWidget(returnlocation_m_label);

        Ankunftdatum_m_label = new QLabel(MietwagenTab);
        Ankunftdatum_m_label->setObjectName("Ankunftdatum_m_label");

        verticalLayout_2->addWidget(Ankunftdatum_m_label);

        AbreiseDatum_m_label = new QLabel(MietwagenTab);
        AbreiseDatum_m_label->setObjectName("AbreiseDatum_m_label");

        verticalLayout_2->addWidget(AbreiseDatum_m_label);

        Compan_m_label = new QLabel(MietwagenTab);
        Compan_m_label->setObjectName("Compan_m_label");

        verticalLayout_2->addWidget(Compan_m_label);

        Id_m_label_6 = new QLabel(MietwagenTab);
        Id_m_label_6->setObjectName("Id_m_label_6");

        verticalLayout_2->addWidget(Id_m_label_6);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName("verticalLayout_5");
        id_m_lineedit = new QLineEdit(MietwagenTab);
        id_m_lineedit->setObjectName("id_m_lineedit");
        id_m_lineedit->setEnabled(false);

        verticalLayout_5->addWidget(id_m_lineedit);

        pickuplocation_m_lineedit = new QLineEdit(MietwagenTab);
        pickuplocation_m_lineedit->setObjectName("pickuplocation_m_lineedit");
        pickuplocation_m_lineedit->setEnabled(true);

        verticalLayout_5->addWidget(pickuplocation_m_lineedit);

        returnlocation_m_lineedit = new QLineEdit(MietwagenTab);
        returnlocation_m_lineedit->setObjectName("returnlocation_m_lineedit");
        returnlocation_m_lineedit->setEnabled(true);

        verticalLayout_5->addWidget(returnlocation_m_lineedit);

        Ankunft_m_lineedit = new QDateEdit(MietwagenTab);
        Ankunft_m_lineedit->setObjectName("Ankunft_m_lineedit");
        Ankunft_m_lineedit->setEnabled(true);
        Ankunft_m_lineedit->setDate(QDate(1999, 1, 1));

        verticalLayout_5->addWidget(Ankunft_m_lineedit);

        Abreise_m_lineedit = new QDateEdit(MietwagenTab);
        Abreise_m_lineedit->setObjectName("Abreise_m_lineedit");
        Abreise_m_lineedit->setEnabled(true);
        Abreise_m_lineedit->setDate(QDate(1999, 1, 1));

        verticalLayout_5->addWidget(Abreise_m_lineedit);

        company_m_lineedit = new QLineEdit(MietwagenTab);
        company_m_lineedit->setObjectName("company_m_lineedit");
        company_m_lineedit->setEnabled(true);

        verticalLayout_5->addWidget(company_m_lineedit);

        preis_m_box = new QSpinBox(MietwagenTab);
        preis_m_box->setObjectName("preis_m_box");
        preis_m_box->setEnabled(true);

        verticalLayout_5->addWidget(preis_m_box);


        horizontalLayout->addLayout(verticalLayout_5);


        verticalLayout_8->addLayout(horizontalLayout);

        tabwidget->addTab(MietwagenTab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName("tab_3");
        kundenName_lineEdit = new QLineEdit(tab_3);
        kundenName_lineEdit->setObjectName("kundenName_lineEdit");
        kundenName_lineEdit->setGeometry(QRect(30, 50, 221, 31));
        layoutWidget3 = new QWidget(tab_3);
        layoutWidget3->setObjectName("layoutWidget3");
        layoutWidget3->setGeometry(QRect(12, 10, 286, 32));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        Kunden_id_label = new QLabel(layoutWidget3);
        Kunden_id_label->setObjectName("Kunden_id_label");

        horizontalLayout_4->addWidget(Kunden_id_label);

        Kunden_id_lineedit = new QLineEdit(layoutWidget3);
        Kunden_id_lineedit->setObjectName("Kunden_id_lineedit");
        Kunden_id_lineedit->setEnabled(true);

        horizontalLayout_4->addWidget(Kunden_id_lineedit);


        horizontalLayout_5->addLayout(horizontalLayout_4);

        kunden_suchen_pushButton = new QPushButton(layoutWidget3);
        kunden_suchen_pushButton->setObjectName("kunden_suchen_pushButton");

        horizontalLayout_5->addWidget(kunden_suchen_pushButton);

        layoutWidget4 = new QWidget(tab_3);
        layoutWidget4->setObjectName("layoutWidget4");
        layoutWidget4->setGeometry(QRect(0, 100, 521, 194));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        travelId_tableWidget = new QTableWidget(layoutWidget4);
        if (travelId_tableWidget->columnCount() < 4)
            travelId_tableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        travelId_tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        travelId_tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        travelId_tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        travelId_tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        travelId_tableWidget->setObjectName("travelId_tableWidget");
        travelId_tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        travelId_tableWidget->setSortingEnabled(true);

        horizontalLayout_6->addWidget(travelId_tableWidget);

        kunde_tabele_widget = new QTableWidget(layoutWidget4);
        if (kunde_tabele_widget->columnCount() < 3)
            kunde_tabele_widget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        kunde_tabele_widget->setHorizontalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        kunde_tabele_widget->setHorizontalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        kunde_tabele_widget->setHorizontalHeaderItem(2, __qtablewidgetitem6);
        kunde_tabele_widget->setObjectName("kunde_tabele_widget");
        kunde_tabele_widget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        kunde_tabele_widget->setSortingEnabled(true);

        horizontalLayout_6->addWidget(kunde_tabele_widget);

        tabwidget->addTab(tab_3, QString());

        verticalLayout_7->addWidget(tabwidget);

        ausgabe_widget_list = new QListWidget(centralwidget);
        ausgabe_widget_list->setObjectName("ausgabe_widget_list");
        ausgabe_widget_list->setGeometry(QRect(710, 20, 661, 441));
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1569, 25));
        menuDatei = new QMenu(menubar);
        menuDatei->setObjectName("menuDatei");
        menuBuchungen = new QMenu(menubar);
        menuBuchungen->setObjectName("menuBuchungen");
        menuReise = new QMenu(menubar);
        menuReise->setObjectName("menuReise");
        menuKunde = new QMenu(menubar);
        menuKunde->setObjectName("menuKunde");
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menuDatei->menuAction());
        menubar->addAction(menuBuchungen->menuAction());
        menubar->addAction(menuReise->menuAction());
        menubar->addAction(menuKunde->menuAction());
        menuDatei->addAction(actionTextEinlesen);
        menuDatei->addAction(actionJsonSpeichern);
        menuDatei->addAction(actionJsonEinlesen);
        menuDatei->addAction(actionjsonSortierSpeichern);
        menuDatei->addAction(actiontxtAlsJsonSpeichern);
        menuDatei->addAction(actionalleBookingSortiertAlsJSon);
        menuBuchungen->addAction(actionAuswaehlen);
        menuBuchungen->addAction(actionAlle_anzeigen);
        menuReise->addAction(actionAlle_Anzeigen);
        menuKunde->addAction(actionAlle_Anzeige);

        retranslateUi(MainWindow);

        tabwidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionTextEinlesen->setText(QCoreApplication::translate("MainWindow", "TextEinlesen", nullptr));
        actionAuswaehlen->setText(QCoreApplication::translate("MainWindow", "Auswaehlen", nullptr));
        actionAlle_anzeigen->setText(QCoreApplication::translate("MainWindow", "Alle anzeigen", nullptr));
        actionJsonSpeichern->setText(QCoreApplication::translate("MainWindow", "JsonSpeichern", nullptr));
        actionAlle_Anzeige->setText(QCoreApplication::translate("MainWindow", "Liste Alle Kunden", nullptr));
        actionAlle_Anzeigen->setText(QCoreApplication::translate("MainWindow", "Liste Alle Reisen Anzeigen", nullptr));
        actionJsonEinlesen->setText(QCoreApplication::translate("MainWindow", "JsonEinlesen", nullptr));
        actionjsonSortierSpeichern->setText(QCoreApplication::translate("MainWindow", "jsonSortierSpeichern", nullptr));
        actiontxtAlsJsonSpeichern->setText(QCoreApplication::translate("MainWindow", "txtAlsJsonSpeichern", nullptr));
        actionalleBookingSortiertAlsJSon->setText(QCoreApplication::translate("MainWindow", "alleBookingSortiertAlsJSon", nullptr));
        id_f_label->setText(QCoreApplication::translate("MainWindow", "Id", nullptr));
        Startdatum_f_label->setText(QCoreApplication::translate("MainWindow", "Startdatum", nullptr));
        Enddatum_f_label->setText(QCoreApplication::translate("MainWindow", "Enddatum", nullptr));
        NameVonFlugHafen_startflughafen_label->setText(QCoreApplication::translate("MainWindow", "Name von Flg", nullptr));
        startflughafen_label->setText(QCoreApplication::translate("MainWindow", "Startflughafen", nullptr));
        NameVonFlugHafen_endflughafen_label->setText(QCoreApplication::translate("MainWindow", "Name von Flg", nullptr));
        Zielflughafen_label->setText(QCoreApplication::translate("MainWindow", "Zielflughafen", nullptr));
        Flugesekschaft_label->setText(QCoreApplication::translate("MainWindow", "Flugesekschaft", nullptr));
        Preis_f_label->setText(QCoreApplication::translate("MainWindow", "Preis", nullptr));
        f_speichern_Button->setText(QCoreApplication::translate("MainWindow", "speichern", nullptr));
        tabwidget->setTabText(tabwidget->indexOf(FlightbuchungTab), QCoreApplication::translate("MainWindow", "Flugbuchung", nullptr));
        Id_h_label->setText(QCoreApplication::translate("MainWindow", "Id", nullptr));
        Startdatum_h_label->setText(QCoreApplication::translate("MainWindow", "Startdatum", nullptr));
        Enddatum_h_label->setText(QCoreApplication::translate("MainWindow", "Enddatum", nullptr));
        Hotel_h_label->setText(QCoreApplication::translate("MainWindow", "Hotel", nullptr));
        Stadt_h_label->setText(QCoreApplication::translate("MainWindow", "Stadt", nullptr));
        price_h_box->setText(QCoreApplication::translate("MainWindow", "Preis", nullptr));
        tabwidget->setTabText(tabwidget->indexOf(hotelTab), QCoreApplication::translate("MainWindow", "Hotel", nullptr));
        Id_m_label->setText(QCoreApplication::translate("MainWindow", "Id", nullptr));
        Pickuplocation_m_label->setText(QCoreApplication::translate("MainWindow", "Pickuplocation", nullptr));
        returnlocation_m_label->setText(QCoreApplication::translate("MainWindow", "returnlocation", nullptr));
        Ankunftdatum_m_label->setText(QCoreApplication::translate("MainWindow", "Ankunftdatum", nullptr));
        AbreiseDatum_m_label->setText(QCoreApplication::translate("MainWindow", "AbreiseDatum", nullptr));
        Compan_m_label->setText(QCoreApplication::translate("MainWindow", "Company", nullptr));
        Id_m_label_6->setText(QCoreApplication::translate("MainWindow", "Price", nullptr));
        tabwidget->setTabText(tabwidget->indexOf(MietwagenTab), QCoreApplication::translate("MainWindow", "MietwagenReservierung", nullptr));
        Kunden_id_label->setText(QCoreApplication::translate("MainWindow", "KundenId", nullptr));
        kunden_suchen_pushButton->setText(QCoreApplication::translate("MainWindow", "Suchen", nullptr));
        QTableWidgetItem *___qtablewidgetitem = travelId_tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "BookingId", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = travelId_tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "startdatum", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = travelId_tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "enddatum", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = travelId_tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "Preis", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = kunde_tabele_widget->horizontalHeaderItem(0);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "ReiseId", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = kunde_tabele_widget->horizontalHeaderItem(1);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "StartDatum", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = kunde_tabele_widget->horizontalHeaderItem(2);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "EndDatum", nullptr));
        tabwidget->setTabText(tabwidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "Kunde succhen", nullptr));
        menuDatei->setTitle(QCoreApplication::translate("MainWindow", "Datei", nullptr));
        menuBuchungen->setTitle(QCoreApplication::translate("MainWindow", "Buchungen", nullptr));
        menuReise->setTitle(QCoreApplication::translate("MainWindow", "Reise", nullptr));
        menuKunde->setTitle(QCoreApplication::translate("MainWindow", "Kunde", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
