#ifndef TEST_H
#define TEST_H
#include <QtTest/QTest>
#include <travelagency.h>

class Test : public QObject
{
    Q_OBJECT

public:

     Test(shared_ptr<Travelagency> travelagency,QObject *parent = nullptr);

private slots:

     void testmietwagen();
     void testFlugbuchung();
     void testbuchungwert();

private:
     shared_ptr<Travelagency>_travelagency;
     std::string datei=("C://Users//nilou//Documents//UpandawayuiPraktikum4//bookings2.txt");

};

#endif // TEST_H
