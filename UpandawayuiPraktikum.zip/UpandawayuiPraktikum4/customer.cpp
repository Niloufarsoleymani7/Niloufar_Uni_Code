#include "customer.h"

Customer::Customer()
{}

Customer::Customer(int id, const std::string &name) : _id(id),
    _name(name)
{}

int Customer::getId() const
{
    return _id;
}

const std::string &Customer::getName() const
{
    return _name;
}

const std::vector<shared_ptr<Travel>> &Customer::getTravelList() const
{
    return _travelList;
}

void Customer::addTravel(shared_ptr<Travel>travel)
{
    _travelList.push_back(travel);
}




