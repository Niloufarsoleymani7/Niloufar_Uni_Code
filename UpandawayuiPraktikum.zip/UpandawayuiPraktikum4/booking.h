#ifndef BOOKING_H
#define BOOKING_H
#include <memory>
#include <string>

class Travelagency;
class Travel;

class Booking
{
public:

    Booking(int id, const std::string &fromdate, const std::string &toDate, double price,int travelId);

    virtual std::string showDetails() =0;

    int getId() const;

    std::string getcreatedDate(std::string &todate);

    double getPrice() const;

    const std::string &getFromdate() const;
    void setFromdate(const std::string &newFromdate);

    const std::string &getToDate() const;
    void setToDate(const std::string &newToDate);

    int getTravelId() const;

    virtual ~Booking();


    void setPrice(double newPrice);

    void setTravelId(int newTravelId);

protected:

    int _id {};
    int _travelId{};

    double _price{};

    std::string _fromdate {};
    std::string _toDate{};

};

#endif // BOOKING_H
