#ifndef TRAVEL_H
#define TRAVEL_H
#include <memory>
#include <vector>
#include "booking.h"

using std::shared_ptr;

class Customer;

class Travel
{
public:
    Travel();
    Travel(int id, int customerId, shared_ptr<Customer>customer);

    void addBooking(shared_ptr<Booking> booking);

    int getId() const;

    int getCustomerId() const;

    const std::vector<shared_ptr<Booking>> &getTravelBookings() const;

    void setCustomer(shared_ptr<Customer> newCustomer);

    const shared_ptr<Customer> &getCustomer() const;

private:

    int _id {};
    int _customerId{};
    std::vector<shared_ptr<Booking>>_travelBookings;
    shared_ptr<Customer> _customer;

};

#endif // TRAVEL_H
