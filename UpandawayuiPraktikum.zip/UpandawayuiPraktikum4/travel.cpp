#include "travel.h"

Travel::Travel(int id, int customerId, shared_ptr<Customer>customer) : _id(id),
    _customerId(customerId),
    _customer(customer)
{}

void Travel::addBooking(shared_ptr<Booking> booking)
{
    _travelBookings.push_back(booking);
}

Travel::Travel()
{ }

int Travel::getId() const
{
    return _id;

}

int Travel::getCustomerId() const
{
    return _customerId;
}

const std::vector<shared_ptr<Booking>> &Travel::getTravelBookings() const
{
    return _travelBookings;
}

void Travel::setCustomer(shared_ptr<Customer> newCustomer)
{
    _customer = newCustomer;
}

const shared_ptr<Customer> &Travel::getCustomer() const
{
    return _customer;
}


