#ifndef TRAVELAGENCY_H
#define TRAVELAGENCY_H
#include "booking.h"
#include "flightbooking.h"
#include "rentalcarreservation.h"
#include "hotelbooking.h"
#include <vector>
#include "travel.h"
#include "customer.h"
#include <QMap>
#include <flughafen.h>
#include <sortfunktor.h>

class Travelagency
{
public:
    Travelagency();

    void readtextfile1(std::string ausgewaehltedatei);
    void readjJsontfile(QString ausgewaehltedatei);
    void txtAlsJsonSpeichern(std::string ausgewaehltedatei);


    std::string gettextfileinfoForPg2();
    std::string showbookings();

    shared_ptr<Booking> findBooking(int id);
    shared_ptr<Travel> findTravel(int id);
    shared_ptr<Customer>findCustomer(int id);

    double getGesamtFlugBetrag();
    double getGesamtHotelBetrag();
    double getGesamtMietwagenBetrag();

    bool is_number(const std::string& s);

    const std::vector<shared_ptr<Booking>> &getBookings() const;
    const std::vector<shared_ptr<Customer>> &getCustomers() const;
    const std::vector<shared_ptr<Travel>> &getTravels() const;

    void setBookingForTravel(int id,shared_ptr<Booking> booking);
    void settravelForCustomer(int id,shared_ptr<Travel> travel);

    //QMap<key,value>;
    //map[key]=value;

    QMap <QString, std::shared_ptr<Flughafen>> airportMap;
    bool findIata(QString iataName);


    void sortBooking(SortFunktor::SortierParameter mode);//mode batavajoh be chizi ke man gablan dadam

    void delteBooking();
    ~Travelagency();

private:

    std::vector<shared_ptr<Booking>> _bookings=std::vector<shared_ptr<Booking>>();
    std::vector<shared_ptr<Customer>> _customers=std::vector<shared_ptr<Customer>> ();
    std::vector<shared_ptr<Travel>> _travels=std::vector<shared_ptr<Travel>>();

    double gesamtFlugBetrag{};
    double gesamtHotelBetrag{};
    double gesamtMietwagenBetrag{};

};

#endif // TRAVELAGENCY_H
