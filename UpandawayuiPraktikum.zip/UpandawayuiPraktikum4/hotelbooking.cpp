#include "hotelbooking.h"

Hotelbooking::Hotelbooking(const std::string &hotel, const std::string &town, int id,
                           const std::string &fromdate, const std::string &toDate, double price,int travelId) :
    Booking(id, fromdate, toDate, price,travelId),
    _hotel(hotel),
    _town(town)
{}

std::string Hotelbooking::showDetails()
{
    //Format: Hotelreservierung 37 im Residence 1898 in Warschau vom 02.06.2021 bis zum 03.06.2021. Preis: 256.02 Euro
      using std::to_string;
      std::string bookinginfo = "Hotelreservierung "+ to_string(getId())+ " im "+ getHotel()+ " in "+ getTown()+
              " vom "+ getcreatedDate(_fromdate)+ " bis zum "+ getcreatedDate(_toDate)+
              ". Preis: "+ to_string(getPrice())+ " Euro";

      return bookinginfo+"\n";
}



const std::string &Hotelbooking::getHotel() const
{
    return _hotel;
}

void Hotelbooking::setHotel(const std::string &newHotel)
{
    _hotel = newHotel;
}

const std::string &Hotelbooking::getTown() const
{
    return _town;
}

void Hotelbooking::setTown(const std::string &newTown)
{
    _town = newTown;
}

Hotelbooking::~Hotelbooking()
{ }
