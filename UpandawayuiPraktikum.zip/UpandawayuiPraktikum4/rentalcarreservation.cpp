#include "rentalcarreservation.h"
 using std::to_string;
RentalCarReservation::RentalCarReservation(const std::string &pickupLocation, const std::string &returnLocation, const std::string &company,
                                           int id, const std::string &fromdate, const std::string &toDate, double price,int travelId) :
    Booking(id, fromdate, toDate, price,travelId),
    _pickupLocation(pickupLocation),
    _returnLocation(returnLocation),
    _company(company)
{}

std::string RentalCarReservation::showDetails()
{
   std::string bookinginfo = "Mietwagenreservierung "+ to_string(getId())+ " mit "+ getCompany()+ ". Abholung am "+
              getcreatedDate(_fromdate)+
               " in "+getPickupLocation()+ ". Rueckgabe am "+ getcreatedDate(_toDate)+
               "in "+getReturnLocation()+". Preis: "+ to_string(getPrice())+ " Euro";
   return bookinginfo+"\n";
}


const std::string &RentalCarReservation::getPickupLocation() const
{
    return _pickupLocation;
}

void RentalCarReservation::setPickupLocation(const std::string &newPickupLocation)
{
    _pickupLocation = newPickupLocation;
}

const std::string &RentalCarReservation::getReturnLocation() const
{
    return _returnLocation;
}

void RentalCarReservation::setReturnLocation(const std::string &newReturnLocation)
{
    _returnLocation = newReturnLocation;
}

const std::string &RentalCarReservation::getCompany() const
{
    return _company;
}

void RentalCarReservation::setCompany(const std::string &newCompany)
{
    _company = newCompany;
}

RentalCarReservation::~RentalCarReservation()
{}
