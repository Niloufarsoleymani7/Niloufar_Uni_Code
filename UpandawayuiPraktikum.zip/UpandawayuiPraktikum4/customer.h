#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string>
#include "travel.h"
#include <vector>
#include <memory>
using std::shared_ptr;
class Customer
{
public:
    Customer();
    Customer(int id, const std::string &name);
    int getId() const;
    const std::string &getName() const;
    const std::vector<shared_ptr<Travel>> &getTravelList() const;
    void addTravel(shared_ptr<Travel> travel);

private :

    int _id{};
    std::string _name{};

    //std::vector<Travel*>_travelList=std::vector<Travel*>();
    std::vector<shared_ptr<Travel>>_travelList=std::vector<shared_ptr<Travel>>();


};

#endif // CUSTOMER_H
