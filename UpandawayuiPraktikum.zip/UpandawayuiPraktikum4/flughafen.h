#ifndef FLUGHAFEN_H
#define FLUGHAFEN_H
#include <QString>


class Flughafen
{
public:
    Flughafen();
    Flughafen(const QString &name, const QString &land, const QString &stad, const QString &iata);

    const QString &getName() const;
    void setName(const QString &newName);

    const QString &getLand() const;
    void setLand(const QString &newLand);

    const QString &getStad() const;
    void setStad(const QString &newStad);

    const QString &getIata() const;
    void setIata(const QString &newIata);

private:
    QString _name{};
    QString _land{};
    QString _stad{};
    QString _iata{};
};

#endif // FLUGHAFEN_H
