#include "flughafen.h"
Flughafen::Flughafen(const QString &name, const QString &land, const QString &stad, const QString &iata) : _name(name),
    _land(land),
    _stad(stad),
    _iata(iata)
{}

Flughafen::Flughafen()
{

}

const QString &Flughafen::getName() const
{
    return _name;
}

void Flughafen::setName(const QString &newName)
{
    _name = newName;
}

const QString &Flughafen::getLand() const
{
    return _land;
}

void Flughafen::setLand(const QString &newLand)
{
    _land = newLand;
}

const QString &Flughafen::getStad() const
{
    return _stad;
}

void Flughafen::setStad(const QString &newStad)
{
    _stad = newStad;
}

const QString &Flughafen::getIata() const
{
    return _iata;
}

void Flughafen::setIata(const QString &newIata)
{
    _iata = newIata;
}

