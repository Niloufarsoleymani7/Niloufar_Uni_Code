#ifndef PLAYERCONTROLLER_H
#define PLAYERCONTROLLER_H
#include<controller.h>
#include <tile.h>
class PlayerController:public Controller
{
public:
    PlayerController(Character * who,Level * nLevel);
    ~PlayerController();
    int move ()override;

    bool TryMove(Position &inputPos)override;
    bool TryMove()override;
    Position getPosition()override;
};

#endif // PLAYERCONTROLLER_H
