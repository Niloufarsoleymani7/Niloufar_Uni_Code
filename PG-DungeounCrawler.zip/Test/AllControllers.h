#ifndef ALLCONTROLLERS_H
#define ALLCONTROLLERS_H
#include<chasecontroller.h>
#include<playercontroller.h>
#include<controller.h>
#include<guardcontroller.h>
#include<enemycollection.h>

#endif // ALLCONTROLLERS_H
