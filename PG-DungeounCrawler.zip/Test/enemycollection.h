#ifndef ENEMYCOLLECTION_H
#define ENEMYCOLLECTION_H
#include "character.h"
#include<controller.h>
#include<QLabel>
class EnemyCollection
{
public:
    EnemyCollection(Character *character_p=nullptr,
    Controller *controller_p=nullptr,
    QLabel *qLabel_p=nullptr);

    Character *character=nullptr;
    Controller *controller=nullptr;
    QLabel *qLabel=nullptr;

    bool deletFlag=false;

};

#endif // ENEMYCOLLECTION_H
