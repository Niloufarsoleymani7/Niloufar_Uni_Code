#ifndef LEVELEXIT_H
#define LEVELEXIT_H
#include <tile.h>
class Level;

class LevelExit:public Tile
{
public:
    LevelExit(int x,int y,Level *pointerAufLevel_p=nullptr);
    Tile* onEnter(Tile* fromTile, Character* who)override; //fromtile aktuelle Standort
    Tile* onLeave(Tile* destTile, Character* who)override;
    Level *pointerAufLevel=nullptr;

};

#endif // LEVELEXIT_H
