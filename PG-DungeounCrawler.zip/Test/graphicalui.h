#ifndef GRAPHICALUI_H
#define GRAPHICALUI_H
#include "abstractui.h"
#include "controller.h"


class GraphicalUI :public AbstractUI,public Controller
{
public:
    GraphicalUI();
    void draw(Level* aktuellLevel)override;
    int move()override;
};

#endif // GRAPHICALUI_H
