#include "level.h"
#include<levelexit.h>
#include<playercontroller.h>
#include "controller.h"
#include<guardcontroller.h>
#include<navgraph.h>
#include<navgraphagent.h>
#include<chasecontroller.h>

Level::Level()
{
    _navGraph=new NavGraph(this);
}

Level::Level(std::string  toOpen)
{
    _navGraph=new NavGraph(this);
    _fileLocation=toOpen;

}

Level::Level( Level &copylevel):_breite(copylevel._breite),_hoehe(copylevel._hoehe)
{
    Tile * lastPortal=nullptr;
    Tile *lastSwitch=nullptr;

    // const std::vector<std::vector<Tile*>> &gridtoCopy =copylevel.getGrid();

    std::cout<<"Copy level"<<std::endl;
    for(size_t y =0; y < copylevel.getGrid().size(); y++)
    {
        grid.push_back(std::vector<Tile*>());
        for(size_t x=0; x <copylevel.getGrid().at(y).size(); x++)
        {

            Tile* tile = copylevel.grid[y][x];

            if(typeid(*tile) == typeid(Floor))
            {
                auto f=dynamic_cast<Floor*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back(new Floor(*f));
            }

            else if(typeid(*tile) == typeid(Wall))
            {
                auto w=dynamic_cast<Wall*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back(new Wall(*w));
            }

            else if(typeid(*tile)== typeid(Pit))
            {
                auto p=dynamic_cast<Pit*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back( new Pit(*p));
            }
            else if(typeid(*tile)== typeid(Portal))
            {

                auto p=dynamic_cast<Portal*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back(new Portal(*p));

                if(lastPortal==nullptr)
                {
                    lastPortal=grid.at(y).back();
                }
                else
                {
                    static_cast<Portal *>(grid.at(y).back())->setDestination(getTile(lastPortal->getposX(),lastPortal->getposY()));//back ist letze elment
                    static_cast<Portal *>(lastPortal)->setDestination(grid.at(y).back());
                    lastPortal=nullptr;
                }

            }
            else if(typeid(*tile)== typeid(Ramp))
            {
                auto r=dynamic_cast<Ramp*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back(new Ramp(*r));
            }
            else if(typeid(*tile)== typeid(Door))
            {
                // auto d=dynamic_cast<Door*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back( new Door(x,y,false));
                dynamic_cast<Switch*>(lastSwitch)->attach(dynamic_cast<Door*>(grid.at(y).back()));

            }

            else if(typeid(*tile)== typeid(Switch))
            {


                auto s=dynamic_cast<Switch*>(copylevel.grid.at(y).at(x));
                grid.at(y).push_back(new Switch(*s));
                lastSwitch=grid.at(y).back();
                dynamic_cast<Switch*>(lastSwitch)->attach(dynamic_cast<Door*>(grid.at(y).back()));


            }

            if(copylevel.grid.at(y).at(x)->hasCharacter())
            {
                Character* copychar = new Character(20,50);
                enemies.push_back(copychar);
                grid.at(y).at(x)->setCharactarOnTile(enemies.back());
                copychar->setLevel(this);
                copychar->setTileDerIchDarufStehe(grid.at(y).back());

            }

        }
    }
}



Level::~Level()
{
    for (unsigned int i = 0; i<grid.size(); ++i){
        for (unsigned int j =0;j<grid.at(i).size(); ++j)
        {
            delete grid.at(i).at(j);
        }}

    for (size_t i=0;i<enemies.size();i++)
    {
        delete enemies.at(i);
    }

    for (size_t i=0;i<enemyControllers.size();i++)
    {
        delete enemyControllers.at(i);
    }
    if(_playerCharacter!=nullptr){
        delete _playerCharacter;
    }
    if(playerController!=nullptr)
    {
        delete playerController;
    }

    delete _navGraph;
}

Tile *Level::getTile(int x, int y)
{
    return grid.at(y).at(x);
}

const Tile *Level::getTile(int x, int y) const
{
    return grid.at(y).at(x);
}

void Level::placeCharacter(Character *c, int x, int y)
{
    c->setTileDerIchDarufStehe(getTile(x,y));//tile char migire
    grid.at(x).at(y)->setCharactarOnTile(c);//char ro bezar run un kashi
    c->setLevel(this);//ta bedune charahter koja hast
}

void Level::printGrid()
{

    for(size_t i = 0 ; i < grid.size(); ++i)
    {
        std::cout<<"\t\t\t";
        for(size_t j = 0 ; j < grid.at(i).size() ; ++j)
        {
            std::cout<<grid.at(i).at(j)->getTexture()<<" ";
        }
        std::cout<<std::endl;
    }
    std::cout<<std::endl;
}

const std::vector<Character *> &Level::getCharacters() const
{
    return enemies;
}

void Level::removeCharacter(Character *toRemove)
{
    std::vector<Character*>::iterator a = enemies.begin();
    while (a!=enemies.end()) {
        if(*a==toRemove){
            enemies.erase(a);
            return;
        }else{
            a++;
        }
    }
}


void Level::setCharacters(const std::vector<Character *> &newCharacters)
{
    enemies = newCharacters;
}

void Level::ReadLevelFile(QString toOpen )
{

    std::ifstream infile(toOpen.toStdString());
    if ( ! infile.is_open() )
    {
        std::cout <<" Failed to open" <<std:: endl;
    }
    else {
        std::cout <<"Opened OK" << std::endl;
    }
    std::string line;
    char cur;
    int y=0;

    while(std::getline(infile,line))
    {
        grid.push_back(std::vector<Tile *>());
        std::stringstream ss; //stream von char
        ss<<line;
        int x=0;
        while(ss>>cur)
        {
            std::string check=std::string(1,cur);
            if(check.find_first_of("0123456789")==0){
                addPairsEntry(static_cast <int>(cur));
            }
            else
            {
                x+=createTileAtPos(cur,x,y);
            }
            if(_breite<x){
                _breite=x;
            }
        }
        y++;
        _hoehe=y;
    }

    std::cout<<"Level X is: "<<_breite<<std::endl<<"Level y is: "<<_hoehe<<std::endl;
}

void Level::initializearrays()
{
    for (int i=0;i<MAX_PAIRS;i++)
    {
        portalPairs[i]=std::vector<Portal*>();
        activs[i]=std::vector<Active*>();
        passivs[i]=std::vector<Passive*>();

    }
}

int Level::createTileAtPos(char tileTexture, int x, int y)
{

    switch(tileTexture)
    {
    case texturewall:
        grid.at(y).push_back(new Wall(x,y));
        break;
    case texturefloor:
        grid.at(y).push_back(new Floor(x,y));
        break;
    case textureportal:
        grid.at(y).push_back(new Portal(x,y));
        lastPortal=grid.at(y).back();
        break;
    case textureplayer:
        grid.at(y).push_back(new Floor(x,y));
        _playerCharacter=new Character(20,20);
        grid.at(y).back()->setCharactarOnTile(_playerCharacter);
        _playerCharacter->setLevel(this);//
        _playerCharacter->setTileDerIchDarufStehe(grid.at(y).back());
        break;
    case texturerZombie:
        grid.at(y).push_back(new Floor(x,y));
        enemies.push_back(new Character(5,10));
        grid.at(y).back()->setCharactarOnTile(enemies.back());
        enemies.back()->setLevel(this);//
        enemies.back()->setTileDerIchDarufStehe(grid.at(y).back());
        enemies.back()->settexture(texturerZombie);
        enemyControllers.push_back(new ChaseController(enemies.back(),this,new NavGraphAgent(_navGraph)));
        //verhalten von einem wenn zombie ein zombie

        break;
    case textureswitchS:
        grid.at(y).push_back(new Switch(x,y));
        lastActive=static_cast<Switch*>(grid.at(y).back());
        break;
    case textureLevelChanger:
        grid.at(y).push_back(new LevelExit(x,y,this));
        lastLevelExit=static_cast<LevelExit*>(grid.at(y).back());
        break;
    case texturepit:
        grid.at(y).push_back(new Pit(x,y));
        break;
    case texturerChest:
        grid.at(y).push_back(new Chest(x,y));
        break;
    case textureramp:
        grid.at(y).push_back(new Ramp(x,y));
        break;
    case texturedoorOpen :
        grid.at(y).push_back(new Door(x,y,true));
        lastPassive=static_cast<Door*>(grid.at(y).back());

        break;
    case texturedoorClose :
        grid.at(y).push_back(new Door(x,y,false));
        lastPassive=static_cast<Door*>(grid.at(y).back());
        break;
    case textureempty:
        return -1;
        break;
    default:
        std::cout<<"Error reading file content, wrong character"<<std::endl;
        break;
    }
    return 1;

}

void Level::setExitStairCase(LevelExit *newExitStairCase)
{
    _exitStairCase = newExitStairCase;
}

void Level::setEntryStairCase(LevelExit *newEntryStairCase)
{
    _entryStairCase = newEntryStairCase;
}

LevelExit *Level::getExitStairCase() const
{
    return _exitStairCase;
}

PlayerController *Level::getPlayerController() const
{
    return playerController;
}

void Level::setPlayerController(PlayerController *newPlayerController)
{
    playerController = newPlayerController;
}

LevelExit *Level::getEntryStairCase() const
{
    return _entryStairCase;
}

void Level::addPairsEntry(int pair)
{
    pair-=48;
    if (lastActive!=nullptr){
        activs[pair].push_back(lastActive);
        lastActive=nullptr;
    }
    else if (lastPassive!=nullptr){
        passivs[pair].push_back(lastPassive);
        lastPassive=nullptr;
    }
    else if (lastPortal!=nullptr){
        portalPairs[pair].push_back(static_cast<Portal*>(lastPortal));
        lastPortal=nullptr;
    }
    else if (lastLevelExit!=nullptr){
        switch(pair){
        case 0:
            _entryStairCase=lastLevelExit;
            lastLevelExit=nullptr;
            break;
        case 1:
            _exitStairCase=lastLevelExit;
            lastLevelExit=nullptr;
            break;
        }
    }

}

void Level::saveCharacterFile()
{

    std::stringstream toSave= std::stringstream();
    if(_playerCharacter!=nullptr){
        writeCharacterToFile(_playerCharacter,toSave);
    }

    for(size_t i=0;i<enemies.size();i++){
        writeCharacterToFile(enemies.at(i),toSave);
    }
     std::ofstream fout(GetCharacterFileLocation());
     fout<<toSave.str();
}

std::string Level::GetCharacterFileLocation()
{
     std::string fixfilelocation=_fileLocation;
     fixfilelocation=fixfilelocation.substr(0,fixfilelocation.length()-4);
     fixfilelocation.append("characters.txt");
     return fixfilelocation;
}

void Level::setGrid(const std::vector<std::vector<Tile *> > &newGrid)
{
    grid = newGrid;
}

const std::vector<std::vector<Tile *> > &Level::getGrid() const
{
    return grid;
}

const std::vector<Controller *> &Level::getControllers() const
{
    return enemyControllers;
}

void Level::removeController(Controller *toRemove)
{
    std::vector<Controller*>::iterator a = enemyControllers.begin();
    while (a!=enemyControllers.end()) {
        if(*a==toRemove){
            enemyControllers.erase(a);
            return;
        }else{
            a++;
        }
    }

}

bool Level::getlevelFinished() const
{
    return levelFinished;
}

void Level::setlevelFinished(bool newlevelFinished)
{
    levelFinished = newlevelFinished;
}

bool Level::getVictory() const
{
    return victory;
}

void Level::setVictory(bool newVictory)
{
    victory = newVictory;
}

void Level::levelChangerEntred(LevelExit *levelexit)
{

    if (levelexit == _entryStairCase){
        if(_levelstate!=Stay){
            _levelstate=Stay;
        }
        else{
            _levelstate=Goback;
        }
    }
    else if (levelexit== _exitStairCase){
        if(_levelstate!=Stay){
            _levelstate=Stay;
        }
        else{
            _levelstate=GoForth;
        }
    }

}

void Level::onPlayerDeath()
{
    _levelstate= LevelState::Defeat;
}

void Level::onVictory()
{
    _levelstate= LevelState::Victory;

}

Level::LevelState Level::getlevelstate() const
{
    return _levelstate;
}

Character *Level::getPlayerInLevel() const
{
    return _playerCharacter;
}

void Level::setPlayerInLevel(Character *newPlayerInLevel)
{
    _playerCharacter = newPlayerInLevel;
    setChasingControllersTarget();
}

int Level::getBreite() const
{
    return _breite;
}

int Level::getHoehe() const
{
    return _hoehe;
}

void Level::connectAllPortals()
{
    for (int i=0;i<MAX_PAIRS;i++){
        if(portalPairs[i].size()==2){
            portalPairs[i].at(0)->setDestination(portalPairs[i].at(1));
            portalPairs[i].at(1)->setDestination(portalPairs[i].at(0));
        }
    }
}

void Level::connectAllActivsAndPassivs()
{
    for (int i=0;i<MAX_PAIRS;i++)
    {
        connectPassivsToActivs(i);
    }

}

void Level::connectPassivsToActivs(int arrayIndex)
{
    for (size_t i=0;i<activs[arrayIndex].size();i++){
        connectPassivsToActiv(arrayIndex,i);

    }

}

void Level::connectPassivsToActiv(int arrayIndex, int activeInex)
{
    for (size_t i=0;i<passivs[arrayIndex].size();i++){
        connectPassivToActiv(arrayIndex,activeInex,i);

    }
}

void Level::connectPassivToActiv(int arrayIndex, int activeIndex, int passivIndex)
{
    activs[arrayIndex].at(activeIndex)->attach(passivs[activeIndex].at(passivIndex));
}

void Level::initialize()
{
    _navGraph->BakeGrid();
    if(_playerCharacter!=nullptr){
        _levelstate=Stay;
    }
    setChasingControllersTarget();
    for(int i=0;i<enemies.size();i++)
    {
      if(enemies.at(i)->getIstDead())
      {
          onCharacterDeath(enemies.at(i));

      }
    }
}

void Level::saveGame()
{
    saveCharacterFile();

}

void Level::onCharacterDeath(Character *character)
{
    character->getTileDerIchDarufStehe()->setCharactarOnTile(nullptr);
}

const std::vector<Character *> &Level::getEnemies() const
{
    return enemies;
}

void Level::setEnemies(const std::vector<Character *> &newEnemies)
{
    enemies = newEnemies;
}

const std::vector<Controller *> &Level::getEnemyControllers() const
{
    return enemyControllers;
}

void Level::setEnemyControllers(const std::vector<Controller *> &newEnemyControllers)
{
    enemyControllers = newEnemyControllers;
}

NavGraph *Level::getNavGraph() const
{
    return _navGraph;
}

void Level::setNavGraph(NavGraph *newNavGraph)
{
    _navGraph = newNavGraph;
}

void Level::setChasingControllersTarget()
{
    for(size_t i =0;i<enemyControllers.size();i++)
    {
        if(typeid(*enemyControllers.at(i)).name()== typeid(ChaseController).name()){
            static_cast<ChaseController*>(enemyControllers.at(i))->SetChasing(_playerCharacter);
        }
    }
}

void Level::writeCharacterToFile(Character *tosave, std::stringstream &stream)
{

    char delimiter='"';

    stream<<delimiter;
    char id=tosave->getTexture();
    stream<<id;
    stream<<delimiter;

    stream<<delimiter;
    int x=tosave->getTileDerIchDarufStehe()->getposX();
    int y =tosave->getTileDerIchDarufStehe()->getposY();
    Position pos(x,y);
    stream<<pos.x;
    stream<<delimiter;

    stream<<delimiter;
    stream<<pos.y;
    stream<<delimiter;

    stream<<delimiter;
    int maxStamina=tosave->getMaxStamina();
    stream<<maxStamina;
    stream<<delimiter;

    stream<<delimiter;
    int curStamina=tosave->getStamina();
    stream<<curStamina;
    stream<<delimiter;

    stream<<delimiter;
    int strenght=tosave->getStrength();
    stream<<strenght;
    stream<<delimiter;

    stream<<delimiter;
    int curHealth=tosave->getHitpoints();
    stream<<curHealth;
    stream<<delimiter;

    stream<<delimiter;
    int movecycle=0;
    stream<<movecycle;
    stream<<delimiter;

    stream<<'\n';
}



void Level::setHoehe(int newHoehe)
{
    _hoehe = newHoehe;
}

void Level::setBreite(int newBreite)
{
    _breite = newBreite;
}











