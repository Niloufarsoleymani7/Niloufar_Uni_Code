#include "position.h"

Position::Position()
{

}

Position::Position(int nx, int ny):x(nx),y(ny)
{

}

bool Position::isMovePos()
{
    for (int i =0;i<10;i++)
    {
        if(INPUTTRANSLATE[i]==*this){
            return true;
        }
    }
    return false;
}

Position Position::operator+(const Position &a) const
{
    return Position(a.x+x,a.y+y);
}

Position Position::operator-(const Position &a) const
{
    return Position(a.x-x,a.y-y);

}

bool Position::operator==(const Position &a) const
{
    return (x == a.x && y== a.y);

}

bool Position::operator!=(const Position &a) const
{
    return !(x == a.x && y== a.y);


}
