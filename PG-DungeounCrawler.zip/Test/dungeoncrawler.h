#ifndef DUNGEONCRAWLER_H
#define DUNGEONCRAWLER_H
#include "level.h"
#include <vector>
#include "terminalui.h"
#include<levelList.h>
#include <MyStatics.h>

class LevelFactory;
class DungeonCrawler//„Managerklasse
{
public:

    DungeonCrawler();
    ~DungeonCrawler();
    DungeonCrawler(LevelFactory *levelFactory);
    void play();
    void setActiveLevels(const std::vector<Level *> &newActiveLevels);
    AbstractUI *getPointerAufAbstractui() const;
    void setPointerAufAbstractui(AbstractUI *newPointerAufAbstractui);
    Level *getActiveLevel();
    void setActiveLevel(Level *newActiveLevel);
    TerminalUI *getPointerAufTerminalUi() const;
    void setPointerAufTerminalUi(TerminalUI *newPointerAufTerminalUi);
    LevelList &getLevelListe() ;

private:

    LevelList _levels=LevelList();
    AbstractUI *_pointerAufAbstractui=nullptr;
    TerminalUI *_pointerAufTerminalUi=nullptr;
   // Level *activeLevel=nullptr;
    Position ReadInput();


};

#endif // DUNGEONCRAWLER_H
