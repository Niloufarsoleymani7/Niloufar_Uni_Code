#include "playercontroller.h"

PlayerController::PlayerController(Character * who,Level * nLevel):Controller(who,nLevel)
{

}

PlayerController::~PlayerController()
{

}

int PlayerController::move()
{

}

bool PlayerController::TryMove(Position &inputPos)
{

}

bool PlayerController::TryMove()
{

}

Position PlayerController::getPosition()
{

}

