#ifndef SWITCH_H
#define SWITCH_H
#include<floor.h>
#include<active.h>
#include <MyStatics.h>
//macht die floor auf und zu
class Switch :public Floor,public Active
{
public:
    Switch(int x,int y);
    Tile* onEnter(Tile* fromTile, Character* who) override;
    Tile* onLeave(Tile* destTile, Character* who) override;

};

#endif // SWITCH_H
