#ifndef LOADLEVELFACTORY_H
#define LOADLEVELFACTORY_H
#include "levelfactory.h"

class LoadLevelFactory:public LevelFactory
{
public:
    LoadLevelFactory();
    ~LoadLevelFactory();
    Level * BuildLevel(QString fileLocation) override;

};

#endif // LOADLEVELFACTORY_H
