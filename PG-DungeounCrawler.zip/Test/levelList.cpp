#include "levellist.h"

LevelList::LevelList()
{
    first=endElement;
    last=endElement;
}

LevelList::~LevelList()
{
    LevelElement * cur=first;
    LevelElement * next=cur->next;
    while(next!=nullptr){
        delete cur;
        cur=next;
        next=cur->next;
    }
    delete cur;
}

void LevelList::PushBack(Level* toAdd)
{
    LevelElement * temp=new LevelElement(toAdd,last,endElement);

    if(first==endElement){
        temp->prev=nullptr;
        first=temp;
        last=temp;

    }else{
        last->next=temp;
        last=temp;
        endElement->prev=last;
    }
}

void LevelList::PushFront(Level* toAdd)
{
    LevelElement * temp=new LevelElement(toAdd,nullptr,first);

    if(first==endElement){
        first=temp;
        last=temp;

    }else{
        first->prev=temp;
        first=temp;
    }
}

void LevelList::PopBack()
{
    LevelElement * lastPrev=last->prev;
    LevelElement * toDelete=last;

    if(lastPrev==nullptr){
        first=endElement;
        last=endElement;
    }else{
        last=lastPrev;
        last->next=endElement;
        endElement->prev=last;

    }
    delete toDelete;

}

void LevelList::PopFront()
{
    LevelElement * firstNext=first->next;
    LevelElement * toDelete=first;

    if(firstNext==endElement){
        first=endElement;
        last=endElement;
    }else{
        first=firstNext;
    }
    delete toDelete;

}

bool LevelList::Empty()
{
    return first==endElement;
}

std::size_t LevelList::Size()
{
    LevelElement * tmp=first;
    size_t size=0;
    while (tmp!=endElement) {
        tmp=tmp->next;
        size++;
    }
    return size;
}

void LevelList::Remove(Level * toRemove)
{
    LevelElement * cur=first;
    while (cur!=endElement) {
        if(cur->level==toRemove){
            LevelElement * next=cur->next;
            LevelElement * prev=cur->prev;
            delete cur;

            StitchElements(prev,next);
            cur=prev;
        }
        cur=cur->next;
    }
}

LevelList::LevelIterator LevelList::Begin()
{
    return LevelIterator(first);
}

LevelList::LevelIterator LevelList::End()
{
    return LevelIterator(endElement);
}

void LevelList::StitchElements(LevelElement *prev, LevelElement *next)
{
    next->prev=prev;
    prev->next=next;
}

LevelList::LevelIterator::LevelIterator()
{
}

LevelList::LevelIterator::LevelIterator( LevelElement *_element)
{
    element=_element;
}

LevelList::LevelIterator &LevelList::LevelIterator::operator++()
{
    if(element->next!=nullptr){
        element=element->next;
    }
    return *this;
}

LevelList::LevelIterator &LevelList::LevelIterator::operator--()
{
    if(element->prev!=nullptr){
        element=element->prev;
    }
    return *this;
}

Level *&LevelList::LevelIterator::operator*()
{
    return element->level;
}

Level *&LevelList::LevelIterator::operator->()
{
    return element->level;

}

bool LevelList::LevelIterator::operator==(const LevelIterator &other)
{
    return other.element->level==element->level;
}

bool LevelList::LevelIterator::operator!=(const LevelIterator &other)
{
    return other.element->level!=element->level;
}

Level *LevelList::LevelIterator::peakNext()
{
 return element->next->level;
}

LevelList::LevelElement::LevelElement()
{

}

LevelList::LevelElement::~LevelElement()
{
    if(level!=nullptr)
    {
    delete level;

    level=nullptr;}
}

LevelList::LevelElement::LevelElement(Level *_level, LevelElement *_prev)
{
    level=_level;
    prev=_prev;
}

LevelList::LevelElement::LevelElement(Level *_level, LevelElement *_prev, LevelElement *_next)
{
    level=_level;
    prev=_prev;
    next=_next;
}
