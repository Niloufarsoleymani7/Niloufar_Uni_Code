#include "ramp.h"

Ramp::Ramp(int x,int y):Tile(x,y)
{
    texture=textureramp;
}

Tile *Ramp::onEnter(Tile *fromTile, Character *who)
{
    if(hasCharacter()&&who!=CharactarOnTile){
        Fight f=Fight(who,CharactarOnTile);
        return nullptr;}
    if(typeid(*fromTile)==typeid(Pit))
    {
        who->useStamina(10);

    }
    return this;
}

Tile *Ramp::onLeave(Tile *destTile, Character *who)
{
    return this;
}


