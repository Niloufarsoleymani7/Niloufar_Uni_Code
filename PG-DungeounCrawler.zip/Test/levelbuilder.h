#ifndef LEVELBUILDER_H
#define LEVELBUILDER_H
#include <string>
#include <QString>
#include <vector>
#include "position.h"
class Level;
class Portal;
class Active;
class Passive;
class LevelExit;
class Tile;
class Character;
class Controller;
class PlayerController;

class LevelBuilder
{
public:
    LevelBuilder();
    Level * BuildFreshLevel(QString fileName);
    Level * BuildOldLevel(QString fileName);
private:
    Level * _currentlyBuilding=nullptr;
    QString _fileLocation;


    void ResetBuilder();

    std::vector<std::vector<Tile *>> _grid;

    std::vector<Character *> _entities=std::vector<Character *>();
    std::vector<Controller *> _entityController=std::vector<Controller *>();

    Character * _playerCharacter=nullptr;
    PlayerController * _playerController=nullptr;

    Tile * _lastPortal=nullptr;
    Passive * _lastPassiv=nullptr;
    Active * _lastActiv=nullptr;
    LevelExit * _lastStairCase=nullptr;

    static const int MAX_PAIRS=10;

    std::vector<Portal *> _portalPairs[MAX_PAIRS];
    std::vector<Active *> _activs[MAX_PAIRS];
    std::vector<Passive *> _passivs[MAX_PAIRS];

    LevelExit * _entryStairCase=nullptr;
    LevelExit * _exitStaircase=nullptr;

    void ReadLvlFile(QString &toLoad);
    std::string GetCharacterFileLocation();
    void ReadLvlFileIgnoreCharacters(QString &toLoad);
    void ReadCharacterFile(QString &toLoad);
    std::string CutNextVariable(std::string &line);

    Tile * GetTileByPosition(Position &pos);

    int CreateTileAtPos(char tileTexture,int x,int y);
    void AddPairsEntry(int pair);

    void ConnectAllPortals();
    void ConnectAllActivsAndPassivs();
    void ConnectPassivsToActivs(int arrayIndex);
    void ConnectPassivsToActiv(int arrayIndex, int activIndex);
    void ConnectPassivToActiv(int arrayIndex,int activIndex,int passivIndex);

    void FinalizeLevel();


};

#endif // LEVELBUILDER_H
