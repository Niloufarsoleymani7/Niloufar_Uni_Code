#ifndef ABSTRACTUI_H
#define ABSTRACTUI_H
#include "level.h"

class AbstractUI
{
public:

    AbstractUI(); //für die verschiedenen Benutzerschnittstellen.
    virtual ~AbstractUI() {};

protected:

    virtual void draw(Level* aktuellLevel)=0;

    //virtual definieren,deklarieren-rein virtual fgt deklare

};

#endif // ABSTRACTUI_H
