#ifndef LEVEL_H
#define LEVEL_H
#include "character.h"
#include "AllTiles.h"
#include <vector>
#include <string>
#include <MyStatics.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <typeinfo>
#include <QString>
#include <fstream>

class Controller;
class LevelExit;
class PlayerController;
class NavGraph;

class Level //die Karte bzw. das Spielfeld des Dungeon Crawlers
{
public:

    Level();
    Level(std::string toOpen);
    Level(Level &copylevel);
    ~Level();
    Tile *getTile(int x, int y);
    const Tile *getTile(int x, int y) const;
    void placeCharacter(Character *c, int x, int y);
    void printGrid();

    const std::vector<Character *> &getCharacters() const;
    void removeCharacter(Character * toRemove);
    void setCharacters(const std::vector<Character *> &newCharacters);

    void setGrid(const std::vector<std::vector<Tile *> > &newGrid);

    const std::vector<std::vector<Tile *> > &getGrid() const;

    const std::vector<Controller *> &getControllers() const;
    void removeController(Controller * toRemove);

    bool getlevelFinished() const;
    void setlevelFinished(bool newlevelFinished);

    bool getVictory() const;
    void setVictory(bool newVictory);

    enum LevelState {Goback,Stay,GoForth,Defeat,Victory};

    void levelChangerEntred(LevelExit *levelexit);
    void onPlayerDeath();
    void onVictory();
    LevelState getlevelstate() const;

    Character *getPlayerInLevel() const;

    void setPlayerInLevel(Character *newPlayerInLevel);

    int getBreite() const;

    int getHoehe() const;

    LevelExit *getEntryStairCase() const;

    LevelExit *getExitStairCase() const;

    PlayerController *getPlayerController() const;
    void setPlayerController(PlayerController *newPlayerController);

    NavGraph *getNavGraph() const;
    void setNavGraph(NavGraph *newNavGraph);

    void setBreite(int newBreite);

    void setHoehe(int newHoehe);

    void setEntryStairCase(LevelExit *newEntryStairCase);

    void setExitStairCase(LevelExit *newExitStairCase);

    void initialize();
    void saveGame();
    void onCharacterDeath(Character *character);



    const std::vector<Character *> &getEnemies() const;
    void setEnemies(const std::vector<Character *> &newEnemies);

    const std::vector<Controller *> &getEnemyControllers() const;
    void setEnemyControllers(const std::vector<Controller *> &newEnemyControllers);

private:

    std:: vector<std::vector<Tile *>> grid;//={{new Tile(0,0),new Tile(0,1)},{new Tile(1,0),new Tile(1,1)}};//gitter simiha az koja bedune cheghadr dare
    std:: vector<Character*> enemies;
    std::vector<Controller*>enemyControllers;

    PlayerController *playerController=nullptr;
    //Character *playerInLevel=nullptr;

    void setChasingControllersTarget();
    void writeCharacterToFile(Character *tosave,std::stringstream &stream);

    void saveCharacterFile();
    std::string GetCharacterFileLocation();



    int _breite=0;
    int _hoehe=0;

    std::string _fileLocation;

    bool victory=false;
    bool levelFinished=false;
    Character *_playerCharacter=nullptr;

    LevelState _levelstate=Goback;
    void ReadLevelFile(QString toOpen);
    void initializearrays();
    int createTileAtPos(char tileTexture,int x ,int y);

    LevelExit * _entryStairCase=nullptr;
    LevelExit * _exitStairCase=nullptr;

    void addPairsEntry(int pair);
    Tile *lastPortal=nullptr;
    Passive *lastPassive=nullptr;
    Active *lastActive=nullptr;
    LevelExit *lastLevelExit=nullptr;


    static const int MAX_PAIRS=10;
    std::vector<Portal*>portalPairs[MAX_PAIRS];
    std::vector<Active*>activs[MAX_PAIRS];
    std::vector<Passive*>passivs[MAX_PAIRS];

    void connectAllPortals();
    void connectAllActivsAndPassivs();
    void connectPassivsToActivs(int arrayIndex);
    void connectPassivsToActiv(int arrayIndex,int activeInex);
    void connectPassivToActiv(int arrayIndex,int activeIndex,int passivIndex);

    NavGraph *_navGraph=nullptr;



};

#endif // LEVEL_H
