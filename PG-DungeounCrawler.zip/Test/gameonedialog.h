#ifndef GAMEONEDIALOG_H
#define GAMEONEDIALOG_H

#include <QDialog>

namespace Ui {
class GameoneDialog;
}

class GameoneDialog : public QDialog
{
    Q_OBJECT

public:
    explicit GameoneDialog(QWidget *parent = nullptr);
    ~GameoneDialog();

private:
    Ui::GameoneDialog *ui;
};

#endif // GAMEONEDIALOG_H
