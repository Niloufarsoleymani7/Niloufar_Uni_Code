#include "list.h"
#include <iostream>

using std::cout;
using std::endl;

List::List()
{
}

List::~List()
{
  while (start != nullptr)
  {
    pop_back();
  }
}

void List::push_back(int data)
{
  Element* tmp = new Element{data, nullptr};

  // list is empty
  if (empty())
  {
    start = tmp;
    m_size++;
    return;
  }

  // search last Element
  Element* current = start;
  while (current->next != nullptr)
  {
    // advance current pointer by one element
    current = current->next;
  }
  current->next = tmp;
  m_size++;
}

void List::print() const
{
  // In order to iterate over the list, we need a "current element" pointer
  // which is then advanced by one element in each iteration
  Element* current = start;
  while (current != nullptr)
  {
    cout << current->data << " ";
    current = current->next;
  }
  cout << endl;
}

void List::pop_back()
{
  // list is already empty
  if (start == nullptr)
  {
    return;
  }

  // list has single element
  if (start->next == nullptr)
  {
    delete start;
    start = nullptr;
    return;
  }

  // if list has 2 or more elements, look for the second last element
  Element* current = start;
  while (current->next->next != nullptr)
  {
    current = current->next;
  }
  delete current->next;
  current->next = nullptr;
  m_size--;
}

std::size_t List::size() const
{
  return m_size;
}

bool List::empty() const
{
  return m_size == 0;
  // Alternatively: return start == nullptr;
}

