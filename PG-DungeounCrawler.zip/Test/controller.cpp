#include "controller.h"

Controller::Controller(Character * who,Level * nLevel):_controlling(who)
{
    _level=nLevel;
}



Position Controller::getPosition()
{

}

Level *Controller::getLevel() const
{
    return _level;
}

void Controller::setLevel(Level *newLevel)
{
    _level = newLevel;
}

Character *Controller::getControlling() const
{
    return _controlling;
}



Controller::~Controller()
{

}
