#ifndef HEALTHBAR_H
#define HEALTHBAR_H
#include <QWidget>
#include <QLabel>
#include<MyStatics.h>

class CollerdBar: public QWidget
{
public:
    CollerdBar(QWidget *parent,QPixmap &farbe);
    QLabel *hintegrundLabel=nullptr;
    QLabel *coloredBar=nullptr;
    QLabel *graueBalken=nullptr;
    QLabel *zahl=nullptr;
    void updateBar(float curent,float max);
    void initialisieren();

};

#endif // HEALTHBAR_H
