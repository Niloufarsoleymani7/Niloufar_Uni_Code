#ifndef GAMEOVERDIALOG_H
#define GAMEOVERDIALOG_H

#include <QDialog>
#include<mainwindow.h>
#include "startscreen.h"
#include<MyStatics.h>


namespace Ui {
class GameOverDialog;
}
class MainWindow;


class GameOverDialog : public QDialog
{
    Q_OBJECT

public:
    explicit GameOverDialog(QWidget *parent = nullptr,MainWindow *mainwindow=nullptr);
    ~GameOverDialog();

public slots:

    void accept()override;
    void reject()override;

private:
    Ui::GameOverDialog *ui;
    void deletGame();
    MainWindow *mw=nullptr;
};

#endif // GAMEOVERDIALOG_H
