#include "gameoverdialog.h"
#include "ui_gameoverdialog.h"

GameOverDialog::GameOverDialog(QWidget *parent,MainWindow *mainwindow) :
    QDialog(parent),
    ui(new Ui::GameOverDialog),mw(mainwindow)
{
    ui->setupUi(this);
    QPixmap *pixmap1=new QPixmap;
    pixmap1->load(gameoverLocation);
    ui->label->setPixmap(*pixmap1);
    ui->label->setScaledContents(true);

}

GameOverDialog::~GameOverDialog()
{
    delete ui;
}

void GameOverDialog::accept()
{
    deletGame();

}

void GameOverDialog::reject()
{
    deletGame();

}

void GameOverDialog::deletGame()
{
    StartScreen *sc=new StartScreen(nullptr);
    sc->show();
    delete mw;

}
