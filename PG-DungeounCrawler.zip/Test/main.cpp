#include "dungeoncrawler.h"
#include <QApplication>
#include<startscreen.h>
using namespace std;
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

int main(int argc , char * argv [])
{
    QApplication application(argc , argv );
    StartScreen *sc=new StartScreen;
    sc->show();
    return application. exec ();
}
