#ifndef CHEST_H
#define CHEST_H
#include<tile.h>
#include <level.h>
class Chest:public Tile
{
public:
    Chest(int x,int y);
    Tile* onEnter(Tile* fromTile, Character* who)override; //fromtile aktuelle Standort
    Tile* onLeave(Tile* destTile, Character* who)override;

};

#endif // CHEST_H
