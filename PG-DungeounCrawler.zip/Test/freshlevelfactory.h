#ifndef FRESHLEVELFACTORY_H
#define FRESHLEVELFACTORY_H
#include "levelfactory.h"

class Level;
class FreshLevelFactory:public LevelFactory
{
public:
    FreshLevelFactory();
    ~FreshLevelFactory();
    Level * BuildLevel(QString fileLocation) override;

};

#endif // FRESHLEVELFACTORY_H
