#ifndef NAVGRAPHAGENT_H
#define NAVGRAPHAGENT_H
#include "position.h"
class Level;
class NavGraph;

class NavGraphAgent
{
public:
    NavGraphAgent(Level * getNavGraphFrom);
    NavGraphAgent(NavGraph * navGraph);
    NavGraph *GetNavGraph() const;
    void SetNavGraph(NavGraph *newNavGraph);
    Position GetNextStep(Position from,Position to);


private:
    NavGraph * _navGraph;
    Position _position;
    Position _target;
};

#endif // NAVGRAPHAGENT_H
