#include "globalstatic.h"

GlobalStatic::GlobalStatic()
{

}
