#ifndef TERMINALUI_H
#define TERMINALUI_H
#include "abstractui.h"
#include "controller.h"

class TerminalUI :public AbstractUI,public Controller
{
public:
    TerminalUI();
    void draw(Level* aktuellLevel) override;
    void movemenu();
    int move() override;
    void moveToTile(int x,int y);
    Character *getCharacterToMove() const;
    void setCharacterToMove(Character *newCharacterToMove);
    Level *getActiveLevelInTerminalUi() const;
    void setActiveLevelInTerminalUi(Level *newActiveLevelInTerminalUi);
    //move methode was im character ist

private:
    Character *characterToMove=nullptr;
    Level *activeLevelInTerminalUi=nullptr;

};

#endif // TERMINALUI_H
