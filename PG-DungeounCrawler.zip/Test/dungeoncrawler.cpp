#include "dungeoncrawler.h"
#include "terminalui.h"
#include "levelbuilder.h"
#include "levelfactory.h"

DungeonCrawler::DungeonCrawler()
{
    LevelBuilder levelBuilder=LevelBuilder();
//    levels.PushBack(new Level (fileLocation));
//    levels.PushBack(new Level (fileLocation1));
//    levels.PushBack(new Level (fileLocation2));
//    levels.PushBack(new Level (fileLocation3));
//    levels.PushBack(new Level (fileLocation4));
    //levelListe.PushBack(new Level (fileLocation5));
    //pointerAufTerminalUi=new TerminalUI;

}
DungeonCrawler::DungeonCrawler(LevelFactory *levelFactory)
{
    _levels.PushBack(levelFactory->BuildLevel(fileLocation));
    _levels.PushBack(levelFactory->BuildLevel(fileLocation1));
    _levels.PushBack(levelFactory->BuildLevel(fileLocation2));
    _levels.PushBack(levelFactory->BuildLevel(fileLocation3));
    _levels.PushBack(levelFactory->BuildLevel(fileLocation4));
    _levels.PushBack(levelFactory->BuildLevel(fileLocation5));

    delete  levelFactory;
}

DungeonCrawler::~DungeonCrawler()
{


}

void DungeonCrawler::play()
{
//    pointerAufTerminalUi->movemenu();
//    //    while(true)
//    //  {
//    //                pointerAufTerminalUi->draw(activeLevel);
//    //                const std::vector<Character*> &charactersToMove=activeLevel->getCharacters();//const benivis vaella khata chon getcharacter const hAST

//    //                for(size_t i =0;i<charactersToMove.size();i++)
//    //                {

//    //                    charactersToMove.at(i)->move();
//    //               }

//    Level *copylevel=new Level (*activeLevel);
//    copylevel->getCharacters().back()->setControllerinChARACTER(pointerAufTerminalUi);

//    while(true)
//    {
//        pointerAufTerminalUi->draw(copylevel);
//        //pointerAufTerminalUi->draw(activeLevel);
//        const std::vector<Character*> &charactersToMove=copylevel->getCharacters();//const benivis vaella khata chon getcharacter const hAST

//        for(size_t i =0;i<charactersToMove.size();i++)
//        {

//            charactersToMove.at(i)->move();
//        }

//    }


    _pointerAufTerminalUi->draw(*_levels.Begin());

        while(true)
        {

            const std::vector<Controller *> entityControllerInLevel=_levels.Begin()->getEnemyControllers();
            for(unsigned int i=0;i<entityControllerInLevel.size();i++){
                //bool moved=entityControllerInLevel.at(i)->TryMove();
                //std::cout<<std::boolalpha<<moved<<std::endl;
                //if(!moved){
                    //return;
                //}
                _pointerAufTerminalUi->draw(*_levels.Begin());
            }
        }




}

AbstractUI *DungeonCrawler::getPointerAufAbstractui() const
{
    return _pointerAufAbstractui;
}

void DungeonCrawler::setPointerAufAbstractui(AbstractUI *newPointerAufAbstractui)
{
    _pointerAufAbstractui = newPointerAufAbstractui;
}

Level *DungeonCrawler::getActiveLevel()
{
    return *_levels.Begin();
}

void DungeonCrawler::setActiveLevel(Level *newActiveLevel)
{
    *_levels.Begin()= newActiveLevel;
}

TerminalUI *DungeonCrawler::getPointerAufTerminalUi() const
{
    return _pointerAufTerminalUi;
}

void DungeonCrawler::setPointerAufTerminalUi(TerminalUI *newPointerAufTerminalUi)
{
    _pointerAufTerminalUi = newPointerAufTerminalUi;
}

LevelList &DungeonCrawler::getLevelListe()
{
    return _levels;
}


