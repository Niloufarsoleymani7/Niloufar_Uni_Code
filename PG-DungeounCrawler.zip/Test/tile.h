#ifndef TILE_H
#define TILE_H
#include<string>
#include "character.h"
#include <MyStatics.h>
#include <fight.h>

class Character;

class Tile

        //stellt eine Kachel dar, kein Instanzerstellung moglich
        //erfordern für die Verwendung eine nicht-abstrakte abgeleitete Klasse
{
public:

    Tile(int new_posX,int new_posY);//moge tavalodesh lazem daram
    virtual Tile* onEnter(Tile* fromTile, Character* who); //fromtile aktuelle Standort
    virtual Tile* onLeave(Tile* destTile, Character* who);
    void setCharactarOnTile(Character *newCharactarOnTile);

    int getposX() const;
    int getposY() const;

    Character *getCharactarOnTile() const;

    bool hasCharacter();//return !=nullptr
    bool moveTo(Tile* destTile, Character* who); //virtual
    virtual ~Tile();  //fur die Vererbung
    char getTexture() const;

protected: //unterklassen konnen die vererben

    char texture=' ';//noe man chie
    Character *CharactarOnTile=nullptr;//man alan kashiam bayad bedunam welche /ob kasi hast
    const int posX;//immer mit initialliste zuweisen
    const int posY;//position Tile auf level

};

#endif // TILE_H
