#include "startscreen.h"
#include "ui_startscreen.h"
#include "loadlevelfactory.h"
#include "freshlevelfactory.h"

StartScreen::StartScreen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StartScreen)
{
    ui->setupUi(this);
    QPalette pal = this->palette();
    pal.setColor(QPalette::Window, Qt::black);
    this->setAutoFillBackground(true);
    this->setPalette(pal);

    //    std::unique_ptr<QPixmap>pixmap;
    //    pixmap = std::make_unique<QPixmap>(buttonNewGameLocation);
    //    QIcon buttonNewGame(*pixmap);
    //    ui->newGameButton->setIcon(buttonNewGame);


    ui->newGameButton->setGeometry((width()-buttonSize*3)/2,height()-buttonSize*3,buttonSize*3,buttonSize);

    QPixmap *pixmap1=new QPixmap;
    pixmap1->load(startScreenPhotoLocation);
    ui->startscreenLabel->setPixmap(*pixmap1);
    ui->startscreenLabel->setScaledContents(true);
    connect(ui->newGameButton,&QPushButton::pressed,this,&StartScreen::startGame);//ohne kallamer

    loadGameButton=new QPushButton(this);
    loadGameButton->setGeometry((width()-buttonSize*3)/2,height()-(buttonSize*3)/2,buttonSize*3,buttonSize);
    loadGameButton->setText("Load Game");
    connect(loadGameButton,&QPushButton::pressed,this,&StartScreen::LoadGame);

    //delete pixmap1;

}

StartScreen::~StartScreen()
{
    delete ui;
}

void StartScreen::startGame()
{
    //    dc=new DungeonCrawler();
    //    mw=new MainWindow(nullptr,dc);
    //    mw->show();
    //    this->hide();
    FreshLevelFactory * factory=new FreshLevelFactory();
    mw=new MainWindow(nullptr,new DungeonCrawler(factory));
    mw->show();
    delete this;
}

void StartScreen::LoadGame()
{
    LoadLevelFactory * factory=new LoadLevelFactory();
    mw=new MainWindow(nullptr,new DungeonCrawler(factory));
    mw->show();
    delete this;

}


