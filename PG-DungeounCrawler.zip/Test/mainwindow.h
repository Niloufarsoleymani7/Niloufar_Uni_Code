#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include "dungeoncrawler.h"
#include<QLabel>
#include<MyStatics.h>
#include<memory>
#include <QPushButton>
#include<healthbar.h>
#include<guardcontroller.h>
#include <QKeyEvent>
#include<gameoverdialog.h>
#include<victorydialog.h>
#include "enemycollection.h"
#include <levelList.h>

class PlayArea;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr,DungeonCrawler *newDungeonCrawler=nullptr);
    ~MainWindow();

    movedirection getLasDirectionMoved() const;

public slots:

    void saveGame();

    void moveDownRight();
    void moveDown();
    void moveDownLeft();
    void moveRight();
    void moveStay();
    void moveLeft();
    void moveupRight();
    void moveup();
    void moveUpLeft();

private:

    Ui::MainWindow *ui;
    std::vector<std::vector<QLabel*>>  qLabelQrid;
    std::vector<std::vector<QPushButton>> qPushButtonArrowsList;
    movedirection lasDirectionMoved=movedirection::down; //am anfang

    QLabel *playerImageLabel;
    QLabel *enemyImageLabel;
    QPushButton *_savebutton=nullptr;

    DungeonCrawler *pointerDungeonCrawler= nullptr;

    int labelSize;
    int animationCycle=0;

    void setLAbelTexture(QLabel *toChange,Tile *toApply);
    void createLabelGrid();
    void drawLevel();
    void configControls();
    void setPushButtonImage();



    void movePlayerImage(int x,int y);
    void moveEnemyImage(QLabel *qlabel,int x,int y);
    void movePlayer(int x,int y);
    void moveAllEnemies();
    void keyPressEvent(QKeyEvent *event);

    CollerdBar *playerHealthBar=nullptr;
    CollerdBar *playerStamina=nullptr;

    std::vector<EnemyCollection> _enemies=std::vector<EnemyCollection>();
    CollerdBar *enemyHealthBar=nullptr;
    CollerdBar *enemyStamina=nullptr;
    Character *enemyCharacterPointer=nullptr;
    Controller *controllerPointer=nullptr;

    LevelList::LevelIterator curentLevel;
    PlayArea *_playarea=nullptr;
    int gamesizeX;
    int gameSizeY;

    void levelFinished();
    void loadNextLevel();
    void loadPrevLevel();
    void deleteLevel();

    void gameVictory();
    void gameDeFeat();
    void deleteOldGame();
    void startNewGame();
    void createLabels();
    void teleportCharacterToNextLevel();
    void teleportCharacterToPrevLevel();


};
#endif // MAINWINDOW_H
