#include "tile.h"
#include <iostream>

Tile::Tile(int new_posX,int new_posY):posX(new_posX),posY(new_posY)//andaze Tile ke cheghadr bashe va dar harkodum anjam midam
{

}

int Tile::getposX() const
{
    return  posX ;
}

int Tile::getposY() const
{
    return posY;
}



bool Tile::hasCharacter()
{
    return CharactarOnTile!=nullptr;//dige nemikhad if benivisam
}

bool Tile::moveTo(Tile *destTile, Character *who)//von this nach dest
{

std::cout<<typeid(*destTile).name()<<std::endl;
    Tile *speicherVonVerlasseneTile=onLeave(destTile,who);//Tile speicherVonVerlasseneTile; injuri daram obj tolid mikonam
    //ob ich verlassen darf,dar surati mitunam beram ke betunam varede hadaf sham,und was passiert wenn ich verlasse

    if(speicherVonVerlasseneTile==nullptr)//niergendswohin,ich kann mich nicht bewegen z.b wand
    {
        return false;
    }
    else
    {
        Tile *speicherVonBetreteneTile=destTile->onEnter(this,who);//ob die andere(zielkache) betretten werden darf
        //desttile ist unser zielkache, va onenter baraye desttile bayad seda zade beshe
        if(speicherVonBetreteneTile== nullptr)
        {
            return false;
        }
        else
        {
            //1 char ra bezar ruye destile vasl mikonim
            //2destile char ro migire
            //3fromtile char=0
            speicherVonBetreteneTile->setCharactarOnTile(CharactarOnTile);
            who->setTileDerIchDarufStehe(speicherVonBetreteneTile);
            if(speicherVonVerlasseneTile!=speicherVonBetreteneTile)
            {
            CharactarOnTile=nullptr;}
            //unser pointer die auf charater zeigt muss nullptr,weil ma mirim birun az un bayad khgali she
            //jetzt c auf ziel und zial auf c
            return true;
        }
    }
}

Tile::~Tile()
{

}

char Tile::getTexture() const
{
//    if(CharactarOnTile!=nullptr) //age kasi hast rush bara unam
//    {
//        return CharactarOnTile->getTexture();
//    }

    return texture;
}

Tile *Tile::onEnter(Tile *fromTile, Character *who)//was beim Betreten einer Kachel passieren soll
{
    //az koja daram miam
    //mabda this maghsad dest
    //natunam vared sham nullptr

    return nullptr;
}

Tile *Tile::onLeave(Tile *destTile, Character *who)//age sefr bashe yani man harakat nakardam
{
    //be koja daram miram,natunam beram mishe sefr
    return nullptr;
}

Character *Tile::getCharactarOnTile() const
{
    return CharactarOnTile;
}

void Tile::setCharactarOnTile(Character *newCharactarOnTile)
{
    std::cout<<"working"<<std::endl;
    CharactarOnTile = newCharactarOnTile;
}
