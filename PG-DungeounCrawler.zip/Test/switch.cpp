#include "switch.h"

Switch::Switch(int x,int y):Floor(x,y)
{
    texture=textureswitchS;
}
Tile *Switch::onEnter(Tile *fromTile, Character *who)//azkoja miam mabda this hadaf dest
 {
    if(hasCharacter()&&who!=CharactarOnTile){
        Fight f=Fight(who,CharactarOnTile);
        return nullptr;}
    activate();
    return this;//wie floor alle seine passive objecte

 }

Tile *Switch::onLeave(Tile *destTile, Character *who)//age sefr bashe yani man harakat nakardam bekoja daram miram
{

    return this;//wie floor
}
