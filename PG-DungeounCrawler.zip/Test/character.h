#ifndef CHARACTER_H
#define CHARACTER_H
#include <string>
#include<controller.h>
#include <healthbar.h>

class Tile; //soluton for recursive include bool compare ( Level * other );
class Level;

class Character //Spielfiguren Held/Heldin und NPCs
{
public:
    Character(int p_strength, int p_stamina);
    Character(int maxStamina, int curStamina,int strenght ,int curHealth,char id);
    ~Character();
    const char &getTexture() const;
    void setTileDerIchDarufStehe(Tile *newTileDerIchDarufStehe);
    void move();

    Tile *getTileDerIchDarufStehe()const ;
    Level *getLevel() const;
    void setLevel(Level *newLevel);
    void setControllerinChARACTER(Controller *newControllerinChARACTER);

    int getHitpoints();
    int getMaxHitpoints()const;
    int getStrength();

    CollerdBar *healthbar=nullptr;
    CollerdBar *staminaBar=nullptr;
    bool useStamina(int staminaToUse);
    void takeDAmage(int damage);
    void settexture(char newTexture);


    void setStamina(int newStamina);

    CollerdBar *getHealthbar() const;
    void setHealthbar(CollerdBar *newHealthbar);

    void setStrength(int newStrength);

    int getStamina() const;

    void setHitpoints(int newHitpoints);

    int getMaxStamina() const;
    void setMaxStamina(int newMaxStamina);

    bool getIstDead() const;
    void setIstDead(bool newIstDead);

private:

    char _texture=' ';
    Tile* _tileDerIchDarufStehe=nullptr;//bedunam man ru chi hastam
    Level *level=nullptr;
    Controller* _controllerinCharacter=nullptr;//das macht pointer.move() ich muss an char auch ubergeben
    int _strength=100;
    int _stamina=100;
    int _maxStamina=100;
    int _hitpoints=100;
    bool _istDead=false;


};

#endif // CHARACTER_H
