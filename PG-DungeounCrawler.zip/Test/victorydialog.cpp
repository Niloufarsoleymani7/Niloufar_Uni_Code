#include "victorydialog.h"
#include "ui_victorydialog.h"

VictoryDialog::VictoryDialog(QWidget *parent,MainWindow *mainwindow):
    QDialog(parent),
    ui(new Ui::VictoryDialog),mw(mainwindow)
{
    ui->setupUi(this);
    QPixmap *pixmap1=new QPixmap;
    pixmap1->load(victoryLocation);
    ui->label->setPixmap(*pixmap1);
    ui->label->setScaledContents(true);



}

VictoryDialog::~VictoryDialog()
{
    delete ui;
}

void VictoryDialog::accept()
{
    deletGame();

}

void VictoryDialog::reject()
{
    deletGame();

}

void VictoryDialog::deletGame()
{
    StartScreen *sc=new StartScreen(nullptr);
    sc->show();
    delete mw;

}
