#include "active.h"
#include "passive.h"
#include <typeinfo>
#include <iostream>
Active::Active()
{

}

void Active::attach(Passive *passiveObject)//add obj in list
{

    for ( auto &goInList : listOfPassiveObjects)
    {
        if ( typeid ( goInList) == typeid ( passiveObject ))
        {
            std::cout<<"This Object is on liststd";
            return;//endet for schleife
        }
    }
     listOfPassiveObjects.push_back(passiveObject);
}

void Active::detach(Passive *passiveObject)//remove passiv obj from list
{
    int i=0;

    for ( auto &goInList : listOfPassiveObjects)
    {
        if ( typeid ( goInList) == typeid ( passiveObject ))
        {
            listOfPassiveObjects.erase(listOfPassiveObjects.begin()+i );
            return;
        }
        i++;
    }
}

void Active::activate()
{
    int i=0;

    for ( auto &goInList : listOfPassiveObjects)
    {
        goInList->notify(this);
        i++;
    }
}

const std::vector<Passive *> &Active::getListOfPassiveObjects() const
{
    return listOfPassiveObjects;
}

void Active::setListOfPassiveObjects(const std::vector<Passive *> &newListOfPassiveObjects)
{
    listOfPassiveObjects = newListOfPassiveObjects;
}













