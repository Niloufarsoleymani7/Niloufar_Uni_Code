#ifndef WALL_H
#define WALL_H
#include "tile.h"
#include <MyStatics.h>

class Wall:public Tile //eine nicht betretbare Wand
{
public:

    Wall(int x,int y);
    Tile* onEnter(Tile* fromTile, Character* who) override;
    Tile* onLeave(Tile* destTile, Character* who) override;
    ~Wall()override;
};

#endif // WALL_H
