#include "chasecontroller.h"

ChaseController::ChaseController(Character * nControlling,Level * nLevel,NavGraphAgent * navGraphAgent):Controller(nControlling,nLevel)
{
    _navGraphAgent=navGraphAgent;
}

bool ChaseController::TryMove(Position &inputPos)
{
    return TryMove();
}

bool ChaseController::TryMove()
{
    _movePower++;
    Tile * controllingTile = _controlling->getTileDerIchDarufStehe();

    if(_movePower<_moveCost)
    {
        controllingTile->moveTo(controllingTile,_controlling);

        return false;
    }
    _movePower-=_moveCost;

    int controlingPosX=_controlling->getTileDerIchDarufStehe()->getposX();
    int controlingPosY=_controlling->getTileDerIchDarufStehe()->getposY();
    Position controllingPos(controlingPosX,controlingPosY);

    int _chasingPosX= _chasing->getTileDerIchDarufStehe()->getposX();
    int _chasingPosY= _chasing->getTileDerIchDarufStehe()->getposY();

    Position targetPos(_chasingPosX,_chasingPosY);

    Position moveDir=_navGraphAgent->GetNextStep( controllingPos,targetPos);
    Position nextStepTilePosition = controllingPos+moveDir;

    int nextStepTilePositionX=nextStepTilePosition.x;
    int nextStepTilePositionY=nextStepTilePosition.y;

    Tile * targetTile=_level->getTile(nextStepTilePositionX,nextStepTilePositionY);

    controllingTile->moveTo(targetTile,_controlling);

    //lastDirectionMoved=moveDir;

    return true;
}

int ChaseController::move()
{

}

Position ChaseController:: getPosition()
{
    int x=  _controlling->getTileDerIchDarufStehe()->getposX();
    int y=_controlling->getTileDerIchDarufStehe()->getposY();
    Position pos(x,y);
    return pos;
}

Character *ChaseController::GetChasing() const
{
    return _chasing;
}

void ChaseController::SetChasing(Character *newChasing)
{
    _chasing = newChasing;
}
