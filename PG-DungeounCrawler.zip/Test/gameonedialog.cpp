#include "gameonedialog.h"
#include "ui_gameonedialog.h"

GameoneDialog::GameoneDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GameoneDialog)
{
    ui->setupUi(this);
}

GameoneDialog::~GameoneDialog()
{
    delete ui;
}
