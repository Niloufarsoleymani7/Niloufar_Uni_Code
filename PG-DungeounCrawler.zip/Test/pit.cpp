#include "pit.h"

Pit::Pit(int x,int y):Tile(x,y)
{
    texture=texturepit;
}

Tile *Pit::onEnter(Tile *fromTile, Character *who)
{   
    if(hasCharacter()&&who!=CharactarOnTile)
    {
        Fight f=Fight(who,CharactarOnTile);
        return nullptr;
    }
    if(typeid(*fromTile)==typeid(Floor))
    {
        who->takeDAmage(10);

        std::cout<<"took damage"<<std::endl;
    }
    return this;
}

Tile *Pit::onLeave(Tile *destTile, Character *who)
{
    //wenn pit or ramp this wenn nicht nullptr
    //nur von pit or ramp
    //mitunam ba cast dynamic cast chek konm
    if (destTile->getTexture()==texturepit or destTile->getTexture()==textureramp)
    {
        return this;
    }
    else
    {
        return nullptr;
    }

}
