#ifndef LEVELFACTORY_H
#define LEVELFACTORY_H
#include <QString>
class Level;
class LevelFactory
{
public:
    LevelFactory();
    ~LevelFactory();
    virtual Level * BuildLevel(QString fileLocation)=0;
};

#endif // LEVELFACTORY_H
