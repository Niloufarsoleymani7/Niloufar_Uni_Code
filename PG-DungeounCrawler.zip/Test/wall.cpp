#include "wall.h"
#include <iostream>

Wall::Wall(int x,int y):Tile(x,y)
{
    texture=texturewall;

}

Tile *Wall::onEnter(Tile *fromTile, Character *who)
{
    return nullptr;
}

Tile *Wall::onLeave(Tile *destTile, Character *who)
{

    return this;
}

Wall::~Wall()
{

}
