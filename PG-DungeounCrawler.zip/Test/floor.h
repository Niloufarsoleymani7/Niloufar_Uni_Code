#ifndef FLOOR_H
#define FLOOR_H
#include "tile.h"
#include <MyStatics.h>

class Floor :public Tile //eine normale, betretbare, Bodenkachel
{
public:

    Floor(int x,int y);
    Tile* onEnter(Tile* fromTile, Character* who) override;
    Tile* onLeave(Tile* destTile, Character* who) override;
    ~Floor()override;

};

#endif // FLOOR_H
