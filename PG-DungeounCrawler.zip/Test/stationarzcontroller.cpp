#include "stationarzcontroller.h"

StationarzController::StationarzController(Character * who,Level * nLevel):Controller(who,nLevel)
{

}

StationarzController::~StationarzController()
{
_level->removeController(this);
}

int StationarzController::move()
{

    Tile *tileDerIchDaraufBin=_controlling->getTileDerIchDarufStehe();
    tileDerIchDaraufBin->moveTo(tileDerIchDaraufBin,_controlling);
}
