#include "terminalui.h"
#include<iostream>
#include <conio.h>
TerminalUI::TerminalUI():Controller(nullptr,nullptr)
{}

void TerminalUI::draw(Level *aktuellLevel)
{
    activeLevelInTerminalUi=aktuellLevel;
    activeLevelInTerminalUi->printGrid();
}

void TerminalUI::movemenu()
{
    std::cout << "\n Bewegungs-Menue \n"
            " 7: Links-Hoch   8: Hoch    9: Rechts-Hoch \n"
            " 4: Links        5: Nichts  6: Rechts \n"
            " 1: Links-Unten  2: Unten   3: Rechts-Unten \n"
            " 0: Spiel beenden" << std::endl;

}
int TerminalUI::move()
{
    characterToMove=_controlling;

    char entered_botton=(getch());
    int x;
    int y;
    x = characterToMove->getTileDerIchDarufStehe()->getposX();
    y = characterToMove->getTileDerIchDarufStehe()->getposY();
  std::cout <<"from "<<x<<" "<<y<<std::endl;
    switch(entered_botton)
    {
    case '0':
        exit(1);
    case '1':moveToTile(x-1,y+1);;break;
    case '2':moveToTile(x,y+1);break;
    case '3': moveToTile(x+1,y+1);break;
    case '4':moveToTile(x-1,y);break;
    case '5': break;
    case '6':moveToTile(x+1,y);break;
    case '7':moveToTile(x-1,y-1);break;
    case '8':moveToTile(x,y-1);break;
    case '9':moveToTile(x+1,y-1);break;
    default:
        std::cout<<"\n\t\t\t!!!Falsche Buttom!!!\n"<<std::endl;
    characterToMove=nullptr;
}
}

void TerminalUI::moveToTile(int x, int y)
{
    std::cout <<"to "<<x<<" "<<y<<std::endl;
    bool result=characterToMove->getTileDerIchDarufStehe()->moveTo(activeLevelInTerminalUi->getTile(x,y),characterToMove);
    std::cout<<std::boolalpha<<result<<std::endl;

}

Character *TerminalUI::getCharacterToMove() const
{
    return characterToMove;
}

void TerminalUI::setCharacterToMove(Character *newCharacterToMove)
{
    characterToMove = newCharacterToMove;
}

Level *TerminalUI::getActiveLevelInTerminalUi() const
{
    return activeLevelInTerminalUi;
}

void TerminalUI::setActiveLevelInTerminalUi(Level *newActiveLevelInTerminalUi)
{
    activeLevelInTerminalUi = newActiveLevelInTerminalUi;
}


