#include "passive.h"

Passive::Passive()
{

}

Passive::~Passive()
{

}
