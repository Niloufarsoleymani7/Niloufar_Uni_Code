#include "guardcontroller.h"

GuardController::GuardController(Character *who,Level* nLevel):Controller(who,nLevel)//chon ersmibare
{

}

GuardController::~GuardController()
{
_level->removeController(this);
}

int GuardController::move()
{
    switch(pattern[cycle%arraySize])
    {
    case movedirection::left:
        moveLeft(_controlling);
        break;
    case movedirection::right:
        moveRight(_controlling);
        break;

    default:
        break;
    }
    cycle++;
    return 0;

}

bool GuardController::TryMove(Position &inputPos)
{

}

bool GuardController::TryMove()
{

}

Position GuardController::getPosition()
{

}

int GuardController::moveLeft(Character *who)
{


    Tile *tileDerIchDaraufBin=who->getTileDerIchDarufStehe();
    int targetX=tileDerIchDaraufBin->getposX()-1;
    int targetY=tileDerIchDaraufBin->getposY();
    Tile *destinationTile= who->getLevel()->getTile(targetX,targetY);
    tileDerIchDaraufBin->moveTo(destinationTile,who);

}

int GuardController::moveRight(Character *who)
{
    Tile *tileDerIchDaraufBin=who->getTileDerIchDarufStehe();
    int targetX=tileDerIchDaraufBin->getposX()+1;
    int targetY=tileDerIchDaraufBin->getposY();
    Tile *destinationTile= who->getLevel()->getTile(targetX,targetY);
    tileDerIchDaraufBin->moveTo(destinationTile,who);

}
