#include "loadlevelfactory.h"
#include "levelbuilder.h"
LoadLevelFactory::LoadLevelFactory()
{

}

LoadLevelFactory::~LoadLevelFactory()
{

}

Level *LoadLevelFactory::BuildLevel(QString fileLocation)
{
    return LevelBuilder().BuildOldLevel(fileLocation);
}


