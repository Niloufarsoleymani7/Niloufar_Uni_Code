#ifndef STARTSCREEN_H
#define STARTSCREEN_H
#include <QDialog>
#include<MyStatics.h>
#include<QLabel>
#include <dungeoncrawler.h>
#include <mainwindow.h>


namespace Ui
{
class StartScreen;
}
class MainWindow;

class StartScreen : public QDialog
{
    Q_OBJECT

public:
    explicit StartScreen(QWidget *parent = nullptr);
    ~StartScreen();

public slots:
    void startGame();
    void LoadGame();

private:
    Ui::StartScreen *ui;
    MainWindow *mw;
    DungeonCrawler *dc;
    QPushButton * loadGameButton;

};

#endif // STARTSCREEN_H


