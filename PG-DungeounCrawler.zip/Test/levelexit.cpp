#include "levelexit.h"
#include <level.h>
LevelExit::LevelExit(int x,int y,Level *pointerAufLevel_p):Tile(x,y)
{
    pointerAufLevel=pointerAufLevel_p;
    texture=textureLevelChanger;

}

Tile *LevelExit::onEnter(Tile *fromTile, Character *who)
{
    if (who->getTexture()==textureplayer)
    {
        pointerAufLevel->levelChangerEntred(this);

    }
    return this;
}

Tile *LevelExit::onLeave(Tile *destTile, Character *who)
{

    return this;
}
