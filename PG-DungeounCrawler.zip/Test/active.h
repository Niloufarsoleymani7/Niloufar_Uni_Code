#ifndef ACTIVE_H
#define ACTIVE_H
#include <vector>

class Passive;

class Active
{
public:

    Active();
    void attach(Passive* passiveObject);//als virtual?
    void detach(Passive* passiveObject);
    virtual void activate();
    const std::vector<Passive *> &getListOfPassiveObjects() const;
    void setListOfPassiveObjects(const std::vector<Passive *> &newListOfPassiveObjects);

protected:
    std:: vector<Passive*>listOfPassiveObjects;


};

#endif // ACTIVE_H
