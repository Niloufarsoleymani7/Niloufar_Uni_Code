#include "portal.h"

Portal::Portal(int x,int y):Tile(x,y)
{
    texture=textureportal;
}

Tile *Portal::onEnter(Tile *fromTile, Character *who)
{
    if(hasCharacter()&&who!=CharactarOnTile){
        Fight f=Fight(who,CharactarOnTile);
        return nullptr;}
 std::cout<<destination<<std::endl;
    return destination;
}

Tile *Portal::onLeave(Tile *destTile, Character *who)
{

    return this;
}

Tile *Portal::getDestination() const
{
    return destination;
}

void Portal::setDestination(Tile *newDestination)
{
    destination = newDestination;
    std::cout<<destination<<std::endl;
}

Portal::~Portal()
{

}
