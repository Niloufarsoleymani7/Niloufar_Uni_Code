#ifndef STATIONARZCONTROLLER_H
#define STATIONARZCONTROLLER_H
#include<controller.h>
#include<tile.h>
#include <level.h>

class StationarzController : public Controller
{
public:
    StationarzController(Character * who,Level * nLevel);
    ~StationarzController();
    int move()override;

};

#endif // STATIONARZCONTROLLER_H
