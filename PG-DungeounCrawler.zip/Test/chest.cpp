#include "chest.h"

Chest::Chest(int x,int y):Tile(x,y)
{
    texture=texturerChest;
}

Tile *Chest::onEnter(Tile *fromTile, Character *who)
{
    if (who->getTexture()==textureplayer)
    {

        who->getLevel()->onVictory();
    }
    return this;
}

Tile *Chest::onLeave(Tile *destTile, Character *who)
{
    return this;
}
