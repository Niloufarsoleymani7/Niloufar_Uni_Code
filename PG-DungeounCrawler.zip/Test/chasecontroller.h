#ifndef CHASECONTROLLER_H
#define CHASECONTROLLER_H
#include<controller.h>
#include <level.h>
#include <navgraphagent.h>

class Level;
class ChaseController:public Controller
{
public:
    ChaseController(Character * nControlling,Level * nLevel,NavGraphAgent * navGraphAgent);
    bool TryMove(Position &inputPos) override;
    bool TryMove() override;
    int move ()override;
    Position getPosition() override;

    Character *GetChasing() const;
    void SetChasing(Character *newChasing);

private:
    NavGraphAgent * _navGraphAgent=nullptr;
    Character * _chasing;

    int _movePower=0;
    const int _moveCost=2;
};

#endif // CHASECONTROLLER_H
