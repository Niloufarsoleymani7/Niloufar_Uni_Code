#include "navgraph.h"
#include<queue>
#include<level.h>
#include<AllTiles.h>

NavGraph::NavGraph(Level *level):tileGrid(level->getGrid())
{

}

NavGraph::~NavGraph()
{
   deletegrid();
}


std::vector<Position> NavGraph::calculatePath(Position start, Position finish)
{
    std::queue<Entry> toVisit=std::queue<Entry>();
    Entry curent;
    toVisit.push(Entry{getNodeByposition(start),getNodeByposition(start)});
    while (!toVisit.empty())
    {
        curent=toVisit.front();//erst nehmen dann loschen
        toVisit.pop();
        if(!curent.node->visited)
        {
            for (std::size_t i=0;i<curent.node->neighbours.size();i++)
            {
                toVisit.push(Entry{curent.node,curent.node->neighbours.at(i).node});
            }
            curent.node->path=curent.caller->path;
            curent.node->path.push_back(curent.node->pos);
            curent.node->visited=true;
            if(curent.node->pos ==finish)
            {
                break;
            }
        }
    }
    std::vector<Position>result =convertPositionToDirectionVec(getNodeByposition(finish)->path);
    resetNodes();
    return result;
}

void NavGraph::BakeGrid()
{
    deletegrid();
    createGrid();
    analyseneighbours();
    resetNodes();
}

void NavGraph::notify(Active *source)
{
    BakeGrid();
}

NavGraph::Node *NavGraph::getNodeByposition(Position pos)
{
return nodeGrid.at(pos.y).at(pos.x);
}

void NavGraph::resetNodes()
{

    for(unsigned int y =0;y<nodeGrid.size();y++){
        for(unsigned int x=0;x<nodeGrid.at(y).size();x++){
            nodeGrid.at(y).at(x)->reset();
        }
    }


}

void NavGraph::deletegrid()
{
    for(unsigned int y =0;y<nodeGrid.size();y++){
            for(unsigned int x=0;x<nodeGrid.at(y).size();x++){
                delete nodeGrid.at(y).at(x);
            }
        }
        nodeGrid.clear();


}

void NavGraph::createGrid()
{
    //deletegrid();
    for(unsigned int y =0;y<tileGrid.size();y++){
        nodeGrid.push_back(std::vector<Node *>());
        for(unsigned int x=0;x<tileGrid.at(y).size();x++){
            nodeGrid.at(y).push_back(new Node());
            nodeGrid.at(y).at(x)->pos=Position(x,y);
        }
    }

}

void NavGraph::analyseneighbours()//wenn ich nur tile bin ause wand pitsts doorzu
//onexit
{
    for( size_t y=0;y<tileGrid.size();y++){
        for( size_t x=0;x<tileGrid.at(y).size();x++)
        {
            Tile *currtile= tileGrid.at(y).at(x);
            switch(tileGrid.at(y).at(x)->getTexture()){
            case texturewall:
            case textureportal:
            case texturedoorClose:
                break;
            case texturedoorOpen:
            case texturefloor:
            case textureLevelChanger:
            case textureswitchS:
            case textureramp:
                connectDeafult(x,y);
                break;
            case texturepit:
                connectPit(x,y);
            }
        }
    }
}

void NavGraph::connectDeafult(unsigned int posx, unsigned int posy)//wenn ich keine beschrankung habe wo ich hib gehen kann
{
    //onenter
    Node *nodeCurent=getNodeByposition(Position(posx,posy));
    int beginX=nodeCurent->pos.x-1;
    int finishX=nodeCurent->pos.x+1;

    int beginY=nodeCurent->pos.y-1;
    int finishY=nodeCurent->pos.y+1;

    for( int y=beginY;y<=finishY;y++){
        for( int x=beginX;x<=finishX;x++)
        {

            switch(tileGrid.at(y).at(x)->getTexture()){
            case texturewall:
            case textureportal:
            case texturedoorClose:
                break;
            case texturedoorOpen:
            case texturefloor:
            case textureLevelChanger:
            case textureswitchS:
            case textureramp:
            case texturepit:
                nodeCurent->addNeighbour(getNodeByposition(Position(x,y)));
                break;
            }
        }
    }
}

void NavGraph::connectPit(unsigned int posx, unsigned int posy)
{

    Node *nodeCurent=getNodeByposition(Position(posx,posy));
    int beginX=nodeCurent->pos.x-1;
    int finishX=nodeCurent->pos.x+1;

    int beginY=nodeCurent->pos.y-1;
    int finishY=nodeCurent->pos.y+1;

    for( int y=beginY;y<=finishY;y++)
    {
        for( int x=beginX;x<=finishX;x++)
        {

            switch(tileGrid.at(y).at(x)->getTexture()){
            case texturewall:
            case textureportal:
            case texturedoorClose:
                break;
            case texturedoorOpen:
            case texturefloor:
            case textureLevelChanger:
            case textureswitchS:
                break;
            case textureramp:
            case texturepit:
                nodeCurent->addNeighbour(getNodeByposition(Position(x,y)));
                break;
            }
        }
}
}

std::vector<Position> NavGraph::convertPositionToDirectionVec(std::vector<Position> &toConvert)
{
    std::vector<Position> convert=std::vector<Position>();
    for(unsigned int i=1;i<toConvert.size();i++)
    {
        //tafavot beineshun
        Position diff=toConvert.at(i-1)-toConvert.at(i);
        if(diff.isMovePos()&&diff!=POSSTAY)//masl tu portal dighe un hame rah nemiram
            //stay yani nemizarim ke sabet bemune
        {
            convert.push_back(diff);

        }
    }
    return convert;
}



NavGraph::Node::Node()
{

}

void NavGraph::Node::reset()
{
    visited=false;
    path=std::vector<Position>();
}

void NavGraph::Node::addNeighbour(Node *toAdd)
{
    //fur distans ist 1 die kosten
    if(toAdd!=this)
    {
    neighbours.push_back({toAdd,1});
    }
}
