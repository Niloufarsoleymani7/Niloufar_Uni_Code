#include "character.h"
#include <conio.h>
#include <iostream>
#include "tile.h"
#include "level.h"//class neveshtam vali age nanivisam kar nemikone level ya tilederichdaraufstehe

Character::Character(int p_strength, int p_stamina)
{
    _texture=textureplayer;
    _strength=p_strength;
    _stamina=p_stamina;
    _hitpoints=getMaxHitpoints();
}

Character::Character(int maxStamina, int curStamina, int strenght, int curHealth, char id)
{
     _texture=id;
    _hitpoints=curHealth;
    _strength=strenght;
    _stamina=curStamina;
    _maxStamina=maxStamina;
    if(curHealth<=0)
    {
        _istDead=true;
    }

}

Character::~Character()
{
    //tileDerIchDarufStehe->setCharactarOnTile(nullptr);
    //level->removeCharacter(this);
}

const char &Character::getTexture() const
{
    return _texture;
}

void Character::setTileDerIchDarufStehe(Tile *newTileDerIchDarufStehe)
{
    _tileDerIchDarufStehe = newTileDerIchDarufStehe;
}

void Character::move()
{
    _controllerinCharacter->move();
}

Tile *Character::getTileDerIchDarufStehe() const
{
    return _tileDerIchDarufStehe;
}

Level *Character::getLevel() const
{
    return level;
}

void Character::setLevel(Level *newLevel)
{
    level = newLevel;
}

void Character::setControllerinChARACTER(Controller *newControllerinChARACTER)
{
    _controllerinCharacter = newControllerinChARACTER;
}


int Character::getHitpoints() {
    return _hitpoints;
}

int Character::getMaxHitpoints() const
{
    return 20+(_stamina*5);
}

int Character::getStrength() {
    return _strength;
}

CollerdBar *Character::getHealthbar() const
{
    return healthbar;
}

void Character::setHealthbar(CollerdBar *newHealthbar)
{
    healthbar = newHealthbar;
}

void Character::setStrength(int newStrength)
{
    _strength = newStrength;
}

int Character::getStamina() const
{
    return _stamina;
}

void Character::setHitpoints(int newHitpoints)
{
    _hitpoints = newHitpoints;
}

int Character::getMaxStamina() const
{
    return _maxStamina;
}

void Character::setMaxStamina(int newMaxStamina)
{
    _maxStamina = newMaxStamina;
}

bool Character::getIstDead() const
{
    return _istDead;
}

void Character::setIstDead(bool newIstDead)
{
    _istDead = newIstDead;
}

bool Character::useStamina(int staminaToUse)
{
    if (staminaToUse<_stamina)//wenn klein ist
    {
        _stamina-=staminaToUse;
        //staminaBar->updateBar(stamina,maxStamina);
        return true;
    }
    else
    {
        _stamina=0;
        //staminaBar->updateBar(stamina,maxStamina);
        return false;}

}

void Character::takeDAmage(int damage)
{

    _hitpoints-=damage;

    if(healthbar!=nullptr)//wenn nicht null
    {
        healthbar->updateBar(_hitpoints,getMaxHitpoints());

    }
    if(_hitpoints<=0)
    {
        _istDead=true;
        level->onCharacterDeath(this);

    }
    else{
        _istDead=false;
    }

}

void Character::settexture(char newTexture)
{

    _texture=newTexture;
}

void Character::setStamina(int newStamina)
{
    _stamina = newStamina;
}


