#include "healthbar.h"

CollerdBar::CollerdBar(QWidget *parent ,QPixmap &farbe):QWidget(parent)
{

    hintegrundLabel=new QLabel(this);
    graueBalken=new QLabel(this);
    coloredBar=new QLabel(this);
    zahl=new QLabel(this);

    std::unique_ptr<QPixmap>pixmap;
    pixmap = std::make_unique<QPixmap>(graueBalkenLocation);
    graueBalken->setPixmap(*pixmap);
    graueBalken->setScaledContents(true);

    std::unique_ptr<QPixmap>pixmap1;
    pixmap1 = std::make_unique<QPixmap>(roteBalkenLocation);

    coloredBar->setPixmap(farbe);
    coloredBar->setScaledContents(true);

}

void CollerdBar::updateBar(float curent, float max)
{
    float width=graueBalken->size().width();
    float height= graueBalken->size().height();
    QPoint point=graueBalken->pos();//ganze posizion
    if (curent<0)
    {
        curent=0;

    }
    coloredBar->setGeometry(point.x(),point.y(),width*curent/max,height);

}



void CollerdBar::initialisieren()
{

    //D DANN A  ZUERST BREITE DANN HOHE
    int x=this->size().width()*((float)10/(float)100);
    int y=this->size().height()*((float)30/(float)100);
    int width=this->size().width()*((float)60/(float)100);
    int height=this->size().height()*((float)40/(float)100);

    graueBalken->setGeometry(x,y,width,height);
    coloredBar->setGeometry(x,y,width,height);

    x=this->size().width()*((float)75/(float)100);
    y=this->size().height()*((float)30/(float)100);
    width=this->size().width()*((float)10/(float)100);
    height=this->size().height()*((float)40/(float)100);
    zahl->setGeometry(x,y,width,height);

}
