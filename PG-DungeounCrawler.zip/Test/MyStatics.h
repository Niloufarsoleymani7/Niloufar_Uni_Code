#ifndef MYSTATICS_H
#define MYSTATICS_H
#include<string>
#include<QString>
static const char texturewall='#';
static const char texturefloor='.';
static const char textureplayer='S';
static const char textureportal='O';
static const char textureswitchS='?';
static const char texturedoorOpen ='/';
static const char texturedoorClose ='X';
static const char textureempty =' ';
static const char texturepit ='P';
static const char textureramp ='R';
static const char texturerZombie ='Z';
static const char textureLevelChanger ='L';
static const char texturerChest='C';

static  const QString locationResourceFolder=R"(C:\HDA\Programmiern 2\Test\texture\)";
static  const QString locationMainFolder=R"(C:\HDA\Programmiern 2\Test\)";


static const QString walltexturelocation=locationResourceFolder+R"(wall\wall1.png)";
static const QString floortexturelocation=locationResourceFolder+R"(floor\floor2.png)";
static const QString portaltexturelocation=locationResourceFolder+R"(portal\portal3.png)";
static const QString switchtexturelocation=locationResourceFolder+R"(switch.png)";
static const QString Opentexturelocation=locationResourceFolder+R"(doors\door2.png)";
static const QString closetexturelocation=locationResourceFolder+R"(doors\door1.png)";
static const QString pittexturelocation=locationResourceFolder+R"(pit.png)";
static const QString ramptexturelocation=locationResourceFolder+R"(ramp.png)";

static const QString buttonDownRightTextureLocation=locationResourceFolder+R"(arrows\arrow_down_right.png)";
static const QString buttonDownTextureLocation=locationResourceFolder+R"(arrows\arrow_down.png)";
static const QString buttonDownLeftTextureLocation=locationResourceFolder+R"(arrows\arrow_down_left.png)";
static const QString buttonRightTextureLocation=locationResourceFolder+R"(arrows\arrow_right.png)";
static const QString buttonSkipTextureLocation=locationResourceFolder+R"(arrows\arrow_skip.png)";
static const QString buttonLeftTextureLocation=locationResourceFolder+R"(arrows\arrow_left.png)";
static const QString buttonUpRightTextureLocation=locationResourceFolder+R"(arrows\arrow_up_right.png)";
static const QString buttonUpTextureLocation=locationResourceFolder+R"(arrows\arrow_up.png)";
static const QString buttonUpLeftTextureLocation=locationResourceFolder+R"(arrows\arrow_up_left.png)";

static const QString startScreenPhotoLocation =locationResourceFolder+R"(startscreen.png)";
static const QString buttonNewGameLocation=locationResourceFolder+R"(new_game_button.png)";
static const QString bloodyFrameLocation=locationResourceFolder+R"(bloody_frame.png)";
static const QString victoryLocation=locationResourceFolder+R"(victory.png)";
static const QString gameoverLocation=locationResourceFolder+R"(gameover.png)";


static const QString zombieLeftLocation=locationResourceFolder+R"(zombie\zombie_left.png)";
static const QString zombiRightLocation=locationResourceFolder+R"(zombie\zombie_right.png)";

static const QString player=locationResourceFolder+R"(char\front\char_front_2.png)";
static const QString chestLocation=locationResourceFolder+R"(chest.png)";
static const QString levelchangerLocation=locationResourceFolder+R"(levelchanger.png)";
static const QString roteBalkenLocation=locationResourceFolder+R"(roteBalken.png)";
static const QString graueBalkenLocation=locationResourceFolder+R"(graueBalken.png)";
static const QString staminaLocation=locationResourceFolder+R"(stamina.png)";


enum movedirection
{
    up,down,left,right

};
static const QString playerImages [4][3]{
    {   locationResourceFolder+R"(char\back\char_back_1.png)",
                locationResourceFolder+R"(char\back\char_back_2.png)",
                locationResourceFolder+R"(char\back\char_back_3.png)"},
    {
        locationResourceFolder+R"(char\front\char_front_1.png)",
                locationResourceFolder+R"(char\front\char_front_2.png)",
                locationResourceFolder+R"(char\front\char_front_3.png)"},
    {
        locationResourceFolder+R"(char\left\char_left_1.png)",
                locationResourceFolder+R"(char\left\char_left_2.png)",
                locationResourceFolder+R"(char\left\char_left_3.png)"}
    ,
    {
        locationResourceFolder+R"(char\right\char_right_1.png)",
                locationResourceFolder+R"(char\right\char_right_2.png)",
                locationResourceFolder+R"(char\right\char_right_3.png)"}
};

static const int buttonSize=50;
const QString fileLocation=locationMainFolder+R"(level.txt)";
const QString fileLocation1=locationMainFolder+R"(level1.txt)";
const QString fileLocation2=locationMainFolder+R"(level2.txt)";
const QString fileLocation3=locationMainFolder+R"(level3.txt)";
const QString fileLocation4=locationMainFolder+R"(level4.txt)";
const QString fileLocation5=locationMainFolder+R"(level5.txt)";




#endif // MYSTATICS_H
