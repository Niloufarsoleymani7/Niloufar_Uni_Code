#ifndef GUARDCONTROLLER_H
#define GUARDCONTROLLER_H
#include<controller.h>
#include<tile.h>
#include<level.h>
#include<MyStatics.h>

class GuardController :public Controller
{
public:

    GuardController(Character *who,Level* nLevel);
    ~GuardController();
    int move() override;
    bool TryMove(Position &inputPos)override;
    bool TryMove()override;
    Position getPosition()override;

private:
    int cycle=0;
    static const int arraySize=8;
    int moveLeft(Character *who);
    int moveRight(Character *who);
    movedirection pattern[arraySize]={movedirection::left,movedirection::left,
                                      movedirection::right,movedirection::right,movedirection::right,movedirection::right,
                                      movedirection::left,movedirection::left};



};

#endif // GUARDCONTROLLER_H
