#ifndef PASSIVE_H
#define PASSIVE_H
#include "active.h"


class Passive
{
public:
    Passive();
    ~Passive();
    //Diese soll aufgerufen werden,
    //wenn für dieses Passive-Objekt eine Aktion ausgelöst werden soll
    //Dies kann in von Passive Objekten verwendet werden um zu ermitteln, durch
    //welches Objekt die Aktion ausgelöst wurde.

    virtual void notify(Active* source)=0;

};

#endif // PASSIVE_H
