#include "playarea.h"
#include "ui_playarea.h"
#include "mainwindow.h"

PlayArea::PlayArea(QWidget *parent,Level *nlevel,MainWindow *mv) :
    QWidget(parent),
    ui(new Ui::PlayArea)
{
    ui->setupUi(this);
    _level=nlevel;
    _mw=mv;
    initializeLabelGrid();
    initializeEnemyLabels();
    playerLAbel=new QLabel(this);
    playerLAbel->setScaledContents(true);
    this->show();
}

PlayArea::~PlayArea()
{
    delete ui;
}

void PlayArea::updateLabels()
{
    const std::vector<std::vector<Tile*>> grid=_level->getGrid();
    Tile *currTile=nullptr;
    for(unsigned int y=0;y<grid.size();y++){
        for (unsigned x=0;x<grid.at(y).size();x++){
            currTile=grid.at(y).at(x);
            updateTilePixmap(getLabelByPos(x,y),currTile->getTexture());
        }
    }
    updatePlayerLabel();
    updateEnemyLabels();
    animationCycle++;
}

QLabel *PlayArea::getPlayerLabel() const
{
    return playerLAbel;
}

void PlayArea::updateTilePixmap(QLabel *label, char filename)
{
    std::unique_ptr<QPixmap>pixmap;
    switch(filename)
    {
    case texturewall:
        pixmap = std::make_unique<QPixmap>(walltexturelocation);
        break;
    case texturefloor:
        pixmap=std::make_unique<QPixmap>(floortexturelocation);
        break;
    case textureportal:
        pixmap=std::make_unique<QPixmap>(portaltexturelocation);
        break;
    case textureswitchS:
        pixmap=std::make_unique<QPixmap>(switchtexturelocation);
        break;
    case texturepit:
        pixmap=std::make_unique<QPixmap>(pittexturelocation);
        break;
    case textureramp:
        pixmap=std::make_unique<QPixmap>(ramptexturelocation);
        break;
    case texturedoorOpen :
        pixmap=std::make_unique<QPixmap>(Opentexturelocation);
        break;
    case texturedoorClose :
        pixmap=std::make_unique<QPixmap>(closetexturelocation);
        break;
    case texturerChest :
        pixmap=std::make_unique<QPixmap>(chestLocation);
        break;
    case textureLevelChanger :
        pixmap=std::make_unique<QPixmap>(levelchangerLocation);
        break;
    default:
        pixmap=nullptr;
        std::cout<<"Error"<<std::endl;
        break;
    }
    label->setScaledContents(true);
    label->setPixmap(*pixmap);

}

QLabel *PlayArea::getLabelByPos(int x, int y)
{
    return labelGrid.at(y).at(x);
}

void PlayArea::updatePlayerLabel()
{
    std::unique_ptr<QPixmap>pixmap;
    Character *p=_level->getPlayerInLevel();
    int x=p->getTileDerIchDarufStehe()->getposX();
    int y=p->getTileDerIchDarufStehe()->getposY();
    playerLAbel->setGeometry(x*buttonSize,y*buttonSize,buttonSize,buttonSize);

    pixmap=std::make_unique<QPixmap>(playerImages[_mw->getLasDirectionMoved()][animationCycle%3]);
    playerLAbel->setPixmap(*pixmap);

}

void PlayArea::updateEnemyLabels()
{
    std::vector<Character*> characters=_level->getCharacters();

    for(unsigned int i=0;i<_enemieLabels.size();i++){
        QLabel *label=_enemieLabels.at(i)._label;
        if(_enemieLabels.at(i)._character->getHitpoints()<=0)
        {
            _enemieLabels.at(i)._label->hide();
        }
        else{
            _enemieLabels.at(i)._label->show();

        }
        int x=characters.at(i)->getTileDerIchDarufStehe()->getposX();
        int y=characters.at(i)->getTileDerIchDarufStehe()->getposY();
        std::unique_ptr<QPixmap>pixmap;
        pixmap=std::make_unique<QPixmap>(zombiRightLocation);
        label->setPixmap(*pixmap);
        label->setGeometry(x*buttonSize,y*buttonSize,buttonSize,buttonSize);
    }
}

void PlayArea::initializeLabelGrid()
{    std::vector<std::vector<Tile*>> toDraw= _level->getGrid();

     for(size_t y=0;y<toDraw.size();y++)//y
     {
         labelGrid.push_back(std::vector<QLabel*>());//fullen
         for(size_t x=0;x<toDraw.at(y).size();x++)//x acalin y size
         {
             labelGrid.at(y).push_back(new QLabel(this));//yeki yeki vared mionim az khode mainwindow
             labelGrid.at(y).back()->setGeometry(buttonSize*x,buttonSize*y,buttonSize,buttonSize);
             labelGrid.at(y).back()->show();//ads ruft show von alle kinder

         }
     }

}

void PlayArea::initializeEnemyLabels()
{
    _enemieLabels=std::vector<Enemy>();

    std::vector<Character*> characters=_level->getCharacters();
    for(unsigned int i=0;i<characters.size();i++)
    {
        _enemieLabels.push_back({characters.at(i),new QLabel (this)});
        QLabel *label=_enemieLabels.back()._label;
        label->setScaledContents(true);
        std::unique_ptr<QPixmap>pixmap;
        pixmap=std::make_unique<QPixmap>(roteBalkenLocation);

        CollerdBar *coloredBar=new CollerdBar(label,*pixmap);
        coloredBar->setGeometry(0,0,buttonSize,buttonSize/3);
        coloredBar->initialisieren();
        characters.at(i)->healthbar=coloredBar;

    }

}
