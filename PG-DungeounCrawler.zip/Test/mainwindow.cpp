#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <PlayArea.h>
#include<levelexit.h>

MainWindow::MainWindow(QWidget *parent,DungeonCrawler *newDungeonCrawler)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),pointerDungeonCrawler(newDungeonCrawler)
{
    ui->setupUi(this);
    QPalette pal = this->palette();
    pal.setColor(QPalette::Window, Qt::darkGray);
    this->setAutoFillBackground(true);
    this->setPalette(pal);
    curentLevel= pointerDungeonCrawler->getLevelListe().Begin();
    configControls();
    _savebutton =new QPushButton(this);
    _savebutton->setGeometry(width()-buttonSize*2,height()/2,buttonSize*2,buttonSize);
    _savebutton->setText("save game");
    startNewGame();
    connect(_savebutton,&QPushButton::pressed,this,&MainWindow::saveGame);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete pointerDungeonCrawler;
}

void MainWindow::moveDownRight()
{
    lasDirectionMoved=movedirection::right;
    movePlayer(1,1);
}

void MainWindow::moveDown()
{
    lasDirectionMoved=movedirection::down;
    movePlayer(0,1);
}

void MainWindow::moveDownLeft()
{
    lasDirectionMoved=movedirection::left;
    movePlayer(-1,1);

}

void MainWindow::moveRight()
{
    lasDirectionMoved=movedirection::right;
    movePlayer(1,0);
}

void MainWindow::moveStay()
{
    lasDirectionMoved=movedirection::down;
    movePlayer(0,0);
}

void MainWindow::moveLeft()
{
    lasDirectionMoved=movedirection::left;
    movePlayer(-1,0);
}

void MainWindow::moveupRight()
{
    lasDirectionMoved=movedirection::right;
    movePlayer(1,-1);

}

void MainWindow::moveup()
{
    lasDirectionMoved=movedirection::up;
    movePlayer(0,-1);


}

void MainWindow::moveUpLeft()
{
    lasDirectionMoved=movedirection::left;
    movePlayer(-1,-1);

}

movedirection MainWindow::getLasDirectionMoved() const
{
    return lasDirectionMoved;
}

void MainWindow::saveGame()
{
    LevelList &list =pointerDungeonCrawler->getLevelListe();
    LevelList::LevelIterator itt=list.Begin();
    while(itt!=list.End())
    {
        itt->saveGame();
        ++itt;
    }
    gameDeFeat();
}

void MainWindow::drawLevel()
{
    _playarea->updateLabels();

    //    for(size_t i=0;i<_enemies.size();i++)
    //    {
    //        if(_enemies.at(i).character->getHitpoints()<=0)
    //        {
    //            delete _enemies.at(i).character;
    //            delete _enemies.at(i).controller;
    //            delete _enemies.at(i).qLabel;
    //            _enemies.at(i).deletFlag=true;
    //        }
    //    }
    //    std::vector<EnemyCollection>::iterator a =enemies.begin();
    //    while(a!=enemies.end())
    //    {
    //        if(a->deletFlag)
    //        {
    //            a=enemies.erase(a);
    //        }else
    //        {
    //            a++;
    //        }
    //    }

    //    std::vector<std::vector<Tile*>> toDraw=  curentLevel->getGrid();
    //    std::unique_ptr<QPixmap>pixmap;
    //    animationCycle++;
    //    for(size_t y=0;y<toDraw.size();y++)//y
    //    {
    //        for(size_t x=0;x<toDraw.at(y).size();x++)//x
    //        {
    //            if(toDraw.at(y).at(x)->hasCharacter())
    //            {
    //                Character *character=toDraw.at(y).at(x)->getCharactarOnTile();
    //                switch(character->getTexture())
    //                {
    //                case textureplayer:
    //                    pixmap=std::make_unique<QPixmap>(playerImages[lasDirectionMoved][animationCycle%3]);
    //                    playerImageLabel->setPixmap(*pixmap);
    //                    movePlayerImage(x,y);
    //                    qLabelQrid.at(y).at(x)->setPixmap(*pixmap);
    //                    break;
    //                case texturerZombie:
    //                    pixmap=std::make_unique<QPixmap>(zombiRightLocation);
    //                    enemyImageLabel->setPixmap(*pixmap);
    //                    moveEnemyImage(enemyImageLabel,x,y);
    //                    qLabelQrid.at(y).at(x)->setPixmap(*pixmap);
    //                    break;
    //                }
    //            }
    //          else
    //            setLAbelTexture(qLabelQrid.at(y).at(x),toDraw.at(y).at(x));//glabel.back ist wie at(j)
    //        }
    //    }
}

void MainWindow::setLAbelTexture(QLabel *toChange, Tile *toApply)
{
    std::unique_ptr<QPixmap>pixmap;
    switch(toApply->getTexture())
    {
    case texturewall:
        pixmap = std::make_unique<QPixmap>(walltexturelocation);
        break;
    case texturefloor:
        pixmap=std::make_unique<QPixmap>(floortexturelocation);
        break;
    case textureportal:
        pixmap=std::make_unique<QPixmap>(portaltexturelocation);
        break;
    case textureswitchS:
        pixmap=std::make_unique<QPixmap>(switchtexturelocation);
        break;
    case texturepit:
        pixmap=std::make_unique<QPixmap>(pittexturelocation);
        break;
    case textureramp:
        pixmap=std::make_unique<QPixmap>(ramptexturelocation);
        break;
    case texturedoorOpen :
        pixmap=std::make_unique<QPixmap>(Opentexturelocation);
        break;
    case texturedoorClose :
        pixmap=std::make_unique<QPixmap>(closetexturelocation);
        break;
    case texturerChest :
        pixmap=std::make_unique<QPixmap>(chestLocation);
        break;
    case textureLevelChanger :
        pixmap=std::make_unique<QPixmap>(levelchangerLocation);
        break;
    default:
        pixmap=nullptr;
        std::cout<<"Error"<<std::endl;
        break;
    }
    toChange->setScaledContents(true);
    toChange->setPixmap(*pixmap);

}

void MainWindow::createLabelGrid()
{
    std::vector<std::vector<Tile*>> toDraw=  curentLevel->getGrid();
    labelSize=(this->size().width()-3*buttonSize)/toDraw.at(0).size();

    for(size_t y=0;y<toDraw.size();y++)//y
    {
        qLabelQrid.push_back(std::vector<QLabel*>());//fullen
        for(size_t x=0;x<toDraw.at(y).size();x++)//x acalin y size
        {
            qLabelQrid.at(y).push_back(new QLabel(this));//yeki yeki vared mionim az khode mainwindow
            qLabelQrid.at(y).back()->setGeometry(labelSize*x,labelSize*y,labelSize,labelSize);
            qLabelQrid.at(y).back()->show();//ads ruft show von alle kinder

        }
    }
}

void MainWindow::configControls()
{
    ui->buttonDownRight->setGeometry(this->size().width()-buttonSize,this->size().height()-buttonSize,buttonSize,buttonSize);
    ui->buttonDown->setGeometry(this->size().width()-buttonSize*2,this->size().height()-buttonSize,buttonSize,buttonSize);
    ui->buttonDownLeft->setGeometry(this->size().width()-buttonSize*3,this->size().height()-buttonSize,buttonSize,buttonSize);
    ui->buttonRight->setGeometry(this->size().width()-buttonSize,this->size().height()-buttonSize*2,buttonSize,buttonSize);
    ui->buttonStay->setGeometry(this->size().width()-buttonSize*2,this->size().height()-buttonSize*2,buttonSize,buttonSize);
    ui->buttonLeft->setGeometry(this->size().width()-buttonSize*3,this->size().height()-buttonSize*2,buttonSize,buttonSize);
    ui->buttonUpRight->setGeometry(this->size().width()-buttonSize,this->size().height()-buttonSize*3,buttonSize,buttonSize);
    ui->buttonUp->setGeometry(this->size().width()-buttonSize*2,this->size().height()-buttonSize*3,buttonSize,buttonSize);
    ui->buttonUpLeft->setGeometry(this->size().width()-buttonSize*3,this->size().height()-buttonSize*3,buttonSize,buttonSize);

    connect(ui->buttonDownRight,&QPushButton::pressed,this,&MainWindow::moveDownRight);//ohne kallamer
    connect(ui->buttonDown,&QPushButton::pressed,this,&MainWindow::moveDown);
    connect(ui->buttonDownLeft,&QPushButton::pressed,this,&MainWindow::moveDownLeft);
    connect(ui->buttonRight,&QPushButton::pressed,this,&MainWindow::moveRight);
    connect(ui->buttonStay,&QPushButton::pressed,this,&MainWindow::moveStay);
    connect(ui->buttonLeft,&QPushButton::pressed,this,&MainWindow::moveLeft);
    connect(ui->buttonUpRight,&QPushButton::pressed,this,&MainWindow::moveupRight);
    connect(ui->buttonUp,&QPushButton::pressed,this,&MainWindow::moveup);
    connect(ui->buttonUpLeft,&QPushButton::pressed,this,&MainWindow::moveUpLeft);
    setPushButtonImage();

}

void MainWindow::setPushButtonImage()
{
    std::unique_ptr<QPixmap>pixmap;
    pixmap = std::make_unique<QPixmap>(buttonLeftTextureLocation);
    QIcon buttonLeft(*pixmap);
    ui->buttonLeft->setIcon(buttonLeft);
    ui->buttonLeft->setIconSize(ui->buttonLeft->size());


    std::unique_ptr<QPixmap>pixmap1;
    pixmap1 = std::make_unique<QPixmap>(buttonUpTextureLocation);
    QIcon *buttonupIcon=new QIcon(*pixmap1);
    ui->buttonUp->setIcon(*buttonupIcon);
    ui->buttonUp->setIconSize(ui->buttonUp->size());

    std::unique_ptr<QPixmap>buttonDownRightPix;
    buttonDownRightPix = std::make_unique<QPixmap>(buttonDownRightTextureLocation);
    QIcon *buttonDownRightIcon=new QIcon(*buttonDownRightPix);
    ui->buttonDownRight->setIcon(*buttonDownRightIcon);
    ui->buttonDownRight->setIconSize(ui->buttonDownRight->size());


    std::unique_ptr<QPixmap>buttonDownPix;
    buttonDownPix = std::make_unique<QPixmap>(buttonDownTextureLocation);
    QIcon *buttonDownIcon=new QIcon(*buttonDownPix);
    ui->buttonDown->setIcon(*buttonDownIcon);
    ui->buttonDown->setIconSize(ui->buttonDown->size());


    std::unique_ptr<QPixmap>buttonDownLeftPix;
    buttonDownLeftPix = std::make_unique<QPixmap>(buttonDownLeftTextureLocation);
    QIcon *buttonDownLeftIcon=new QIcon(*buttonDownLeftPix);
    ui->buttonDownLeft->setIcon(*buttonDownLeftIcon);
    ui->buttonDownLeft->setIconSize(ui->buttonDown->size());


    std::unique_ptr<QPixmap>buttonRightPix;
    buttonRightPix = std::make_unique<QPixmap>(buttonRightTextureLocation);
    QIcon *buttonRightIcon=new QIcon(*buttonRightPix);
    ui->buttonRight->setIcon(*buttonRightIcon);
    ui->buttonRight->setIconSize(ui->buttonRight->size());


    std::unique_ptr<QPixmap>buttonSkipPix;
    buttonSkipPix = std::make_unique<QPixmap>(buttonSkipTextureLocation);
    QIcon *buttonSkipIcon=new QIcon(*buttonSkipPix);
    ui->buttonStay->setIcon(*buttonSkipIcon);
    ui->buttonStay->setIconSize(ui->buttonStay->size());


    std::unique_ptr<QPixmap>buttonUpRightPix;
    buttonUpRightPix = std::make_unique<QPixmap>(buttonUpRightTextureLocation);
    QIcon *buttonUpRightIcon=new QIcon(*buttonUpRightPix);
    ui->buttonUpRight->setIcon(*buttonUpRightIcon);
    ui->buttonUpRight->setIconSize(ui->buttonUpRight->size());


    std::unique_ptr<QPixmap>buttonUpLeftPIx;
    buttonUpLeftPIx = std::make_unique<QPixmap>(buttonUpLeftTextureLocation);
    QIcon *buttonUpLeftIcon=new QIcon(*buttonUpLeftPIx);
    ui->buttonUpLeft->setIcon(*buttonUpLeftIcon);
    ui->buttonUpLeft->setIconSize(ui->buttonUpLeft->size());
}

void MainWindow::movePlayerImage(int x, int y)
{
    playerImageLabel->setGeometry(labelSize*x,labelSize*y,labelSize,labelSize);
}

void MainWindow::moveEnemyImage(QLabel *qlabel, int x, int y)
{
    qlabel->setGeometry(labelSize*x,labelSize*y,labelSize,labelSize);


}

void MainWindow::movePlayer(int x,int y)
{
    Character *player=curentLevel->getPlayerInLevel();
    x+=player->getTileDerIchDarufStehe()->getposX();
    y+=player->getTileDerIchDarufStehe()->getposY();
    player->getTileDerIchDarufStehe()->moveTo(curentLevel->getTile(x,y),player);

    if(player->getIstDead())
    {
        curentLevel->onPlayerDeath();

    }
    if (curentLevel->getlevelstate()!=Level::LevelState::Stay)
    {
        levelFinished();
    }
    else
    {
        moveAllEnemies();
        drawLevel();
    }


}

void MainWindow::moveAllEnemies()
{

    const std::vector<Controller*> &controllers=curentLevel->getControllers();
    for(size_t i=0;i<controllers.size();i++)
    {
        if(!controllers.at(i)->getControlling()->getIstDead())
        {
            controllers.at(i)->TryMove();
        }
    }

}

void MainWindow::keyPressEvent(QKeyEvent *event)
{

    switch(event->key()){
    case Qt::Key_Y:
        moveDownLeft();
        break;
    case Qt::Key_X:
        moveDown();
        break;
    case Qt::Key_C:
        moveDownRight();
        break;
    case Qt::Key_A:
        moveLeft();
        break;
    case Qt::Key_S:
        moveStay();
        break;
    case Qt::Key_D:
        moveRight();
        break;
    case Qt::Key_Q:
        moveUpLeft();
        break;
    case Qt::Key_W:
        moveup();
        break;
    case Qt::Key_E:
        moveupRight();
        break;
    }
}



void MainWindow::levelFinished()
{
    switch(curentLevel->getlevelstate()){
    case Level::LevelState::Goback:
        loadPrevLevel();
        break;
    case Level::LevelState::GoForth:
        loadNextLevel();
        break;
    case Level::LevelState::Defeat:
        gameDeFeat();
        break;
    case Level::LevelState::Victory:
        gameVictory();
        break;
    default:
        break;

    }

}

void MainWindow::loadNextLevel()
{
    LevelList::LevelIterator nextLevel=curentLevel;
    ++nextLevel;

    if(nextLevel == pointerDungeonCrawler->getLevelListe().End())
    {
        gameVictory();
    }
    else
    {
        deleteOldGame();
        teleportCharacterToNextLevel();
        ++curentLevel;
        startNewGame();
    }
}

void MainWindow::loadPrevLevel()
{
    deleteOldGame();
    teleportCharacterToPrevLevel();
    --curentLevel;
    startNewGame();

}

void MainWindow::deleteLevel()
{



}

void MainWindow::gameVictory()
{
    VictoryDialog *vd=new VictoryDialog(this,this);
    vd->show();
}

void MainWindow::gameDeFeat()
{
    GameOverDialog *gm=new GameOverDialog(this,this);
    gm->show();

}

void MainWindow::deleteOldGame()
{
    delete _playarea;

}

void MainWindow::startNewGame()
{
    //qwidget main window ,der klasse mainwindow
    _playarea= new PlayArea(this,*curentLevel,this);
    int x=curentLevel->getBreite()*buttonSize;
    int y=curentLevel->getHoehe()*buttonSize;
    this->setGeometry(20,20,x+3*buttonSize,y+3*buttonSize);
    _playarea->setGeometry(0,0,x,y);
    QPixmap playerHealthBarpixmap=QPixmap(roteBalkenLocation);
    playerHealthBar=new CollerdBar(_playarea->getPlayerLabel(),playerHealthBarpixmap);
    playerHealthBar->show();
    curentLevel->getPlayerInLevel()->setHealthbar(playerHealthBar);
    playerHealthBar->setGeometry(0,0,buttonSize,buttonSize/3);
    playerHealthBar->initialisieren();
    drawLevel();
}

void MainWindow::createLabels()
{
    createLabelGrid();
    playerImageLabel=new QLabel(this);
    QPixmap playerStaminapixmap=QPixmap(staminaLocation);
    playerStamina=new CollerdBar(this,playerStaminapixmap);
    playerStamina->setGeometry(this->size().width()-3*buttonSize,buttonSize*2,3*buttonSize,buttonSize);
    playerStamina->initialisieren();
    curentLevel->getPlayerInLevel()->staminaBar=playerStamina;

    QPixmap playerHealthBarpixmap=QPixmap(roteBalkenLocation);
    playerHealthBar=new CollerdBar(playerImageLabel,playerHealthBarpixmap);
    //x ,Y , width , height
    playerHealthBar->setGeometry(0,0,buttonSize,(float)buttonSize/(float)3);
    playerHealthBar->initialisieren();
    curentLevel->getPlayerInLevel()->healthbar=playerHealthBar;

    Character *enemyCharacterPointer=curentLevel->getCharacters().at(0);
    Controller *controllerPointer=curentLevel->getControllers().at(0);


    enemyImageLabel=new QLabel(this);
    _enemies.push_back(EnemyCollection(enemyCharacterPointer,controllerPointer,enemyImageLabel));


    QPixmap enemyHealthBarPixmap=QPixmap(roteBalkenLocation);
    enemyHealthBar=new CollerdBar(enemyImageLabel,enemyHealthBarPixmap);
    //x ,Y , width , height
    enemyHealthBar->setGeometry(0,0,buttonSize,(float)buttonSize/(float)3);
    enemyHealthBar->initialisieren();
    enemyCharacterPointer->healthbar=enemyHealthBar;


    QPixmap enemyStaminaPixmap=QPixmap(staminaLocation);
    enemyStamina=new CollerdBar(this,enemyStaminaPixmap);
    enemyStamina->setGeometry(this->size().width()-3*buttonSize,buttonSize*5,3*buttonSize,buttonSize);
    enemyStamina->initialisieren();
    curentLevel->getCharacters().at(0)->staminaBar=enemyStamina;

    playerImageLabel->setScaledContents(true);
    enemyImageLabel->setScaledContents(true);

}

void MainWindow::teleportCharacterToNextLevel( )
{  
    Character *player=curentLevel->getPlayerInLevel();
    LevelList::LevelIterator nextLevel=curentLevel;
    ++nextLevel;
    player->getTileDerIchDarufStehe()->moveTo(nextLevel->getEntryStairCase(),player);
    curentLevel->setPlayerInLevel(nullptr);
    nextLevel->setPlayerController(curentLevel->getPlayerController());
    curentLevel->setPlayerController(nullptr);
    nextLevel->setPlayerInLevel(player);
    player->setLevel(*nextLevel);
}

void MainWindow::teleportCharacterToPrevLevel()
{
    Character *player=curentLevel->getPlayerInLevel();
    LevelList::LevelIterator prevLevel=curentLevel;
    --prevLevel;
    player->getTileDerIchDarufStehe()->moveTo(prevLevel->getExitStairCase(),player);
    curentLevel->setPlayerInLevel(nullptr);
    prevLevel->setPlayerController(curentLevel->getPlayerController());
    curentLevel->setPlayerController(nullptr);
    prevLevel->setPlayerInLevel(player);
    player->setLevel(*prevLevel);
}






