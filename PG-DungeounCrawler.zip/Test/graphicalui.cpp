#include "graphicalui.h"

GraphicalUI::GraphicalUI():Controller(nullptr,nullptr)
{

}

void GraphicalUI::draw(Level *aktuellLevel)
{

}

int GraphicalUI::move()
{

}
