#ifndef PLAYAREA_H
#define PLAYAREA_H
#include <QWidget>
#include <level.h>
#include<MyStatics.h>
#include "healthbar.h"

namespace Ui {
class PlayArea;
}

class MainWindow;

class PlayArea : public QWidget
{
    Q_OBJECT

public:
    explicit PlayArea(QWidget *parent = nullptr,Level *nlevel=nullptr,MainWindow *mv=nullptr);
    ~PlayArea();
    void updateLabels();
    QLabel *getPlayerLabel() const;

private:
    Ui::PlayArea *ui;
    struct Enemy
    {
        Character *_character=nullptr;
        QLabel *_label=nullptr;
    };
    std::vector<std::vector<QLabel*>> labelGrid;
    QLabel *playerLAbel=nullptr;
    std::vector<Enemy>_enemieLabels;
    Level *_level;
    void updateTilePixmap(QLabel *label,char filename);
    QLabel *getLabelByPos(int x,int y);

    void updatePlayerLabel();
    void updateEnemyLabels();

    void initializeLabelGrid();
    void initializeEnemyLabels();

    int animationCycle=0;
    MainWindow *_mw=nullptr;

};

#endif // PLAYAREA_H
