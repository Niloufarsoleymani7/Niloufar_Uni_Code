#include "levelfactory.h"

LevelFactory::LevelFactory()
{

}

LevelFactory::~LevelFactory()
{

}
