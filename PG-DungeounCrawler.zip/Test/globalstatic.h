#ifndef GLOBALSTATIC_H
#define GLOBALSTATIC_H


class GlobalStatic
{
public:
    GlobalStatic();
    static const int levelSize=10;
};

#endif // GLOBALSTATIC_H
