#include "door.h"


Door::Door(int x, int y,bool isOpen):Tile(x,y)
{

    if(isOpen)
    {
        texture=texturedoorOpen;
    }
    else
        texture=texturedoorClose;


}

void Door::notify(Active *source)
{
    if(texture==texturedoorOpen)
    {
        texture=texturedoorClose;
    }
    else

        texture=texturedoorOpen;

}

bool Door::getIsopen() const
{
    return isopen;
}

Tile *Door::onEnter(Tile *fromTile, Character *who)
{
    //agar kasi hast na un cha
    if(hasCharacter()&&who!=CharactarOnTile){
        Fight f=Fight(who,CharactarOnTile);
        return nullptr;}
    if (texture==texturedoorClose)//khodesh midune kojast
    {
      return nullptr;
    }
    else
        return this;

}

Tile *Door::onLeave(Tile *destTile, Character *who)
{

    return this;
}
