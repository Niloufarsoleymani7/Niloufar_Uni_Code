#include "freshlevelfactory.h"
#include "levelbuilder.h"
FreshLevelFactory::FreshLevelFactory()
{

}

FreshLevelFactory::~FreshLevelFactory()
{

}

Level *FreshLevelFactory::BuildLevel(QString fileLocation)
{
    return LevelBuilder().BuildFreshLevel(fileLocation);
}
