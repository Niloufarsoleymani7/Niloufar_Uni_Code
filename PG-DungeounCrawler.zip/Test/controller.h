#ifndef CONTROLLER_H
#define CONTROLLER_H
#include<position.h>

class Level;
class Character;

class Controller
{
public:
    Controller(Character * who,Level * nLevel);
    virtual ~Controller()=0;
    virtual int move()=0;
    virtual  bool TryMove(Position &inputPos)=0;
    virtual  bool TryMove()=0;
    virtual  Position getPosition();
    Level *getLevel() const;
    void setLevel(Level *newLevel);

    Character *getControlling() const;

protected:
    Character *_controlling=nullptr;
    Level * _level=nullptr;
    Position _position;

};

#endif // CONTROLLER_H
