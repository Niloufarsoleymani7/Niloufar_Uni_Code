#ifndef PIT_H
#define PIT_H
#include<tile.h>
#include <MyStatics.h>
#include<floor.h>
#include<iostream>
class Pit:public Tile
{
public:
    Pit(int x,int y);
    Tile* onEnter(Tile* fromTile, Character* who)override;
    Tile* onLeave(Tile* destTile, Character* who)override;
};

#endif // PIT_H
