#ifndef PORTAL_H
#define PORTAL_H
#include "tile.h"
#include <MyStatics.h>
#include<iostream>
class Portal :public Tile
{
public:
    Portal(int x,int y);

    Tile* onEnter(Tile* fromTile, Character* who)override;
    Tile* onLeave(Tile* destTile,Character * who)override;
    Tile *getDestination() const;
    void setDestination(Tile *newDestination);

    ~Portal()override;

private:

    Tile* destination=nullptr;

};

#endif // PORTAL_H
