﻿#ifndef NAVGRAPH_H
#define NAVGRAPH_H
#include<vector>
#include<position.h>
#include<passive.h>
class Tile;
class Level;
class NavGraph: public Passive//wenn tile grid  andert muss nodegrid  auch sich ändern
{
private :
    struct Node
    {
        Node();
        struct Neighbour
        {
            Node *node;
            float distance=1;
        };

        bool visited=false;
        Position pos;
        std::vector<Neighbour>neighbours=std::vector<Neighbour>();
        std::vector<Position>path;
        void reset();
        void addNeighbour(Node *toAdd);

    };
    struct Entry
    {
        Node *caller;//az tarafe ki umadan tu
        Node *node;
    };

public:
    NavGraph(Level *level);
    ~NavGraph();
    std::vector<Position>calculatePath(Position start,Position finish);
    void BakeGrid();
    void notify(Active* source)override;


private:

    Node *getNodeByposition(Position pos);
    std::vector<Position>  convertPositionToDirectionVec(std::vector<Position> &toConvert);

    std::vector<std::vector<Node*>>nodeGrid=std::vector<std::vector<Node*>>();
    const std::vector<std::vector<Tile*>> &tileGrid;

    void resetNodes();

    void deletegrid();
    void createGrid();
    void analyseneighbours();

    void connectDeafult(unsigned int posx,unsigned int posy);
    void connectPit(unsigned int posx,unsigned int posy);

};

#endif // NAVGRAPH_H
