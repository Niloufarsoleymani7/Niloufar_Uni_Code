#ifndef DOOR_H
#define DOOR_H
#include<tile.h>
#include<passive.h>
#include <MyStatics.h>

//geschlossen wand offen floor
//az wall floor unmoghe bayad virtual bashe

class Door:public Tile,public Passive
{
public:
    Door(int x,int y,bool isOpen);

    Tile* onEnter(Tile* fromTile, Character* who) override;
    Tile* onLeave(Tile* destTile, Character* who) override;

    void notify(Active* source) override;
    bool isopen;

    bool getIsopen() const;
};

#endif // DOOR_H
