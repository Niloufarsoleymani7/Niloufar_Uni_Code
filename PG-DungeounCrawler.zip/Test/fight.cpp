#include "fight.h"

Fight::Fight(Character * angreifer_par,Character *verteidiger_par)
{

    angreifer=angreifer_par;
    verteidiger=verteidiger_par;
    fight();

}

void Fight::fight()
{
    verteidiger->takeDAmage(angreifer->getStrength());
}
