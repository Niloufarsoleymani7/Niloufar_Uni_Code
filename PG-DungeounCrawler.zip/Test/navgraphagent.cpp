#include "navgraphagent.h"
#include "navgraph.h"
#include "level.h"

NavGraphAgent::NavGraphAgent(Level * getNavGraphFrom)
{
    _navGraph=getNavGraphFrom->getNavGraph();
}

NavGraphAgent::NavGraphAgent(NavGraph *navGraph)
{
    _navGraph=navGraph;
}

NavGraph *NavGraphAgent::GetNavGraph() const
{
    return _navGraph;
}

void NavGraphAgent::SetNavGraph(NavGraph *newNavGraph)
{
    _navGraph = newNavGraph;
}

Position NavGraphAgent::GetNextStep(Position from,Position to)
{
    std::vector<Position> path=_navGraph->calculatePath(from,to);
    if(path.size()>0)
    {
        return path.front();
    }else{
        return POSSTAY;
    }

}
