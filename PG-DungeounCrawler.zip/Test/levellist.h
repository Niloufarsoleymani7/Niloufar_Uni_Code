#ifndef LEVELLIST_H
#define LEVELLIST_H
#include <cstddef>
#include <level.h>

class LevelList
{
public:
    struct LevelElement{
        LevelElement();
        ~LevelElement();
        LevelElement(Level * _level,LevelElement* _prev);
        LevelElement(Level * _level,LevelElement* _prev,LevelElement* _next);
        Level * level=nullptr;
        LevelElement * next=nullptr;
        LevelElement * prev=nullptr;
    };
    class LevelIterator{
    public:
        LevelIterator();
        LevelIterator(LevelElement * _element);

        LevelIterator& operator++();
        LevelIterator& operator--();
        Level*& operator*();
        Level*& operator->();
        bool operator==(const LevelIterator& other);
        bool operator!=(const LevelIterator& other);
        Level *peakNext();

    private:
        LevelElement * element;
    };
public:
    LevelList();
    ~LevelList();
    void PushBack(Level* toAdd);
    void PushFront(Level* toAdd);
    void PopBack();
    void PopFront();
    bool Empty();
    std::size_t Size();
    void Remove(Level * toRemove);
    LevelIterator Begin();
    LevelIterator End();


private:

    void StitchElements(LevelElement* prev,LevelElement * next);

    LevelElement * first=nullptr;
    LevelElement * last=nullptr;

    LevelElement * endElement=new LevelElement();



};

#endif // LEVELLIST_H
