#ifndef ALLTILES_H
#define ALLTILES_H
#include<tile.h>
#include<floor.h>
#include<door.h>
#include<switch.h>
#include<chest.h>
#include<levelexit.h>
#include<wall.h>
#include<portal.h>
#include<ramp.h>
#include<pit.h>



#endif // ALLTILES_H
