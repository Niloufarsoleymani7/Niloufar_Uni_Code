#include "abstractui.h"

AbstractUI::AbstractUI()
{

}
