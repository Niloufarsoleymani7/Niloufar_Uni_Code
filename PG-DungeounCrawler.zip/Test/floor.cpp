#include "floor.h"

Floor::Floor(int x,int y):Tile(x,y)//eltern initial mikonm
{

    texture=texturefloor;
}

Tile *Floor::onEnter(Tile *fromTile, Character *who)
{
    if(hasCharacter()&&who!=CharactarOnTile){
        Fight f=Fight(who,CharactarOnTile);
        return nullptr;}
    return this;
}

Tile *Floor::onLeave(Tile *destTile, Character *who)
{

    return this;
}

Floor::~Floor()
{

}

