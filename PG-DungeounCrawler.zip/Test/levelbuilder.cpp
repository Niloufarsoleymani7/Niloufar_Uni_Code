#include "levelbuilder.h"
#include "level.h"
#include "AllTiles.h"
#include "navgraph.h"
#include "AllControllers.h"
LevelBuilder::LevelBuilder()
{

}

Level *LevelBuilder::BuildFreshLevel(QString fileName)
{
    ResetBuilder();
    Level * level=new Level(fileName.toStdString());
    _currentlyBuilding=level;

    ReadLvlFile(fileName);

    ConnectAllActivsAndPassivs();
    ConnectAllPortals();

    FinalizeLevel();

    return level;
}

Level *LevelBuilder::BuildOldLevel(QString fileName)
{
    ResetBuilder();
    _fileLocation=fileName;

    Level * level=new Level(fileName.toStdString());
    _currentlyBuilding=level;

    ReadLvlFileIgnoreCharacters(fileName);
    ReadCharacterFile(fileName);

    ConnectAllActivsAndPassivs();
    ConnectAllPortals();

    FinalizeLevel();

    return level;

}

void LevelBuilder::ResetBuilder()
{
    _grid=std::vector<std::vector<Tile *>>();

    _entities=std::vector<Character *>();
    _entityController=std::vector<Controller *>();

    _playerCharacter=nullptr;
    _playerController=nullptr;

    _lastPortal=nullptr;
    _lastPassiv=nullptr;
    _lastActiv=nullptr;
    _lastStairCase=nullptr;

    for(int i =0;i<MAX_PAIRS;i++){
        _portalPairs[i]=std::vector<Portal *>();
        _activs[i]=std::vector<Active *>();
        _passivs[i]=std::vector<Passive *>();
    }

    _entryStairCase=nullptr;
    _exitStaircase=nullptr;

}

void LevelBuilder::ReadLvlFile(QString &toLoad)
{
    std::ifstream infile(toLoad.toStdString());
    std::string line;
    char cur;
    int y=0;


    while(std::getline(infile,line))//in khatro barmidare ta /n
    {
        _grid.push_back(std::vector<Tile *>());
        std::stringstream ss;
        ss<<line;
        int x=0;
        while(ss>>cur)// ss = asdwqwet >> char = ' ' -> ss = <sdwqwet> cahr = 'a' nimmt soviel wie möglich und packt es n den Datenty rein
                      // ss = asdwqwet >> string = "" -> ss = <> string = "asdwqwet"
        {
            //constructore string
            std::string check=std::string(1,cur);//cur = 'd' check == 1*cur = "d" faghat yedune bashe
            std::string test=std::string(4,cur);//cur = 'd' check == 4*cur = "dddd"

            if(check.find_first_of("0123456789")==0)//age yekish bashe chek mikone
                //                                           0 1 2 3 4 5 6 7 8 9
                //string = "Hallo Welt" find first of("l")= "H a l l o   W e l t" erste "l" ist bei 2
                //                                            0 1 2 3 4 5 6 7 8 9
                //string = "Hallo Welt" find first of("la")= "H a l l o   W e l t" erste "l" oder "a" ist bei 1
                //                                            0 1 2 3 4 5 6 7 8 9
                //string = "Hallo Welt" find first of("xc")= "H a l l o   W e l t" es gibt kein x oder c also -1
            {
                AddPairsEntry(static_cast<int>(cur));
            }else{
                x+=CreateTileAtPos(cur,x,y);
            }
            if(_currentlyBuilding->getBreite()<x){
                _currentlyBuilding->setBreite(x);
            }
        }
        y++;
    }
    _currentlyBuilding->setHoehe(y);


}

std::string LevelBuilder::GetCharacterFileLocation()
{
    std::string fixfilelocation=_fileLocation.toStdString();
    fixfilelocation=fixfilelocation.substr(0,fixfilelocation.length()-4);
    //-4 für .txt wegzumachen
    fixfilelocation.append("characters.txt");//akharesh ino bezar
    return fixfilelocation;
}

void LevelBuilder::ReadLvlFileIgnoreCharacters(QString &toLoad)
{
    //std::cout<<"reading level file from: "<<toLoad.toStdString()<<std::endl;
    std::ifstream infile(toLoad.toStdString());
    std::string line;
    char cur;
    int y=0;


    while(std::getline(infile,line)){
        _grid.push_back(std::vector<Tile *>());
        std::stringstream ss;
        ss<<line;
        int x=0;
        while(ss>>cur){

            std::string check=std::string(1,cur);

            if(check.find_first_of("0123456789")==0){
                AddPairsEntry(static_cast<int>(cur));
            }else{
                switch (cur) {            
                case textureplayer:
                    cur='.';
                    break;
                case texturerZombie:
                    cur='.';
                    break;
                default:
                    break;

                }
                x+=CreateTileAtPos(cur,x,y);
            }
            if(_currentlyBuilding->getBreite()<x){
                _currentlyBuilding->setBreite(x);
            }
        }
        y++;
    }
    _currentlyBuilding->setHoehe(y);

    //std::cout<<"Level widht is: "<<_widht<<std::endl<<"Level height is: "<<_height<<std::endl;

}

void LevelBuilder::ReadCharacterFile(QString &toLoad)
{
    std::ifstream infile(GetCharacterFileLocation());
    std::string line;
    std::stringstream converter=std::stringstream();
    std::string test;

    while(std::getline(infile,line)){//Character"id" Position"x""y" MAXStamina "ms" curStamina "cs" strenght "st" curHealth "ch" movecycle "mc"

        test= CutNextVariable(line);
        converter.str(test);
        char id=' ';
        converter>>id;
        converter.str("");

        Position pos;
        test= CutNextVariable(line);
        pos.x=std::atoi(test.c_str());

        test= CutNextVariable(line);
        pos.y=std::atoi(test.c_str());

        test= CutNextVariable(line);
        int maxStamina=std::atoi(test.c_str());

        test= CutNextVariable(line);
        int curStamina=std::atoi(test.c_str());

        test= CutNextVariable(line);
        int strenght=std::atoi(test.c_str());

        test= CutNextVariable(line);
        int curHealth=std::atoi(test.c_str());

        test= CutNextVariable(line);
        int movecycle=std::atoi(test.c_str());

        switch (id) {
        case textureplayer:
            _playerCharacter= new Character(maxStamina,curStamina,strenght,curHealth,textureplayer);
            //entityController.push_back(new PlayerController(static_cast<Player *>(entities.back()),this,ui));
            _playerController=new PlayerController(_playerCharacter,_currentlyBuilding);
             GetTileByPosition(pos)->setCharactarOnTile(_playerCharacter);
            _playerCharacter->setTileDerIchDarufStehe(GetTileByPosition(pos));
            break;
        case texturerZombie:
            _entities.push_back(new Character(maxStamina,curStamina,strenght,curHealth,texturerZombie));
            //_entityController.push_back(new GuardController(_entities.back(),_currentlyBuilding));
            _entityController.push_back(new ChaseController(_entities.back(),_currentlyBuilding,new NavGraphAgent(_currentlyBuilding->getNavGraph())));
            GetTileByPosition(pos)->setCharactarOnTile(_entities.back());
            _entities.back()->setTileDerIchDarufStehe(GetTileByPosition(pos));
            break;
        }

    }
}

std::string LevelBuilder::CutNextVariable(std::string &line)
{
    std::string buffer;

    int beginn=line.find_first_of('"');
    line=line.substr(beginn+1);
    int end=line.find_first_of('"');
    buffer = line.substr(0,end);
    line=line.substr(end+1);
    return buffer;
}

Tile *LevelBuilder::GetTileByPosition(Position &pos)
{
    return _grid.at(pos.y).at(pos.x);
}

int LevelBuilder::CreateTileAtPos(char tileTexture, int x,int y)
{
    switch(tileTexture)
    {
    case texturewall:
        _grid.at(y).push_back(new Wall(x,y));
        break;
    case texturefloor:
        _grid.at(y).push_back(new Floor(x,y));
        break;
    case textureportal:
        _grid.at(y).push_back(new Portal(x,y));
        _lastPortal=_grid.at(y).back();
        break;
    case textureplayer:
        _grid.at(y).push_back(new Floor(x,y));
        _playerCharacter=new Character(20,20);
        _grid.at(y).back()->setCharactarOnTile(_playerCharacter);
        _playerCharacter->setLevel(_currentlyBuilding);//
        _playerCharacter->setTileDerIchDarufStehe(_grid.at(y).back());
        break;
    case texturerZombie:
        _grid.at(y).push_back(new Floor(x,y));
        _entities.push_back(new Character(5,10));
        _grid.at(y).back()->setCharactarOnTile(_entities.back());
        _entities.back()->setLevel(_currentlyBuilding);//
        _entities.back()->setTileDerIchDarufStehe(_grid.at(y).back());
        _entities.back()->settexture(texturerZombie);
        _entityController.push_back(new ChaseController(_entities.back(),_currentlyBuilding,new NavGraphAgent(_currentlyBuilding->getNavGraph())));
        //verhalten von einem wenn zombie ein zombie

        break;
    case textureswitchS:
        _grid.at(y).push_back(new Switch(x,y));
        _lastActiv=static_cast<Switch*>(_grid.at(y).back());
        break;
    case textureLevelChanger:
        _grid.at(y).push_back(new LevelExit(x,y,_currentlyBuilding));
        _lastStairCase=static_cast<LevelExit*>(_grid.at(y).back());
        break;
    case texturepit:
        _grid.at(y).push_back(new Pit(x,y));
        break;
    case texturerChest:
        _grid.at(y).push_back(new Chest(x,y));
        break;
    case textureramp:
        _grid.at(y).push_back(new Ramp(x,y));
        break;
    case texturedoorOpen :
        _grid.at(y).push_back(new Door(x,y,true));
        _lastPassiv=static_cast<Door*>(_grid.at(y).back());

        break;
    case texturedoorClose :
        _grid.at(y).push_back(new Door(x,y,false));
        _lastPassiv=static_cast<Door*>(_grid.at(y).back());
        break;
    case textureempty:
        return -1;
        break;
    default:
        std::cout<<"Error reading file content, wrong character"<<std::endl;
        break;
    }
    return 1;

}

void LevelBuilder::AddPairsEntry(int pair)
{
    pair-=48;//TO-DO find better char to int conversion
    if(_lastActiv!=nullptr){

        _activs[pair].push_back(_lastActiv);
        _lastActiv=nullptr;

    }else if(_lastPassiv!=nullptr){
        _passivs[pair].push_back(_lastPassiv);
        _lastPassiv=nullptr;

    }else if (_lastPortal!=nullptr){
        _portalPairs[pair].push_back(static_cast<Portal *>(_lastPortal));
        _lastPortal=nullptr;
    }else if(_lastStairCase!=nullptr){
        switch(pair){
        case 0:
            _entryStairCase=_lastStairCase;
            _lastStairCase=nullptr;
            break;
        case 1:
            _exitStaircase=_lastStairCase;
            _lastStairCase=nullptr;
            break;

        }
    }
    else{
        //_ui->DisplayError("No last pointer set, check level file");
    }

}

void LevelBuilder::ConnectAllPortals()
{
    for(int i=0;i<MAX_PAIRS;i++){
        if(_portalPairs[i].size()==2){
            _portalPairs[i].at(0)->setDestination(_portalPairs[i].at(1));
            _portalPairs[i].at(1)->setDestination(_portalPairs[i].at(0));
        }
    }
}

void LevelBuilder::ConnectAllActivsAndPassivs()
{
    for(int i=0;i<MAX_PAIRS;i++){
        ConnectPassivsToActivs(i);
    }
    /*for(int i=0;i<MAX_PAIRS;i++){
        for(int o=0;o<activs[i].size();o++){
            for(int p=0;p<passivs[i].size();p++){
                activs[i].at(o)->AddListener(passivs[i].at(p));
            }
        }
    }*/
}

void LevelBuilder::ConnectPassivsToActivs(int arrayIndex)
{
    for(unsigned int i=0;i<_activs[arrayIndex].size();i++){
        ConnectPassivsToActiv(arrayIndex,i);
    }
}

void LevelBuilder::ConnectPassivsToActiv(int arrayIndex, int activIndex)
{
    for(unsigned int i=0;i<_passivs[arrayIndex].size();i++){
        ConnectPassivToActiv(arrayIndex,activIndex,i);
    }
    _activs[arrayIndex].at(activIndex)->attach(_currentlyBuilding->getNavGraph());

}

void LevelBuilder::ConnectPassivToActiv(int arrayIndex, int activIndex, int passivIndex)
{
    _activs[arrayIndex].at(activIndex)->attach(_passivs[arrayIndex].at(passivIndex));

}

void LevelBuilder::FinalizeLevel()
{
    _currentlyBuilding->setGrid(_grid);
    _currentlyBuilding->setCharacters(_entities);
    _currentlyBuilding->setEnemyControllers(_entityController);
    _currentlyBuilding->setPlayerInLevel(_playerCharacter);
    _currentlyBuilding->setPlayerController(_playerController);
    _currentlyBuilding->setEntryStairCase(_entryStairCase);
    _currentlyBuilding->setExitStairCase(_exitStaircase);
    _currentlyBuilding->initialize();

}
