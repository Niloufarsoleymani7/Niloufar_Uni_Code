#include "enemycollection.h"

EnemyCollection:: EnemyCollection(Character *character_p
                                  ,Controller *controller_p,QLabel *qLabel_p)
{
    character=character_p;
    controller=controller_p;
    qLabel=qLabel_p;


}
