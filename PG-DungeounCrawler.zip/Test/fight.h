#ifndef FIGHT_H
#define FIGHT_H
#include<character.h>

class Fight
{
public:
    Fight(Character * angreifer_par,Character *verteidiger_par);
    Character *angreifer=nullptr;
    Character *verteidiger=nullptr;
    void fight();
};

#endif // FIGHT_H
