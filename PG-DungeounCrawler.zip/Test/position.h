#ifndef POSITION_H
#define POSITION_H
#include<math.h>

struct Position
{
public:
     Position();
     Position(int nx,int ny);
     int x =0;
     int y =0;
     bool isMovePos();
     Position operator+(const Position& a)const;
     Position operator-(const Position& a)const;
     bool operator==(const Position& a)const;
     bool operator!=(const Position& a)const;

};

static Position POSUPLEFT=Position(-1,-1);
static Position POSUP=Position(0,-1);
static Position POSUPRIGHT=Position(1,-1);
static Position POSLEFT=Position(-1,0);
static Position POSSTAY=Position(0,0);
static Position POSRIGHT=Position(1,0);
static Position POSDOWNLEFT=Position(-1,1);
static Position POSDOWN=Position(0,1);
static Position POSDOWNRIGHT=Position(1,1);
static Position POSPINFINITY=Position(INT_MAX,INT_MAX);
static Position INPUTTRANSLATE[10] = {POSPINFINITY,POSDOWNLEFT,POSDOWN,POSDOWNRIGHT,POSLEFT,POSSTAY,POSRIGHT,POSUPLEFT,POSUP,POSUPRIGHT};

#endif // POSITION_H
