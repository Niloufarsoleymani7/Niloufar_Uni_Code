#ifndef VICTORYDIALOG_H
#define VICTORYDIALOG_H

#include <QDialog>
#include<mainwindow.h>
#include<MyStatics.h>

namespace Ui {
class VictoryDialog;
}
class MainWindow;


class VictoryDialog : public QDialog
{
    Q_OBJECT

public:
    explicit VictoryDialog(QWidget *parent = nullptr,MainWindow *mainwindow=nullptr);
    ~VictoryDialog();


public slots:

    void accept()override;
    void reject()override;

private:
    Ui::VictoryDialog *ui;
    void deletGame();
    MainWindow *mw=nullptr;
};

#endif // VICTORYDIALOG_H
